import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  phoneNumber: text("phone_number"),
  fullName: text("full_name"),
  walletAddress: text("wallet_address").notNull(),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Wallet model
export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  balance: doublePrecision("balance").notNull().default(0),
  currency: text("currency").notNull().default("USDC"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertWalletSchema = createInsertSchema(wallets).omit({
  id: true,
  createdAt: true,
});

// Transaction types
export const TRANSACTION_TYPES = {
  SEND: "send",
  RECEIVE: "receive",
  STAKE: "stake",
  CARD: "card",
  REWARD: "reward",
} as const;

// Transaction model
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(),
  amount: doublePrecision("amount").notNull(),
  fee: doublePrecision("fee").default(0).notNull(),
  recipient: text("recipient"),
  sender: text("sender"),
  note: text("note"),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

// QR code model
export const qrCodes = pgTable("qr_codes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: doublePrecision("amount"),
  description: text("description"),
  expiresAt: timestamp("expires_at"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertQrCodeSchema = createInsertSchema(qrCodes).omit({
  id: true,
  createdAt: true,
});

// Contacts model
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  email: text("email"),
  phoneNumber: text("phone_number"),
  profilePic: text("profile_pic"),
  isFavorite: boolean("is_favorite").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

// Define types for models
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Wallet = typeof wallets.$inferSelect;
export type InsertWallet = z.infer<typeof insertWalletSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type QrCode = typeof qrCodes.$inferSelect;
export type InsertQrCode = z.infer<typeof insertQrCodeSchema>;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;

// Custom schema for sending money
export const sendMoneySchema = z.object({
  recipient: z.string().min(1, "Recipient is required"),
  amount: z.number().positive("Amount must be positive"),
  note: z.string().optional(),
});

export type SendMoneyInput = z.infer<typeof sendMoneySchema>;

// Custom schema for QR code generation
export const generateQrSchema = z.object({
  amount: z.number().optional(),
  description: z.string().optional(),
  expiresAt: z.date().optional(),
});

export type GenerateQrInput = z.infer<typeof generateQrSchema>;

// Schema para añadir contactos
export const addContactSchema = z.object({
  userId: z.number(),
  name: z.string().min(1, "El nombre es requerido"),
  email: z.string().email("Email inválido").optional().nullable(),
  phoneNumber: z.string().min(8, "Número de teléfono inválido").optional().nullable(),
  isFavorite: z.boolean().default(false),
  profilePic: z.string().optional().nullable(),
});

export type AddContactInput = z.infer<typeof addContactSchema>;

// Esquemas para autenticación
export const registerSchema = z.object({
  username: z.string().min(3, "El nombre de usuario debe tener al menos 3 caracteres"),
  password: z.string().min(8, "La contraseña debe tener al menos 8 caracteres"),
  email: z.string().email("Email inválido"),
  phoneNumber: z.string().min(8, "Número de teléfono inválido").optional().nullable(),
  fullName: z.string().min(3, "El nombre completo es requerido").optional().nullable(),
});

export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  username: z.string().min(1, "El nombre de usuario es requerido"),
  password: z.string().min(1, "La contraseña es requerida"),
});

export type LoginInput = z.infer<typeof loginSchema>;

// Inheritance/Heirs tables
export const heirs = pgTable("heirs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  relationship: text("relationship").notNull(),
  percentage: doublePrecision("percentage").notNull(),
  documentType: text("document_type"),
  documentNumber: text("document_number"),
  address: text("address"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const inheritanceSettings = pgTable("inheritance_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  isEnabled: boolean("is_enabled").default(false).notNull(),
  inactivityPeriodMonths: integer("inactivity_period_months").default(6).notNull(),
  lastActivity: timestamp("last_activity").defaultNow().notNull(),
  notificationsSent: integer("notifications_sent").default(0).notNull(),
  finalNotificationDate: timestamp("final_notification_date"),
  inheritanceExecuted: boolean("inheritance_executed").default(false).notNull(),
  executionDate: timestamp("execution_date"),
  emergencyContact: text("emergency_contact"),
  emergencyContactPhone: text("emergency_contact_phone"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type Heir = typeof heirs.$inferSelect;
export type InheritanceSettings = typeof inheritanceSettings.$inferSelect;

export const addHeirSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address").optional(),
  phone: z.string().min(1, "Phone number is required"),
  relationship: z.string().min(1, "Relationship is required"),
  percentage: z.number().min(0.01, "Percentage must be greater than 0").max(100, "Percentage cannot exceed 100"),
  documentType: z.string().optional(),
  documentNumber: z.string().optional(),
  address: z.string().optional(),
});

export type AddHeirInput = z.infer<typeof addHeirSchema>;
