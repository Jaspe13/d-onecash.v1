import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Profile from "@/pages/Profile";
import Wallet from "@/pages/Wallet";
import Statistics from "@/pages/Statistics";
import Contacts from "@/pages/Contacts";
import KYC from "@/pages/KYC";
import Settings from "@/pages/Settings";
// Sección de Crypto eliminada según solicitud del usuario
import Loans from "@/pages/Loans";
import Invest from "@/pages/Invest";
import Business from "@/pages/Business";
import Help from "@/pages/Help";
import Heirs from "@/pages/Heirs";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import { WalletProvider } from "./contexts/WalletContext";
import Layout from "./components/Layout";
import { useEffect } from "react";

function Router() {
  const [location, setLocation] = useLocation();

  // Verificar sesión en páginas protegidas
  useEffect(() => {
    const publicRoutes = ['/login', '/register'];
    const isPublicRoute = publicRoutes.includes(location);
    const user = localStorage.getItem('currentUser');
    
    if (!user && !isPublicRoute) {
      setLocation('/login');
    }
  }, [location, setLocation]);

  // Decidir si mostrar el Layout basado en la ruta
  const isAuthRoute = ['/login', '/register'].includes(location);

  if (isAuthRoute) {
    return (
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route component={Login} />
      </Switch>
    );
  }

  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/profile" component={Profile} />
        <Route path="/wallet" component={Wallet} />
        <Route path="/stats" component={Statistics} />
        <Route path="/contacts" component={Contacts} />
        <Route path="/verification" component={KYC} />
        <Route path="/settings" component={Settings} />
        {/* Ruta de Crypto eliminada según solicitud del usuario */}
        <Route path="/loans" component={Loans} />
        <Route path="/invest" component={Invest} />
        <Route path="/business" component={Business} />
        <Route path="/help" component={Help} />
        <Route path="/heirs" component={Heirs} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WalletProvider>
          <Router />
          <Toaster />
        </WalletProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
