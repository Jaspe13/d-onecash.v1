import { SVGProps } from "react";

export function D1CLogo(props: SVGProps<SVGSVGElement>) {
  // Logo verde con patrón de puntos y curva exterior
  return (
    <svg
      width="40"
      height="40"
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <g>
        {/* Patrón de puntos verdes */}
        <g>
          {Array.from({ length: 10 }).map((_, i) => 
            Array.from({ length: 10 - i }).map((_, j) => (
              <circle 
                key={`${i}-${j}`} 
                cx={20 + i * 6} 
                cy={20 + j * 6} 
                r={2.5 - (i + j) * 0.1} 
                fill="#00E676" 
              />
            ))
          )}
        </g>
        
        {/* Arco exterior */}
        <path
          d="M80 50C80 31.77 65.23 17 47 17C28.77 17 14 31.77 14 50"
          stroke="#00E676"
          strokeWidth="5"
          strokeLinecap="round"
          fill="none"
        />
      </g>
    </svg>
  );
}
