import React from 'react';

interface LogoVerdeProps {
  className?: string;
}

export function LogoVerde({ className = "h-8 w-8" }: LogoVerdeProps) {
  // Implementación SVG del logo verde con patrón de puntos
  return (
    <svg
      className={className}
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Fondo transparente */}
      <rect width="100" height="100" fill="transparent" />
      
      {/* Patrón de puntos verdes en degradado */}
      {[...Array(8)].map((_, i) => 
        [...Array(8 - Math.floor(i/1.5))].map((_, j) => (
          <circle
            key={`${i}-${j}`}
            cx={20 + i * 7}
            cy={35 + j * 7}
            r={2.5 - (i + j) * 0.1}
            fill="#00E676"
            opacity={1 - (i + j) * 0.06}
          />
        ))
      )}
      
      {/* Círculo exterior parcial */}
      <path
        d="M80 50C80 31.77 65.23 17 47 17C28.77 17 14 31.77 14 50"
        stroke="#00E676"
        strokeWidth="5"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}