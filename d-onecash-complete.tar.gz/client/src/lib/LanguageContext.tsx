import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Definir los tipos de idioma disponibles
type Language = 'es' | 'en';

// Interfaz para las traducciones
interface Translations {
  [key: string]: string;
}

// Interfaz para el contexto
interface LanguageContextType {
  language: Language;
  translate: (key: string) => string;
  setLanguage: (lang: Language) => void;
}

// Crear el contexto
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Traducciones en español
const spanishTranslations: Translations = {
  // Menú
  'dashboard': 'Inicio',
  'wallet': 'Billetera',
  'stats': 'Estadísticas',
  'contacts': 'Contactos',
  'kyc': 'KYC',
  'loans': 'Préstamos',
  'settings': 'Configuración',
  
  // Usuario
  'profile': 'Perfil',
  'logout': 'Cerrar sesión',
  
  // Auth
  'login': 'Iniciar sesión',
  'register': 'Registrarse',
  'welcome_back': 'Bienvenido de nuevo',
  'enter_credentials': 'Ingresa tus credenciales para acceder',
  'email': 'Correo electrónico',
  'password': 'Contraseña',
  'submit': 'Iniciar sesión',
  'faceid': 'Iniciar con Face ID',
  'register_link': '¿No tienes cuenta? Regístrate',
  
  // Face ID
  'faceid_title': 'Autenticación con Face ID',
  'start_scanner': 'Iniciar escáner',
  'scanning': 'Escaneando...',
};

// Traducciones en inglés
const englishTranslations: Translations = {
  // Menú
  'dashboard': 'Dashboard',
  'wallet': 'Wallet',
  'stats': 'Statistics',
  'contacts': 'Contacts',
  'kyc': 'KYC',
  'loans': 'Loans',
  'settings': 'Settings',
  
  // Usuario
  'profile': 'Profile',
  'logout': 'Logout',
  
  // Auth
  'login': 'Sign in',
  'register': 'Register',
  'welcome_back': 'Welcome back',
  'enter_credentials': 'Enter your credentials to access',
  'email': 'Email',
  'password': 'Password',
  'submit': 'Sign in',
  'faceid': 'Sign in with Face ID',
  'register_link': 'Don\'t have an account? Register',
  
  // Face ID
  'faceid_title': 'Face ID Authentication',
  'start_scanner': 'Start scanner',
  'scanning': 'Scanning...',
};

// Diccionario completo de traducciones
const translations: Record<Language, Translations> = {
  es: spanishTranslations,
  en: englishTranslations,
};

// Proveedor del contexto
export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Obtener el idioma del localStorage o usar español por defecto
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('d1c-language');
    return (saved === 'en' ? 'en' : 'es') as Language;
  });

  // Función para cambiar el idioma
  const setLanguage = (lang: Language) => {
    localStorage.setItem('d1c-language', lang);
    setLanguageState(lang);
  };

  // Función para traducir un texto
  const translate = (key: string): string => {
    return translations[language][key] || key;
  };

  // Proporcionar el contexto
  return (
    <LanguageContext.Provider value={{ language, translate, setLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Hook personalizado para usar el contexto
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// Componente selector de idioma
export const LanguageSelector: React.FC = () => {
  const { language, setLanguage } = useLanguage();
  
  return (
    <div className="flex gap-1">
      <button
        onClick={() => setLanguage('es')}
        className={`px-2 py-1 rounded-md text-sm font-medium ${
          language === 'es' 
            ? 'bg-primary text-white' 
            : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
        }`}
      >
        ES
      </button>
      <button
        onClick={() => setLanguage('en')}
        className={`px-2 py-1 rounded-md text-sm font-medium ${
          language === 'en' 
            ? 'bg-primary text-white' 
            : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
        }`}
      >
        EN
      </button>
    </div>
  );
};