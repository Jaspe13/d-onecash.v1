import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

export function LangSelect() {
  // Estado para el idioma actual
  const [lang, setLang] = useState(() => {
    return localStorage.getItem("app_lang") === "en" ? "en" : "es";
  });

  // Función para cambiar el idioma
  const changeLang = (newLang: "es" | "en") => {
    if (newLang === lang) return;
    
    localStorage.setItem("app_lang", newLang);
    
    // Forzar recarga para aplicar los cambios de idioma
    window.location.reload();
  };

  return (
    <div className="flex items-center gap-1">
      <Button
        variant={lang === "es" ? "default" : "outline"}
        size="sm"
        onClick={() => changeLang("es")}
        className="h-8 px-2 py-1"
      >
        ESP
      </Button>
      <Button
        variant={lang === "en" ? "default" : "outline"}
        size="sm"
        onClick={() => changeLang("en")}
        className="h-8 px-2 py-1"
      >
        ENG
      </Button>
    </div>
  );
}