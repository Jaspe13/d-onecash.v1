import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

export default function IdiomaSelector() {
  const [idioma, setIdioma] = useState<"es" | "en">(() => {
    // Obtener el idioma guardado o usar español por defecto
    const savedLanguage = localStorage.getItem("idioma");
    return (savedLanguage === "en" ? "en" : "es");
  });

  // Cambiar el idioma
  const cambiarIdioma = (nuevoIdioma: "es" | "en") => {
    // Guardar la preferencia del usuario
    localStorage.setItem("idioma", nuevoIdioma);
    // Actualizar el estado
    setIdioma(nuevoIdioma);
    // Recargar la página para aplicar los cambios
    window.location.reload();
  };

  return (
    <div className="flex gap-1">
      <Button
        variant={idioma === "es" ? "default" : "outline"}
        size="sm"
        onClick={() => cambiarIdioma("es")}
      >
        ES
      </Button>
      <Button
        variant={idioma === "en" ? "default" : "outline"}
        size="sm"
        onClick={() => cambiarIdioma("en")}
      >
        EN
      </Button>
    </div>
  );
}