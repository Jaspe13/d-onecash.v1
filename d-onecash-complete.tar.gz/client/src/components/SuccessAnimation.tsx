import { useState, useEffect } from "react";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SuccessAnimationProps {
  title: string;
  message: string;
  onClose: () => void;
}

export default function SuccessAnimation({ title, message, onClose }: SuccessAnimationProps) {
  const [show, setShow] = useState(false);
  
  useEffect(() => {
    // Trigger animation after component mounts
    setTimeout(() => setShow(true), 100);
    
    // Auto-close after 6 seconds
    const timeout = setTimeout(() => {
      setShow(false);
      setTimeout(onClose, 500);
    }, 6000);
    
    return () => clearTimeout(timeout);
  }, [onClose]);
  
  return (
    <div className={`fixed inset-0 flex items-center justify-center z-50 bg-black/50 transition-opacity duration-500 ${show ? 'opacity-100' : 'opacity-0'}`}>
      <div className={`bg-background text-foreground rounded-lg max-w-md mx-auto p-6 shadow-lg transform transition-all duration-500 ${show ? 'scale-100 translate-y-0' : 'scale-95 translate-y-4'}`}>
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-4">
            {/* Círculo exterior pulsante */}
            <div className="absolute inset-0 rounded-full bg-green-500/20 animate-ping"></div>
            
            {/* Círculo base */}
            <div className="relative flex items-center justify-center h-24 w-24 rounded-full bg-green-500 text-white">
              {/* Animación de entrada del check */}
              <Check className="h-12 w-12 animate-checkmark" />
            </div>
            
            {/* Destellos alrededor */}
            <div className="absolute top-0 right-0 h-3 w-3 rounded-full bg-green-400 animate-sparkle delay-75"></div>
            <div className="absolute bottom-0 left-0 h-2 w-2 rounded-full bg-green-400 animate-sparkle delay-150"></div>
            <div className="absolute top-1/2 left-0 h-2 w-2 rounded-full bg-green-400 animate-sparkle delay-300"></div>
            <div className="absolute bottom-1/4 right-0 h-2 w-2 rounded-full bg-green-400 animate-sparkle"></div>
          </div>
          
          <h2 className="text-xl font-bold mb-2">{title}</h2>
          <p className="text-muted-foreground mb-6">{message}</p>
          
          <Button onClick={() => {
            setShow(false);
            setTimeout(onClose, 500);
          }}>
            Continuar
          </Button>
        </div>
      </div>
    </div>
  );
}