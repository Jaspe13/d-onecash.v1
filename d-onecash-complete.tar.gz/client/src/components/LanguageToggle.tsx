import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

// Definir tipo de idioma
type Language = "es" | "en";

// Objeto de traducciones
const translations = {
  es: {
    // Interfaz general
    "app.theme.dark": "Oscuro",
    "app.theme.light": "Claro",
    "app.language": "Idioma",
    "app.send": "Enviar",
    "app.receive": "Recibir",
    "app.qrpay": "Pago QR",
    
    // Autenticación
    "login.sign_in_with_face_id": "Acceder con Face ID",
    "login.title": "Iniciar Sesión",
    "login.description": "Inicia sesión en tu cuenta D-OneCash",
    "login.welcome_back": "Bienvenido de vuelta",
    "login.enter_credentials": "Ingresa tus credenciales para acceder",
    "login.username": "Nombre de usuario",
    "login.username_placeholder": "Tu nombre de usuario",
    "login.password": "Contraseña",
    "login.password_placeholder": "Tu contraseña",
    "login.sign_in": "Iniciar sesión",
    "login.signing_in": "Iniciando sesión...",
    "login.dont_have_account": "¿No tienes una cuenta?",
    "login.create_account": "Crear cuenta",
    "login.error": "Error al iniciar sesión",
    
    // Registro
    "register.title": "Registro",
    "register.description": "Crea una nueva cuenta en D-OneCash",
    "register.create_account": "Crear cuenta",
    "register.enter_details": "Ingresa tus datos para registrarte",
    "register.username": "Nombre de usuario",
    "register.username_placeholder": "Crea un nombre de usuario",
    "register.email": "Correo electrónico",
    "register.email_placeholder": "tu@correo.com",
    "register.password": "Contraseña",
    "register.password_placeholder": "Crea una contraseña segura",
    "register.full_name": "Nombre completo",
    "register.full_name_placeholder": "Tu nombre completo",
    "register.phone_number": "Número de teléfono",
    "register.phone_placeholder": "+1234567890",
    "register.creating_account": "Creando cuenta...",
    "register.already_have_account": "¿Ya tienes una cuenta?",
    "register.sign_in": "Iniciar sesión",
    "register.error": "Error al crear la cuenta",
    
    // Encabezado
    "header.log_out": "Cerrar sesión",
    "header.log_in": "Iniciar sesión",
    "header.sign_up": "Registrarse",
    
    // Contactos
    "app.contact.page_title": "Mis Contactos",
    "app.contact.page_desc": "Administra tus contactos para envíos rápidos",
    "app.contact.add": "Añadir Contacto",
    "app.contact.add_title": "Nuevo Contacto",
    "app.contact.add_desc": "Añade un nuevo contacto para envíos rápidos",
    "app.contact.add_button": "Guardar",
    "app.contact.adding": "Guardando...",
    "app.contact.name": "Nombre",
    "app.contact.name_placeholder": "Nombre completo",
    "app.contact.email": "Correo Electrónico",
    "app.contact.email_placeholder": "ejemplo@email.com",
    "app.contact.phone": "Teléfono",
    "app.contact.phone_placeholder": "+1234567890",
    "app.contact.favorite": "Favorito",
    "app.contact.favorite_desc": "Marca como favorito para acceso rápido",
    "app.contact.added_title": "Contacto añadido",
    "app.contact.added_desc": "El contacto ha sido añadido correctamente",
    "app.contact.add_error_title": "Error",
    "app.contact.add_error_desc": "No se pudo añadir el contacto",
    "app.contact.deleted": "Contacto eliminado",
    "app.contact.deleted_desc": "El contacto ha sido eliminado correctamente",
    "app.contact.confirm_delete": "¿Estás seguro que deseas eliminar este contacto?",
    "app.contact.search": "Buscar contactos...",
    "app.contact.empty": "No tienes contactos. Añade uno para comenzar.",
    "app.contact.no_results": "No se encontraron resultados para tu búsqueda.",
    "app.contact.import": "Importar",
    "app.contact.importing": "Importando...",
    "app.contact.import_title": "Importación de contactos",
    "app.contact.import_desc": "Tus contactos han sido importados correctamente",
    
    // Verificación KYC
    "app.kyc.page_title": "KYC",
    "app.kyc.page_desc": "Completa tu verificación KYC para aumentar tus límites de transacción y acceder a más funciones",
    "app.kyc.verification_progress": "Progreso de verificación",
    "app.kyc.verification_desc": "Completa todos los pasos para verificar tu identidad",
    "app.kyc.progress": "Progreso general",
    "app.kyc.id_title": "Documento de identidad",
    "app.kyc.id_desc": "Sube tu identificación o pasaporte",
    "app.kyc.id_upload_desc": "Documento de identidad válido (DNI, pasaporte)",
    "app.kyc.address_title": "Comprobante de dirección",
    "app.kyc.address_desc": "Documento que verifique tu dirección",
    "app.kyc.address_upload_desc": "Factura de servicios o extracto bancario (no mayor a 3 meses)",
    "app.kyc.selfie_title": "Selfie con ID",
    "app.kyc.selfie_desc": "Una foto tuya sosteniendo tu identificación",
    "app.kyc.selfie_upload_desc": "Asegúrate que toda la información sea visible",
    "app.kyc.verified": "Verificado",
    "app.kyc.pending": "En revisión",
    "app.kyc.in_progress": "En progreso",
    "app.kyc.rejected": "Rechazado",
    "app.kyc.not_started": "No iniciado",
    "app.kyc.upload": "Subir documento",
    "app.kyc.uploading": "Subiendo...",
    "app.kyc.upload_success": "Documento subido",
    "app.kyc.upload_success_desc": "Tu documento ha sido enviado para revisión",
    "app.kyc.legal_title": "Información legal",
    "app.kyc.legal_desc": "Todos los documentos son procesados de manera segura y confidencial. D-OneCash cumple con las regulaciones de protección de datos y prevención de lavado de dinero.",
    
    // Crypto Trading
    "app.crypto.page_title": "Trade",
    "app.crypto.subtitle": "Compra, vende y recibe criptomonedas",
    "app.crypto.buy": "Comprar",
    "app.crypto.sell": "Vender",
    "app.crypto.receive": "Recibir",
    "app.crypto.select_crypto": "Seleccionar Criptomoneda",
    "app.crypto.amount": "Cantidad",
    "app.crypto.wallet_address": "Dirección de Billetera",
    "app.crypto.network": "Red",
    "app.crypto.fee": "Comisión",
    "app.crypto.total": "Total",
    "app.crypto.available_balance": "Saldo Disponible",
    "app.crypto.commission": "Comisión aplicada",
    "app.crypto.confirm": "Confirmar Transacción",
    "app.crypto.transaction_success": "Transacción Exitosa",
    "app.crypto.transaction_pending": "Transacción Pendiente",
    "app.crypto.your_wallet_address": "Tu Dirección de Billetera",
    "app.crypto.copy_address": "Copiar Dirección",
    "app.crypto.address_copied": "Dirección copiada al portapapeles",
    "app.crypto.qr_description": "Escanea este código QR para recibir criptomonedas",
    "app.crypto.my_assets": "Mis Activos",
    "app.crypto.market": "Mercado",
    "app.crypto.price": "Precio",
    "app.crypto.24h": "24h",
    "app.crypto.staking": "Ahorro",
    "app.crypto.stake": "Ahorrar",
    "app.crypto.unstake": "Retirar Ahorro",
    "app.crypto.staking_period": "Período de Ahorro",
    "app.crypto.reward_rate": "Tasa de Recompensa",
    "app.crypto.estimated_rewards": "Recompensas Estimadas",
    "app.crypto.1_month": "1 Mes",
    "app.crypto.2_months": "2 Meses",
    "app.crypto.3_months": "3 Meses",
    "app.crypto.6_months": "6 Meses",
    "app.crypto.12_months": "12 Meses",
    
    // General
    "Profile": "Perfil",
    "Settings": "Configuración"
  },
  en: {
    // General Interface
    "app.theme.dark": "Dark",
    "app.theme.light": "Light",
    "app.language": "Language",
    "app.send": "Send",
    "app.receive": "Receive",
    "app.qrpay": "QR Pay",
    
    // Authentication
    "login.sign_in_with_face_id": "Sign in with Face ID",
    "login.title": "Sign In",
    "login.description": "Sign in to your D-OneCash account",
    "login.welcome_back": "Welcome Back",
    "login.enter_credentials": "Enter your credentials to access",
    "login.username": "Username",
    "login.username_placeholder": "Your username",
    "login.password": "Password",
    "login.password_placeholder": "Your password",
    "login.sign_in": "Sign In",
    "login.signing_in": "Signing in...",
    "login.dont_have_account": "Don't have an account?",
    "login.create_account": "Create account",
    "login.error": "Error signing in",
    
    // Registration
    "register.title": "Register",
    "register.description": "Create a new D-OneCash account",
    "register.create_account": "Create Account",
    "register.enter_details": "Enter your details to register",
    "register.username": "Username",
    "register.username_placeholder": "Create a username",
    "register.email": "Email",
    "register.email_placeholder": "your@email.com",
    "register.password": "Password",
    "register.password_placeholder": "Create a secure password",
    "register.full_name": "Full Name",
    "register.full_name_placeholder": "Your full name",
    "register.phone_number": "Phone Number",
    "register.phone_placeholder": "+1234567890",
    "register.creating_account": "Creating account...",
    "register.already_have_account": "Already have an account?",
    "register.sign_in": "Sign in",
    "register.error": "Error creating account",
    
    // Header
    "header.log_out": "Log Out",
    "header.log_in": "Log In",
    "header.sign_up": "Sign Up",
    
    // Contacts
    "app.contact.page_title": "My Contacts",
    "app.contact.page_desc": "Manage your contacts for quick money transfers",
    "app.contact.add": "Add Contact",
    "app.contact.add_title": "New Contact",
    "app.contact.add_desc": "Add a new contact for quick money transfers",
    "app.contact.add_button": "Save",
    "app.contact.adding": "Saving...",
    "app.contact.name": "Name",
    "app.contact.name_placeholder": "Full name",
    "app.contact.email": "Email",
    "app.contact.email_placeholder": "example@email.com",
    "app.contact.phone": "Phone",
    "app.contact.phone_placeholder": "+1234567890",
    "app.contact.favorite": "Favorite",
    "app.contact.favorite_desc": "Mark as favorite for quick access",
    "app.contact.added_title": "Contact added",
    "app.contact.added_desc": "The contact has been added successfully",
    "app.contact.add_error_title": "Error",
    "app.contact.add_error_desc": "Could not add contact",
    "app.contact.deleted": "Contact deleted",
    "app.contact.deleted_desc": "The contact has been deleted successfully",
    "app.contact.confirm_delete": "Are you sure you want to delete this contact?",
    "app.contact.search": "Search contacts...",
    "app.contact.empty": "You don't have any contacts. Add one to get started.",
    "app.contact.no_results": "No results found for your search.",
    "app.contact.import": "Import",
    "app.contact.importing": "Importing...",
    "app.contact.import_title": "Contact Import",
    "app.contact.import_desc": "Your contacts have been imported successfully",
    
    // KYC Verification
    "app.kyc.page_title": "KYC",
    "app.kyc.page_desc": "Complete your KYC verification to increase your transaction limits and access more features",
    "app.kyc.verification_progress": "Verification Progress",
    "app.kyc.verification_desc": "Complete all steps to verify your identity",
    "app.kyc.progress": "Overall progress",
    "app.kyc.id_title": "ID Document",
    "app.kyc.id_desc": "Upload your ID or passport",
    "app.kyc.id_upload_desc": "Valid ID document (passport, driver's license)",
    "app.kyc.address_title": "Proof of Address",
    "app.kyc.address_desc": "Document verifying your address",
    "app.kyc.address_upload_desc": "Utility bill or bank statement (not older than 3 months)",
    "app.kyc.selfie_title": "Selfie with ID",
    "app.kyc.selfie_desc": "A photo of yourself holding your ID",
    "app.kyc.selfie_upload_desc": "Make sure all information is visible",
    "app.kyc.verified": "Verified",
    "app.kyc.pending": "Under Review",
    "app.kyc.in_progress": "In Progress",
    "app.kyc.rejected": "Rejected",
    "app.kyc.not_started": "Not Started",
    "app.kyc.upload": "Upload Document",
    "app.kyc.uploading": "Uploading...",
    "app.kyc.upload_success": "Document Uploaded",
    "app.kyc.upload_success_desc": "Your document has been submitted for review",
    "app.kyc.legal_title": "Legal Information",
    "app.kyc.legal_desc": "All documents are processed securely and confidentially. D-OneCash complies with data protection and anti-money laundering regulations.",
    
    // Crypto Trading
    "app.crypto.page_title": "Trade",
    "app.crypto.subtitle": "Buy, sell and receive cryptocurrencies",
    "app.crypto.buy": "Buy",
    "app.crypto.sell": "Sell",
    "app.crypto.receive": "Receive",
    "app.crypto.select_crypto": "Select Cryptocurrency",
    "app.crypto.amount": "Amount",
    "app.crypto.wallet_address": "Wallet Address",
    "app.crypto.network": "Network",
    "app.crypto.fee": "Fee",
    "app.crypto.total": "Total",
    "app.crypto.available_balance": "Available Balance",
    "app.crypto.commission": "Commission Applied",
    "app.crypto.confirm": "Confirm Transaction",
    "app.crypto.transaction_success": "Transaction Successful",
    "app.crypto.transaction_pending": "Transaction Pending",
    "app.crypto.your_wallet_address": "Your Wallet Address",
    "app.crypto.copy_address": "Copy Address",
    "app.crypto.address_copied": "Address copied to clipboard",
    "app.crypto.qr_description": "Scan this QR code to receive cryptocurrencies",
    "app.crypto.my_assets": "My Assets",
    "app.crypto.market": "Market",
    "app.crypto.price": "Price",
    "app.crypto.24h": "24h",
    "app.crypto.staking": "Savings",
    "app.crypto.stake": "Save",
    "app.crypto.unstake": "Withdraw Savings",
    "app.crypto.staking_period": "Savings Period",
    "app.crypto.reward_rate": "Reward Rate",
    "app.crypto.estimated_rewards": "Estimated Rewards",
    "app.crypto.1_month": "1 Month",
    "app.crypto.2_months": "2 Months",
    "app.crypto.3_months": "3 Months",
    "app.crypto.6_months": "6 Months",
    "app.crypto.12_months": "12 Months",
    
    // General
    "Profile": "Profile",
    "Settings": "Settings"
  }
};

// Variable global para idioma actual
let currentLanguage: Language = "es";

// Inicializar el idioma basado en localStorage si existe
try {
  const savedLanguage = localStorage.getItem("language");
  if (savedLanguage === "en" || savedLanguage === "es") {
    currentLanguage = savedLanguage as Language;
  }
} catch (e) {
  console.error("Error accediendo a localStorage:", e);
}

// Funcion para obtener traducción
export function t(key: string): string {
  // @ts-ignore
  return translations[currentLanguage][key] || key;
}

// Componente de selector de idioma
export function LanguageToggle() {
  const [language, setLanguage] = useState<Language>(currentLanguage);
  
  // Cambiar idioma
  const changeLanguage = (lang: Language) => {
    // Actualizar idioma globalmente
    currentLanguage = lang;
    
    // Guardar en localStorage
    try {
      localStorage.setItem("language", lang);
    } catch (e) {
      console.error("Error guardando idioma:", e);
    }
    
    // Actualizar estado local
    setLanguage(lang);
    
    // Forzar recarga de la página para aplicar cambios
    window.location.reload();
  };
  
  return (
    <div className="flex gap-1">
      <Button
        variant={language === "es" ? "default" : "outline"}
        size="sm"
        onClick={() => changeLanguage("es")}
        className="px-2 py-1 h-8"
      >
        ESP
      </Button>
      <Button
        variant={language === "en" ? "default" : "outline"}
        size="sm"
        onClick={() => changeLanguage("en")}
        className="px-2 py-1 h-8"
      >
        ENG
      </Button>
    </div>
  );
}