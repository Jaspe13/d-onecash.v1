import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useWallet } from "@/hooks/useWallet";
import { Contact } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Trash2,
  Star,
  StarOff,
  UserPlus,
  Mail,
  Phone,
  Search,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { t } from "@/components/ui/LanguageToggle";
import AddContactModal from "./AddContactModal";

export default function ContactsList() {
  const { userId } = useWallet();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  
  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ['/api/contacts', userId],
    queryFn: async () => {
      const response = await fetch(`/api/contacts/${userId}`);
      const data = await response.json();
      return data as Contact[];
    },
    enabled: !!userId,
  });
  
  const deleteContactMutation = useMutation({
    mutationFn: async (contactId: number) => {
      return fetch(`/api/contacts/${contactId}`, {
        method: "DELETE"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contacts', userId] });
      toast({
        title: t("app.contact.deleted"),
        description: t("app.contact.deleted_desc"),
      });
    }
  });
  
  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({contactId, isFavorite}: {contactId: number, isFavorite: boolean}) => {
      return fetch(`/api/contacts/${contactId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isFavorite })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contacts', userId] });
    }
  });
  
  const handleDeleteContact = (contactId: number) => {
    if (confirm(t("app.contact.confirm_delete"))) {
      deleteContactMutation.mutate(contactId);
    }
  };
  
  const handleToggleFavorite = (contactId: number, isFavorite: boolean) => {
    toggleFavoriteMutation.mutate({ contactId, isFavorite: !isFavorite });
  };
  
  const filteredContacts = contacts.filter(
    (contact) => 
      contact.name.toLowerCase().includes(search.toLowerCase()) || 
      (contact.email && contact.email.toLowerCase().includes(search.toLowerCase())) ||
      (contact.phoneNumber && contact.phoneNumber.includes(search))
  );
  
  // Ordenar contactos: favoritos primero, luego por nombre
  const sortedContacts = [...filteredContacts].sort((a, b) => {
    // Primero ordenar por favoritos
    if (a.isFavorite && !b.isFavorite) return -1;
    if (!a.isFavorite && b.isFavorite) return 1;
    
    // Luego ordenar por nombre
    return a.name.localeCompare(b.name);
  });
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative w-full max-w-xs">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t("app.contact.search")}
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <UserPlus className="mr-2 h-4 w-4" />
          {t("app.contact.add")}
        </Button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : sortedContacts.length === 0 ? (
        <Card className="p-8 text-center text-muted-foreground">
          {search ? t("app.contact.no_results") : t("app.contact.empty")}
        </Card>
      ) : (
        <ScrollArea className="h-[calc(100vh-240px)]">
          <div className="grid gap-4 md:grid-cols-2">
            {sortedContacts.map((contact) => (
              <Card key={contact.id} className="p-4 flex items-start gap-4">
                <Avatar className="h-12 w-12">
                  {contact.profilePic ? (
                    <AvatarImage src={contact.profilePic} alt={contact.name} />
                  ) : (
                    <AvatarFallback>{contact.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                  )}
                </Avatar>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium truncate">{contact.name}</h3>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleToggleFavorite(contact.id, contact.isFavorite || false)}
                        className="h-8 w-8"
                      >
                        {contact.isFavorite ? (
                          <Star className="h-4 w-4 text-yellow-400" />
                        ) : (
                          <StarOff className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteContact(contact.id)}
                        className="h-8 w-8 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-1 mt-1">
                    {contact.email && (
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Mail className="h-3.5 w-3.5 mr-1.5" />
                        <span className="truncate">{contact.email}</span>
                      </div>
                    )}
                    {contact.phoneNumber && (
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Phone className="h-3.5 w-3.5 mr-1.5" />
                        <span>{contact.phoneNumber}</span>
                      </div>
                    )}
                  </div>
                  
                  {contact.isFavorite && (
                    <Badge variant="outline" className="mt-2 bg-yellow-50 text-yellow-700 border-yellow-200">
                      {t("app.contact.favorite")}
                    </Badge>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </ScrollArea>
      )}
      
      <AddContactModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        userId={userId}
      />
    </div>
  );
}