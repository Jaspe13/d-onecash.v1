import { useWallet } from "@/hooks/useWallet";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useLocation } from "wouter";

// Importar componentes para los modales
import SendMoneyModal from "./SendMoneyModal";
import QRCodeModal from "./QRCodeModal";

export default function QuickActions() {
  const { balance } = useWallet();
  const { toast } = useToast();
  const [location, setLocation] = useState(""); 
  
  // Estados para controlar los modales
  const [sendMoneyModalOpen, setSendMoneyModalOpen] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  
  const handleTransferClick = () => {
    // Mostrar el modal de envío de dinero
    setSendMoneyModalOpen(true);
  };
  
  const handleStakeClick = () => {
    // Navegar a la página de staking
    window.location.href = "/wallet?tab=staking";
  };
  
  const handleSwapClick = () => {
    toast({
      title: "Currency Exchange",
      description: "This feature will be available soon.",
      variant: "default",
    });
  };
  
  return (
    <>
      <section className="px-4 mb-6">
        <h2 className="text-lg font-semibold mb-3">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-3">
          {/* Remittance */}
          <div className="card-container flex flex-col">
            <div className="icon-container mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 14V2"></path>
                <path d="M9 18.12 21 18.12"></path>
                <path d="M17 22v-8"></path>
                <path d="M14 22H6a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2h8"></path>
                <path d="m9 14 3-3 3 3"></path>
              </svg>
            </div>
            <h3 className="text-sm font-medium mb-1">Send Money</h3>
            <p className="text-xs text-muted-foreground mb-2">Transfer to contacts</p>
            <button 
              className="mt-auto bg-primary hover:bg-primary/90 text-primary-foreground text-xs py-1.5 px-3 rounded-lg transition-colors"
              onClick={handleTransferClick}
            >
              Transfer
            </button>
          </div>
          
          {/* Staking */}
          <div className="card-container flex flex-col">
            <div className="icon-container mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2v20"></path>
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
              </svg>
            </div>
            <h3 className="text-sm font-medium mb-1">Savings</h3>
            <p className="text-xs text-muted-foreground mb-2">Earn up to 7.2% APY</p>
            <button 
              className="mt-auto bg-primary hover:bg-primary/90 text-primary-foreground text-xs py-1.5 px-3 rounded-lg transition-colors"
              onClick={handleStakeClick}
            >
              Invest D1C
            </button>
          </div>
          
          {/* Virtual Card */}
          <div className="card-container flex flex-col">
            <div className="icon-container mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="20" height="14" x="2" y="5" rx="2"></rect>
                <line x1="2" x2="22" y1="10" y2="10"></line>
              </svg>
            </div>
            <h3 className="text-sm font-medium mb-1">Virtual Card</h3>
            <p className="text-xs text-muted-foreground mb-2">Create a new card</p>
            <a
              href="/wallet?tab=cards" 
              className="mt-auto bg-primary hover:bg-primary/90 text-primary-foreground text-xs py-1.5 px-3 rounded-lg transition-colors text-center inline-block"
            >
              Get Card
            </a>
          </div>
          
          {/* QR Payment */}
          <div className="card-container flex flex-col">
            <div className="icon-container mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="6" height="6" x="3" y="3" rx="1"></rect>
                <rect width="6" height="6" x="15" y="3" rx="1"></rect>
                <rect width="6" height="6" x="3" y="15" rx="1"></rect>
                <rect width="6" height="6" x="15" y="15" rx="1"></rect>
              </svg>
            </div>
            <h3 className="text-sm font-medium mb-1">QR Payment</h3>
            <p className="text-xs text-muted-foreground mb-2">Generate or scan QR</p>
            <button 
              className="mt-auto bg-primary hover:bg-primary/90 text-primary-foreground text-xs py-1.5 px-3 rounded-lg transition-colors"
              onClick={() => setQrModalOpen(true)}
            >
              QR Code
            </button>
          </div>
        </div>
      </section>
      
      {/* Modales */}
      <SendMoneyModal 
        isOpen={sendMoneyModalOpen} 
        onClose={() => setSendMoneyModalOpen(false)} 
      />
      
      <QRCodeModal
        isOpen={qrModalOpen}
        onClose={() => setQrModalOpen(false)}
      />
    </>
  );
}
