import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Clipboard, Copy, Check, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import QRCode from "qrcode";

interface CollateralModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  btcAmount: number;
}

export default function CollateralModal({
  isOpen,
  onClose,
  onConfirm,
  btcAmount
}: CollateralModalProps) {
  const { toast } = useToast();
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<"instructions" | "confirmation" | "complete">("instructions");
  
  // D-OneCash wallet address (example)
  const walletAddress = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh";
  
  useEffect(() => {
    if (isOpen) {
      generateQRCode();
    }
  }, [isOpen]);
  
  const generateQRCode = async () => {
    try {
      const url = await QRCode.toDataURL(`bitcoin:${walletAddress}?amount=${btcAmount}`);
      setQrCodeUrl(url);
    } catch (error) {
      console.error("Error generating QR code:", error);
    }
  };
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(walletAddress);
    setCopied(true);
    
    toast({
      title: "Address copied",
      description: "Bitcoin address copied to clipboard",
    });
    
    setTimeout(() => setCopied(false), 3000);
  };
  
  const handleConfirmSent = () => {
    setLoading(true);
    
    // Simulate verifying the transaction
    setTimeout(() => {
      setLoading(false);
      setStep("confirmation");
    }, 2000);
  };
  
  const handleConfirmCollateral = () => {
    setStep("complete");
    
    // Allow a moment to see the completion message
    setTimeout(() => {
      onConfirm();
    }, 1500);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {step === "instructions" && "Send Collateral"}
            {step === "confirmation" && "Confirm Transaction"}
            {step === "complete" && "Collateral Received"}
          </DialogTitle>
          <DialogDescription>
            {step === "instructions" && `Please send ${btcAmount} BTC to complete your loan request.`}
            {step === "confirmation" && "Verify that you've sent the Bitcoin collateral."}
            {step === "complete" && "Your collateral has been received and your loan is being processed."}
          </DialogDescription>
        </DialogHeader>
        
        {step === "instructions" && (
          <div className="flex flex-col items-center space-y-4 py-4">
            <div className="bg-white p-2 rounded-md">
              {qrCodeUrl && (
                <img 
                  src={qrCodeUrl} 
                  alt="Bitcoin QR Code" 
                  className="w-48 h-48"
                />
              )}
            </div>
            
            <div className="flex items-center space-x-2 w-full border rounded-md p-2">
              <Clipboard className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <code className="text-xs truncate flex-1">{walletAddress}</code>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={copyToClipboard}
                className="h-8 w-8"
              >
                {copied ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
            
            <div className="bg-amber-50 text-amber-800 p-3 rounded-md text-sm w-full">
              <p className="font-medium">Important:</p>
              <p>Only send {btcAmount} BTC from a wallet you control. The collateral will be returned when you repay your loan.</p>
            </div>
          </div>
        )}
        
        {step === "confirmation" && (
          <div className="space-y-4 py-4">
            <div className="bg-green-50 border border-green-100 rounded-md p-4">
              <div className="flex items-center">
                <div className="mr-3 flex-shrink-0">
                  <Check className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-sm font-medium text-green-800">
                    Transaction detected
                  </p>
                  <p className="text-sm text-green-700">
                    We've detected a pending transaction of {btcAmount} BTC.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="rounded-md bg-primary/10 p-4">
              <div className="flex">
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-primary">
                    Next steps
                  </h3>
                  <div className="mt-2 text-sm text-primary/90">
                    <p>
                      Once the transaction is confirmed (usually within 10-30 minutes), your loan of {(btcAmount * 30000 * 0.5).toFixed(2)} USDC will be credited to your wallet.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {step === "complete" && (
          <div className="flex items-center justify-center py-8">
            <div className="rounded-full bg-green-100 p-3">
              <Check className="h-8 w-8 text-green-600" />
            </div>
          </div>
        )}
        
        <DialogFooter className="flex sm:justify-between">
          {step === "instructions" && (
            <>
              <Button 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleConfirmSent}
                disabled={loading}
              >
                {loading ? "Verifying..." : "I've sent the BTC"}
              </Button>
            </>
          )}
          
          {step === "confirmation" && (
            <>
              <Button 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleConfirmCollateral}
              >
                Confirm and continue
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}