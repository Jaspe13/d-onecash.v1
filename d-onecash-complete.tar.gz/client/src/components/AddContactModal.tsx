import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { t } from "@/components/ui/LanguageToggle";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { AddContactInput, addContactSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { z } from "zod";

interface AddContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: number;
}

export default function AddContactModal({ isOpen, onClose, userId }: AddContactModalProps) {
  const { toast } = useToast();
  const [isImporting, setIsImporting] = useState(false);
  
  // Extender el esquema para añadir validación específica de la UI
  const formSchema = addContactSchema.extend({
    // Aquí podríamos añadir validaciones adicionales si fuera necesario
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      userId,
      name: "",
      email: null,
      phoneNumber: null,
      isFavorite: false,
      profilePic: null
    },
  });
  
  const mutation = useMutation({
    mutationFn: async (values: AddContactInput) => {
      const response = await fetch("/api/contacts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values)
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contacts', userId] });
      toast({
        title: t("app.contact.added_title"),
        description: t("app.contact.added_desc"),
      });
      form.reset();
      onClose();
    },
    onError: (error) => {
      console.error("Error adding contact:", error);
      toast({
        title: t("app.contact.add_error_title"),
        description: t("app.contact.add_error_desc"),
        variant: "destructive",
      });
    },
  });
  
  // Simulación de importación de contactos (en una implementación real, esto conectaría con APIs nativas)
  const handleImportContacts = () => {
    setIsImporting(true);
    // Simular un retraso en la importación
    setTimeout(() => {
      setIsImporting(false);
      toast({
        title: t("app.contact.import_title"),
        description: t("app.contact.import_desc"),
      });
      // En una implementación real, aquí se procesarían los contactos importados
    }, 2000);
  };
  
  function onSubmit(values: z.infer<typeof formSchema>) {
    // Asegurarse de que userId esté incluido en los valores
    mutation.mutate({
      ...values,
      userId,
    });
  }
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{t("app.contact.add_title")}</DialogTitle>
          <DialogDescription>
            {t("app.contact.add_desc")}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("app.contact.name")}</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder={t("app.contact.name_placeholder")} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("app.contact.email")}</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      placeholder={t("app.contact.email_placeholder")} 
                      value={field.value || ""}
                      onChange={(e) => field.onChange(e.target.value || null)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phoneNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t("app.contact.phone")}</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      placeholder={t("app.contact.phone_placeholder")} 
                      value={field.value || ""}
                      onChange={(e) => field.onChange(e.target.value || null)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="isFavorite"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <FormLabel>{t("app.contact.favorite")}</FormLabel>
                    <FormDescription>
                      {t("app.contact.favorite_desc")}
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            <DialogFooter className="gap-2 sm:gap-0">
              <Button
                type="button"
                variant="outline"
                className="flex-1 sm:flex-none"
                onClick={handleImportContacts}
                disabled={isImporting || mutation.isPending}
              >
                {isImporting 
                  ? t("app.contact.importing") 
                  : t("app.contact.import")}
              </Button>
              <Button 
                type="submit" 
                className="flex-1 sm:flex-none"
                disabled={mutation.isPending}
              >
                {mutation.isPending 
                  ? t("app.contact.adding") 
                  : t("app.contact.add_button")}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}