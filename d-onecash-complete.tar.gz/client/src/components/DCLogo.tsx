import { SVGProps } from "react";

export function DCLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width="400"
      height="150"
      viewBox="0 0 400 150"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      {/* Círculo principal con patrón de puntos */}
      <g>
        <circle cx="70" cy="75" r="60" fill="#0AD678" fillOpacity="0.2" />
        <path
          d="M70 15C40 15 15 40 15 70C15 100 40 125 70 125V115C45 115 25 95 25 70C25 45 45 25 70 25V15Z"
          fill="#0AD678"
        />
        <path
          d="M70 15C100 15 125 40 125 70C125 80 120 90 115 95L105 85C110 80 115 75 115 70C115 45 95 25 70 25V15Z"
          fill="#0AD678"
        />
        
        {/* Patrón de puntos */}
        <g fill="#0AD678">
          {Array.from({ length: 10 }).map((_, i) => (
            <g key={`row-${i}`}>
              {Array.from({ length: 10 }).map((_, j) => (
                <circle 
                  key={`dot-${i}-${j}`}
                  cx={25 + i * 8} 
                  cy={30 + j * 8} 
                  r={2 - (i + j) * 0.1} 
                  opacity={1 - (i + j) * 0.08}
                />
              ))}
            </g>
          ))}
        </g>
      </g>
      
      {/* Texto D-OneCash */}
      <path
        d="M145 65H165C175 65 185 70 185 85C185 100 175 105 165 105H145V65ZM155 95H160C170 95 175 92.5 175 85C175 77.5 170 75 160 75H155V95Z"
        fill="#0AD678"
      />
      <path
        d="M190 85H195L200 105H190L190 85ZM190 82.5L192.5 65H197.5L200 82.5H190Z"
        fill="#0AD678"
      />
      <path
        d="M215 65C225 65 235 72.5 235 85C235 97.5 225 105 215 105C205 105 195 97.5 195 85C195 72.5 205 65 215 65ZM215 95C220 95 225 90 225 85C225 80 220 75 215 75C210 75 205 80 205 85C205 90 210 95 215 95Z"
        fill="#0AD678"
      />
      <path
        d="M240 65H250V75H255C265 75 275 77.5 275 90C275 102.5 265 105 255 105H240V65ZM250 95H255C260 95 265 92.5 265 90C265 87.5 260 85 255 85H250V95Z"
        fill="#0AD678"
      />
      <path
        d="M280 65H290V85C290 90 292.5 95 300 95C307.5 95 310 90 310 85V65H320V85C320 95 315 105 300 105C285 105 280 95 280 85V65Z"
        fill="#0AD678"
      />
      <path
        d="M325 65H345C353.5 65 360 70 360 77.5C360 82.5 357.5 85 352.5 87.5C357.5 90 360 95 360 97.5V105H350V97.5C350 95 347.5 92.5 345 92.5H335V105H325V65ZM335 82.5H345C347.5 82.5 350 80 350 77.5C350 75 347.5 72.5 345 72.5H335V82.5Z"
        fill="#0AD678"
      />
      <path
        d="M360 65H370L375 85L380 65H387.5L392.5 85L397.5 65H407.5L395 105H387.5L382.5 87.5L377.5 105H370L360 65Z"
        fill="#0AD678"
      />
      
      {/* Texto Finance For All */}
      <text x="200" y="125" fontSize="16" fill="#0AD678" textAnchor="middle">Finance For All</text>
    </svg>
  );
}