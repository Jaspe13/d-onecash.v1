import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { LogoVerde } from "@/lib/LogoVerde";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import MobileMenu from "@/components/MobileMenu";

export default function Header() {
  const [location, setLocation] = useLocation();
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);

  useEffect(() => {
    // Verificar si el usuario está autenticado al cargar el componente
    const checkAuth = () => {
      const user = localStorage.getItem('currentUser');
      setIsLoggedIn(!!user);
    };
    
    checkAuth();
    
    // Escuchar cambios en el localStorage (para cuando el usuario inicia o cierra sesión)
    window.addEventListener('storage', checkAuth);
    
    return () => {
      window.removeEventListener('storage', checkAuth);
    };
  }, []);
  
  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setIsLoggedIn(false);
    setLocation("/login");
  };

  // Solo mostrar el menú de navegación si el usuario está autenticado
  const showNavigation = isLoggedIn;

  return (
    <header className="px-4 py-3 flex items-center justify-between bg-secondary border-b border-accent">
      <div className="flex items-center gap-2">
        <div className="flex items-center" onClick={() => setLocation("/")} role="button" tabIndex={0}>
          <LogoVerde className="h-8 w-8" />
          <h1 className="ml-2 text-lg font-semibold text-foreground">D-OneCash</h1>
        </div>
      </div>
      
      {showNavigation && (
        <nav className="flex-1 max-w-md mx-8 hidden md:block">
          <ul className="flex gap-1 justify-center text-sm">
            <li>
              <button 
                onClick={() => setLocation("/")} 
                className={`px-4 py-1.5 rounded-md transition-colors ${location === "/" ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-accent/50"}`}
              >
                Dashboard
              </button>
            </li>
            <li>
              <button 
                onClick={() => setLocation("/wallet")} 
                className={`px-4 py-1.5 rounded-md transition-colors ${location === "/wallet" ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-accent/50"}`}
              >
                Wallet
              </button>
            </li>
            <li>
              <button 
                onClick={() => setLocation("/contacts")} 
                className={`px-4 py-1.5 rounded-md transition-colors ${location === "/contacts" ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-accent/50"}`}
              >
                Contacts
              </button>
            </li>
            <li>
              <button 
                onClick={() => setLocation("/stats")} 
                className={`px-4 py-1.5 rounded-md transition-colors ${location === "/stats" ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-accent/50"}`}
              >
                Stats
              </button>
            </li>

            {/* Sección de Trade (Crypto) eliminada según solicitud del usuario */}
            <li>
              <button 
                onClick={() => setLocation("/loans")} 
                className={`px-4 py-1.5 rounded-md transition-colors ${location === "/loans" ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-accent/50"}`}
              >
                Loans
              </button>
            </li>
            <li>
              <button 
                onClick={() => setLocation("/invest")} 
                className={`px-4 py-1.5 rounded-md transition-colors ${location === "/invest" ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-accent/50"}`}
              >
                Invest
              </button>
            </li>
            <li>
              <button 
                onClick={() => setLocation("/business")} 
                className={`px-4 py-1.5 rounded-md transition-colors ${location === "/business" ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-accent/50"}`}
              >
                Business
              </button>
            </li>
          </ul>
        </nav>
      )}
      
      <div className="flex items-center gap-3">
        {/* Botones de autenticación o perfil según el estado */}
        {isLoggedIn ? (
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-foreground/80 hidden sm:block">
              Welcome to D-OneCash
            </span>
            <MobileMenu />
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setLocation("/login")}
            >
              Log In
            </Button>
            <Button 
              variant="default" 
              size="sm" 
              onClick={() => setLocation("/register")}
            >
              Register
            </Button>
          </div>
        )}
      </div>
    </header>
  );
}
