import { useToast } from "@/hooks/use-toast";

export default function Notifications() {
  const { toast } = useToast();
  
  const handleClaimBonus = () => {
    toast({
      title: "Bonus Claimed",
      description: "You've successfully claimed your welcome bonus!",
      variant: "success",
    });
  };
  
  const handleViewStakingDetails = () => {
    toast({
      title: "Staking Plans",
      description: "This feature will be available in the next update.",
    });
  };
  
  return (
    <section className="px-4 mb-6">
      <h2 className="text-lg font-semibold mb-3">Notifications</h2>
      <div className="bg-secondary rounded-xl p-4">
        <div className="flex items-start mb-4">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3 mt-1 flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 12V8H6a2 2 0 1 1 0-4h14v4"></path>
              <path d="M20 12V8H6a2 2 0 1 1 0-4h14v4"></path>
              <path d="M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1"></path>
              <path d="M17 12H2"></path>
            </svg>
          </div>
          <div>
            <h3 className="text-sm font-medium mb-1">Welcome Bonus Available!</h3>
            <p className="text-xs text-muted-foreground">Complete your profile to receive 10 D1C tokens as a welcome bonus.</p>
            <button 
              className="mt-2 bg-primary hover:bg-primary/90 text-primary-foreground text-xs py-1.5 px-3 rounded-lg transition-colors"
              onClick={handleClaimBonus}
            >
              Claim Now
            </button>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="w-10 h-10 rounded-full bg-yellow-400/10 flex items-center justify-center mr-3 mt-1 flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
              <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"></path>
            </svg>
          </div>
          <div>
            <h3 className="text-sm font-medium mb-1">New Staking Plan Available</h3>
            <p className="text-xs text-muted-foreground">Check out our new 12-month staking plan with increased APY of 7.2%!</p>
            <button 
              className="mt-2 bg-secondary hover:bg-secondary/80 text-foreground text-xs py-1.5 px-3 rounded-lg transition-colors"
              onClick={handleViewStakingDetails}
            >
              View Details
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
