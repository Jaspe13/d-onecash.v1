import { useWallet } from "@/hooks/useWallet";
import { useState } from "react";
import SendMoneyModal from "./SendMoneyModal";
import QRCodeModal from "./QRCodeModal";

export default function WalletDashboard() {
  const { balance, walletAddress } = useWallet();
  const [sendModalOpen, setSendModalOpen] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [receiveModalOpen, setReceiveModalOpen] = useState(false);
  
  const handleSendClick = () => {
    setSendModalOpen(true);
  };
  
  const handleReceiveClick = () => {
    // Para recibir, mostramos el QR pero asegurándonos que esté en modo "generar"
    setQrModalOpen(true);
  };
  
  const handleQRClick = () => {
    setQrModalOpen(true);
  };
  
  return (
    <>
      <section className="p-4">
        <div className="wallet-card mb-6">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-sm font-medium text-muted-foreground">Total Balance</h2>
            <span className="text-xs px-2 py-1 bg-secondary text-primary rounded-full">D1C Wallet</span>
          </div>
          <div className="flex items-baseline">
            <span className="text-2xl font-semibold text-foreground" data-testid="wallet-balance">
              {new Intl.NumberFormat('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
              }).format(balance)}
            </span>
            <span className="ml-1 text-sm text-muted-foreground">USD</span>
          </div>
          <div className="mt-1">
            <span className="text-xs text-muted-foreground">
              ≈ {new Intl.NumberFormat('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
              }).format(balance)} D1C
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary ml-2">1 D1C = 1 USD</span>
          </div>
          
          <div className="grid grid-cols-3 gap-3 mt-6">
            <button 
              className="action-button"
              onClick={handleSendClick}
              aria-label="Send money"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
              <span className="text-xs">Send</span>
            </button>
            
            <button 
              className="action-button"
              onClick={handleQRClick}
              aria-label="QR Payment"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="6" height="6" x="3" y="3" rx="1"></rect>
                <rect width="6" height="6" x="15" y="3" rx="1"></rect>
                <rect width="6" height="6" x="3" y="15" rx="1"></rect>
                <rect width="6" height="6" x="15" y="15" rx="1"></rect>
              </svg>
              <span className="text-xs">QR Pay</span>
            </button>
            
            <button 
              className="action-button"
              onClick={handleReceiveClick}
              aria-label="Receive money"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="17 8 12 3 7 8"></polyline>
                <line x1="12" y1="3" x2="12" y2="15"></line>
              </svg>
              <span className="text-xs">Receive</span>
            </button>
          </div>
        </div>
      </section>
      
      {/* Modales */}
      <SendMoneyModal 
        isOpen={sendModalOpen} 
        onClose={() => setSendModalOpen(false)} 
      />
      
      <QRCodeModal
        isOpen={qrModalOpen || receiveModalOpen}
        onClose={() => {
          setQrModalOpen(false);
          setReceiveModalOpen(false);
        }}
      />
    </>
  );
}
