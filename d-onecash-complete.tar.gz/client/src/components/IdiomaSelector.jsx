import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

function IdiomaSelector() {
  const [idioma, setIdioma] = useState(() => {
    return localStorage.getItem("idioma") === "en" ? "en" : "es";
  });

  function cambiarIdioma(nuevoIdioma) {
    localStorage.setItem("idioma", nuevoIdioma);
    window.location.reload(); // Recargar la página para aplicar el cambio
  }

  return (
    <div className="flex gap-2 items-center">
      <Button 
        variant={idioma === "es" ? "default" : "outline"} 
        size="sm"
        onClick={() => cambiarIdioma("es")}
      >
        ES
      </Button>
      <Button 
        variant={idioma === "en" ? "default" : "outline"} 
        size="sm"
        onClick={() => cambiarIdioma("en")}
      >
        EN
      </Button>
    </div>
  );
}

export default IdiomaSelector;