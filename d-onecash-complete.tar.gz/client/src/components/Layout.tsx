import { ReactNode, useState } from "react";
import Header from "./Header";
import BottomNavigation from "./BottomNavigation";
import SendMoneyModal from "./SendMoneyModal";
import QRCodeModal from "./QRCodeModal";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [sendModalOpen, setSendModalOpen] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-background">
      <Header />
      
      <main className="flex-grow overflow-y-auto pb-16">
        {children}
      </main>
      
      <BottomNavigation 
        onSendClick={() => setSendModalOpen(true)}
        onQrClick={() => setQrModalOpen(true)}
      />
      
      <SendMoneyModal
        isOpen={sendModalOpen}
        onClose={() => setSendModalOpen(false)}
      />
      
      <QRCodeModal
        isOpen={qrModalOpen}
        onClose={() => setQrModalOpen(false)}
      />
    </div>
  );
}
