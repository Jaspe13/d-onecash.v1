import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { X, Menu, Home, Wallet, Users, Zap, CreditCard, ArrowRightLeft, LifeBuoy, Building2, User, Shield, Heart, Settings, ChevronDown, ChevronRight, ArrowLeft } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function MobileMenu() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  // Cerrar el menú al cambiar de ruta
  useEffect(() => {
    setOpen(false);
    setShowProfileMenu(false);
  }, [location]);

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    window.location.href = '/login';
  };

  const menuItems = [
    { path: "/", label: "Home", icon: <Home className="w-5 h-5 mr-2" /> },
    { path: "/wallet", label: "Wallet", icon: <Wallet className="w-5 h-5 mr-2" /> },
    { path: "/contacts", label: "Contacts", icon: <Users className="w-5 h-5 mr-2" /> },
    { path: "/heirs", label: "Heirs", icon: <Heart className="w-5 h-5 mr-2" /> },
    { path: "/loans", label: "Loans", icon: <Zap className="w-5 h-5 mr-2" /> },
    { path: "/cards", label: "Cards", icon: <CreditCard className="w-5 h-5 mr-2" /> },
    { path: "/invest", label: "Invest", icon: <ArrowRightLeft className="w-5 h-5 mr-2" /> },
    { path: "/business", label: "Business", icon: <Building2 className="w-5 h-5 mr-2" /> },
    { path: "/help", label: "Help & Support", icon: <LifeBuoy className="w-5 h-5 mr-2" /> },
  ];

  const profileItems = [
    { path: "/profile", label: "Profile", icon: <User className="w-4 h-4 mr-2" /> },
    { path: "/verification", label: "KYC", icon: <Shield className="w-4 h-4 mr-2" /> },
    { path: "/settings", label: "Settings", icon: <Settings className="w-4 h-4 mr-2" /> },
  ];

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-6 w-6 text-primary" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[280px] p-0">
        <div className="flex flex-col h-full">
          <div className="p-4 border-b">
            <div className="flex items-center">
              <Avatar className="h-10 w-10">
                <AvatarImage src="/avatar.png" alt="User" />
                <AvatarFallback>US</AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium">Usuario Demo</p>
                <p className="text-xs text-muted-foreground">demo@d-onecash.com</p>
              </div>
            </div>
          </div>
          <nav className="flex-1 overflow-auto p-2 space-y-1">
            {!showProfileMenu ? (
              <>
                {menuItems.map((item) => (
                  <Link
                    key={item.path}
                    href={item.path}
                    className={`flex items-center rounded-md px-3 py-2 text-sm transition-colors ${
                      location === item.path
                        ? "bg-accent text-accent-foreground"
                        : "hover:bg-accent/50 hover:text-accent-foreground"
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </Link>
                ))}
                
                {/* Profile Menu Trigger */}
                <button
                  onClick={() => setShowProfileMenu(true)}
                  className="flex items-center justify-between w-full rounded-md px-3 py-2 text-sm transition-colors hover:bg-accent/50 hover:text-accent-foreground"
                >
                  <div className="flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Profile & Settings
                  </div>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </>
            ) : (
              <>
                {/* Profile Sub-menu */}
                <div className="space-y-1">
                  <button
                    onClick={() => setShowProfileMenu(false)}
                    className="flex items-center w-full rounded-md px-3 py-2 text-sm transition-colors hover:bg-accent/50 hover:text-accent-foreground mb-4 border-b pb-3"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Main Menu
                  </button>
                  
                  <div className="space-y-1">
                    {profileItems.map((item) => (
                      <Link
                        key={item.path}
                        href={item.path}
                        className={`flex items-center rounded-md px-3 py-2 text-sm transition-colors ${
                          location === item.path
                            ? "bg-accent text-accent-foreground"
                            : "hover:bg-accent/50 hover:text-accent-foreground"
                        }`}
                      >
                        {item.icon}
                        {item.label}
                      </Link>
                    ))}
                  </div>
                </div>
              </>
            )}
          </nav>
          <div className="p-4 border-t">
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={handleLogout}
            >
              <X className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}