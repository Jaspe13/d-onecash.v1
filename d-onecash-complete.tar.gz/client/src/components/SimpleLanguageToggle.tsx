import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

// Función simple que guarda y recupera el idioma actual
const getLanguage = () => {
  return localStorage.getItem("app-lang") === "en" ? "en" : "es";
};

const setLanguage = (lang: "es" | "en") => {
  localStorage.setItem("app-lang", lang);
  window.location.reload();
};

export function SimpleLanguageToggle() {
  const [lang, setLang] = useState(getLanguage());

  return (
    <div className="flex gap-1">
      <Button
        variant={lang === "es" ? "default" : "outline"}
        size="sm"
        onClick={() => setLanguage("es")}
      >
        ES
      </Button>
      <Button
        variant={lang === "en" ? "default" : "outline"}
        size="sm"
        onClick={() => setLanguage("en")}
      >
        EN
      </Button>
    </div>
  );
}