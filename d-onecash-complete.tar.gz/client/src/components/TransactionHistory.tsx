import { useWallet } from "@/hooks/useWallet";
import { Transaction } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function TransactionHistory() {
  const { userId } = useWallet();

  const { data: transactions, isLoading } = useQuery({
    queryKey: [`/api/transactions/${userId}`],
    enabled: !!userId,
  });

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "send":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-destructive" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m5 12 14 0"></path>
            <path d="m12 5 7 7-7 7"></path>
          </svg>
        );
      case "receive":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m19 12-14 0"></path>
            <path d="m12 19-7-7 7-7"></path>
          </svg>
        );
      case "reward":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="22 10 12 2 2 10"></polyline>
            <polygon points="12 2 12 22 22 10 12 2"></polygon>
            <polygon points="12 2 12 22 2 10 12 2"></polygon>
          </svg>
        );
      case "card":
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect width="20" height="14" x="2" y="5" rx="2"></rect>
            <line x1="2" x2="22" y1="10" y2="10"></line>
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-muted-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" x2="12" y1="8" y2="12"></line>
            <line x1="12" x2="12.01" y1="16" y2="16"></line>
          </svg>
        );
    }
  };

  const getStatusStyle = (type: string) => {
    switch (type) {
      case "send":
        return "bg-destructive/10 text-destructive";
      case "receive":
        return "bg-primary/10 text-primary";
      case "reward":
        return "bg-yellow-400/10 text-yellow-400";
      default:
        return "bg-secondary text-muted-foreground";
    }
  };

  const getStatusText = (type: string) => {
    switch (type) {
      case "send":
        return "Sent";
      case "receive":
        return "Received";
      case "reward":
        return "Reward";
      case "card":
        return "Card";
      default:
        return "Completed";
    }
  };

  const formatAmount = (type: string, amount: number) => {
    const prefix = type === "send" || type === "card" ? "-" : "+";
    return `${prefix}$${amount.toFixed(2)}`;
  };

  const formatDate = (date: string) => {
    const txDate = new Date(date);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - txDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      const hours = txDate.getHours();
      const minutes = txDate.getMinutes();
      const ampm = hours >= 12 ? 'PM' : 'AM';
      const formattedHours = hours % 12 || 12;
      const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
      return `Today, ${formattedHours}:${formattedMinutes} ${ampm}`;
    } else if (diffDays === 1) {
      return "Yesterday";
    } else {
      return txDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  const renderTransactionItems = () => {
    if (isLoading) {
      return Array(4).fill(0).map((_, index) => (
        <div key={index} className="transaction-item">
          <div className="flex items-center">
            <Skeleton className="w-10 h-10 rounded-full mr-3" />
            <div className="flex-grow">
              <div className="flex justify-between">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-16" />
              </div>
              <div className="flex justify-between items-center mt-2">
                <Skeleton className="h-3 w-20" />
                <Skeleton className="h-3 w-14" />
              </div>
            </div>
          </div>
        </div>
      ));
    }

    if (!transactions || transactions.length === 0) {
      return (
        <div className="transaction-item flex flex-col items-center py-8">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-muted-foreground mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" x2="12" y1="8" y2="12"></line>
            <line x1="12" x2="12.01" y1="16" y2="16"></line>
          </svg>
          <p className="text-muted-foreground">No transactions yet</p>
        </div>
      );
    }

    return transactions.map((transaction: Transaction) => (
      <div key={transaction.id} className="transaction-item">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
            {getTransactionIcon(transaction.type)}
          </div>
          <div className="flex-grow">
            <div className="flex justify-between">
              <h3 className="text-sm font-medium">
                {transaction.type === "send" 
                  ? `Send to ${transaction.recipient}` 
                  : transaction.type === "receive" 
                    ? `Received from ${transaction.sender}` 
                    : transaction.type === "reward" 
                      ? "Staking Reward" 
                      : transaction.type === "card" 
                        ? "Virtual Card Top Up" 
                        : "Transaction"}
              </h3>
              <span 
                className={`text-sm font-mono font-medium ${transaction.type === "send" || transaction.type === "card" ? "text-destructive" : "text-primary"}`}
              >
                {formatAmount(transaction.type, transaction.amount)}
              </span>
            </div>
            <div className="flex justify-between items-center mt-1">
              <span className="text-xs text-muted-foreground">
                {formatDate(transaction.createdAt.toString())}
              </span>
              <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusStyle(transaction.type)}`}>
                {getStatusText(transaction.type)}
              </span>
            </div>
          </div>
        </div>
      </div>
    ));
  };

  return (
    <section className="px-4 mb-6">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-semibold">Recent Transactions</h2>
        <button className="text-xs text-primary">See All</button>
      </div>
      
      <div className="bg-secondary rounded-xl overflow-hidden">
        {renderTransactionItems()}
      </div>
    </section>
  );
}
