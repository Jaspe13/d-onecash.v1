import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { QRCode } from "@/components/ui/qr-code";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useWallet } from "@/hooks/useWallet";
import { useToast } from "@/hooks/use-toast";
import { GenerateQrInput } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function QRCodeModal({ isOpen, onClose }: QRCodeModalProps) {
  const { userId, walletAddress } = useWallet();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("generate");
  const [amount, setAmount] = useState("");
  const [qrValue, setQrValue] = useState(walletAddress);
  const [description, setDescription] = useState("Pago D-OneCash");
  const [qrGenerated, setQrGenerated] = useState(false);
  const [isLoadingCamera, setIsLoadingCamera] = useState(false);
  
  // Reset QR value when modal opens
  useEffect(() => {
    if (isOpen) {
      setQrValue(walletAddress);
      setQrGenerated(false);
    }
  }, [isOpen, walletAddress]);
  
  const { mutate, isPending } = useMutation({
    mutationFn: async (data: GenerateQrInput) => {
      const response = await apiRequest("POST", "/api/qrcode/generate", {
        ...data,
        userId,
      });
      return response.json();
    },
    onSuccess: (data) => {
      const qrData = {
        address: data.walletAddress,
        amount: amount ? parseFloat(amount) : undefined,
        description: description,
        date: new Date().toISOString()
      };
      setQrValue(JSON.stringify(qrData));
      setQrGenerated(true);
      toast({
        title: "Código QR Generado",
        description: "Tu código QR de pago ha sido generado exitosamente.",
        variant: "default",
      });
    },
    onError: (error: any) => {
      console.error("Error al generar QR:", error);
      toast({
        title: "Error al generar código QR",
        description: error.message || "Ocurrió un error inesperado",
        variant: "destructive",
      });
    },
  });
  
  const handleGenerateQR = () => {
    // Simular la generación de QR sin llamada al servidor
    // Esto es temporal hasta que arreglemos el backend
    const qrData = {
      address: walletAddress,
      amount: amount ? parseFloat(amount) : undefined,
      description: description,
      date: new Date().toISOString()
    };
    setQrValue(JSON.stringify(qrData));
    setQrGenerated(true);
    toast({
      title: "Código QR Generado",
      description: "Tu código QR de pago ha sido generado exitosamente.",
      variant: "default",
    });
    
    // También intentamos la llamada al API para dejar trazas en el backend
    try {
      mutate({
        amount: amount ? parseFloat(amount) : undefined,
        description: description || "Pago D-OneCash",
      });
    } catch (error) {
      console.error("Error en mutate:", error);
    }
  };
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(walletAddress).then(
      () => {
        toast({
          title: "Dirección Copiada",
          description: "Dirección de billetera copiada al portapapeles.",
          variant: "default",
        });
      },
      (err) => {
        toast({
          title: "Error al copiar",
          description: "No se pudo copiar la dirección al portapapeles.",
          variant: "destructive",
        });
      }
    );
  };
  
  const simulateScanQR = () => {
    setIsLoadingCamera(true);
    
    // Simulate camera access and QR scanning
    setTimeout(() => {
      setIsLoadingCamera(false);
      toast({
        title: "QR Escaneado",
        description: "Pago a Juan Pérez de 50 USDC detectado",
        variant: "default",
      });
      
      // Navigate to payment confirmation
      setTimeout(() => {
        toast({
          title: "Pago Confirmado",
          description: "Has enviado 50 USDC a Juan Pérez",
          variant: "default",
        });
        onClose();
      }, 1500);
    }, 2000);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-secondary text-foreground sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Pago con QR</DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="generate" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="generate">Generar</TabsTrigger>
            <TabsTrigger value="scan">Escanear</TabsTrigger>
          </TabsList>
          
          <TabsContent value="generate" className="mt-4">
            <div className="bg-white p-4 rounded-lg mx-auto w-64 h-64 flex items-center justify-center mb-5">
              <QRCode 
                value={qrValue || walletAddress} 
                size={200}
                bgColor="#ffffff"
                fgColor="#000000"
                level="M"
                includeMargin={false}
              />
            </div>
            
            <div className="text-center mb-5">
              <h3 className="text-sm font-medium mb-1">Tu Dirección de Pago</h3>
              <p className="text-xs text-muted-foreground bg-accent py-2 px-3 rounded-lg font-mono mb-2 overflow-hidden text-ellipsis">
                {walletAddress}
              </p>
              <Button 
                variant="secondary" 
                size="sm"
                onClick={copyToClipboard}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
                  <path d="M4 16V4a2 2 0 0 1 2-2h10"></path>
                </svg>
                Copiar Dirección
              </Button>
            </div>
            
            <div className="space-y-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">Monto (Opcional)</label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="0.00"
                    className="pl-16 pr-4"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">USDC</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Descripción</label>
                <Input
                  type="text"
                  placeholder="Descripción del pago"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
            </div>
            
            {qrGenerated && (
              <div className="mb-4 bg-primary/10 p-3 rounded-lg">
                <p className="text-sm text-center text-primary font-medium">
                  ¡Código QR generado con éxito!
                </p>
                <p className="text-xs text-center text-muted-foreground mt-1">
                  Comparte este código para recibir pagos
                </p>
              </div>
            )}
            
            <Button 
              className="w-full" 
              onClick={handleGenerateQR}
              disabled={isPending}
            >
              {isPending ? (
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-background" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 12a9 9 0 0 0-9-9 9 9 0 0 0-9 9 9 9 0 0 0 9 9 9 9 0 0 0 9-9Z"></path>
                  <path d="M13 12a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2"></path>
                  <path d="M12 7v5"></path>
                </svg>
              )}
              <span>{isPending ? "Generando..." : "Generar Nuevo QR"}</span>
            </Button>
          </TabsContent>
          
          <TabsContent value="scan" className="mt-4">
            {isLoadingCamera ? (
              <div className="bg-secondary p-8 rounded-lg flex flex-col items-center justify-center">
                <div className="animate-pulse">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-primary mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect width="6" height="6" x="3" y="3" rx="1"></rect>
                    <rect width="6" height="6" x="15" y="3" rx="1"></rect>
                    <rect width="6" height="6" x="3" y="15" rx="1"></rect>
                    <rect width="6" height="6" x="15" y="15" rx="1"></rect>
                  </svg>
                </div>
                <p className="text-center mb-4">
                  Accediendo a la cámara...
                </p>
                <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : (
              <div className="bg-secondary p-8 rounded-lg flex flex-col items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-muted-foreground mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="6" height="6" x="3" y="3" rx="1"></rect>
                  <rect width="6" height="6" x="15" y="3" rx="1"></rect>
                  <rect width="6" height="6" x="3" y="15" rx="1"></rect>
                  <rect width="6" height="6" x="15" y="15" rx="1"></rect>
                </svg>
                <p className="text-muted-foreground text-center mb-4">
                  Haz clic en "Escanear QR" para activar la cámara y escanear un código de pago.
                </p>
                <div className="space-y-2 w-full">
                  <Button className="w-full" onClick={simulateScanQR}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect width="6" height="6" x="3" y="3" rx="1"></rect>
                      <rect width="6" height="6" x="15" y="3" rx="1"></rect>
                      <rect width="6" height="6" x="3" y="15" rx="1"></rect>
                      <rect width="6" height="6" x="15" y="15" rx="1"></rect>
                    </svg>
                    Escanear QR
                  </Button>
                  <Button variant="secondary" className="w-full">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 7V4a2 2 0 0 1 2-2h8.5L20 7.5V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-3"></path>
                      <polyline points="14 2 14 8 20 8"></polyline>
                      <path d="M10 12H4"></path>
                      <path d="M10 16H4"></path>
                      <path d="M14 16h2"></path>
                      <path d="M7 12H8"></path>
                      <path d="M7 16H8"></path>
                    </svg>
                    Subir Imagen de QR
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
