import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useWallet } from "@/hooks/useWallet";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useState, useRef } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  CreditCard, 
  DollarSign, 
  Bitcoin, 
  Clock, 
  Zap, 
  Copy, 
  Check, 
  QrCode 
} from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface AddMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const formSchema = z.object({
  amount: z.string()
    .min(1, "Amount is required")
    .refine(val => !isNaN(parseFloat(val)), {
      message: "Must be a valid number",
    })
    .refine(val => parseFloat(val) > 0, {
      message: "Amount must be greater than 0",
    }),
  method: z.string().min(1, "Payment method is required"),
  cryptoType: z.string().optional(),
});

export default function AddMoneyModal({ isOpen, onClose }: AddMoneyModalProps) {
  const { userId } = useWallet();
  const { toast } = useToast();
  const [processingFee, setProcessingFee] = useState(0);
  const [total, setTotal] = useState(0);
  const [showCryptoOptions, setShowCryptoOptions] = useState(false);
  const [selectedCrypto, setSelectedCrypto] = useState("usdc");
  const [copied, setCopied] = useState(false);
  const walletAddressRef = useRef<HTMLInputElement>(null);
  
  // Wallet addresses for demo purposes
  const walletAddresses = {
    usdc: "0x4a8b3694c165d69e3e712f7809af845e9cb12c55",
    usdt: "0x8c17cf316c8a31b2e743cf8c5c18b41b83e527fa"
  };
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: "",
      method: "",
      cryptoType: "usdc",
    },
  });
  
  // Función para copiar la dirección de la wallet al portapapeles
  const copyToClipboard = async () => {
    if (walletAddressRef.current) {
      try {
        await navigator.clipboard.writeText(walletAddressRef.current.value);
        setCopied(true);
        
        // Restablecer el estado después de 2 segundos
        setTimeout(() => {
          setCopied(false);
        }, 2000);
        
        toast({
          title: "Dirección copiada",
          description: "La dirección ha sido copiada al portapapeles",
          variant: "default",
        });
      } catch (err) {
        console.error("No se pudo copiar al portapapeles:", err);
        toast({
          title: "Error al copiar",
          description: "No se pudo copiar la dirección al portapapeles",
          variant: "destructive",
        });
      }
    }
  };
  
  const { mutate, isPending } = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const response = await fetch("/api/wallet/add-funds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          amount: parseFloat(data.amount),
          method: data.method,
        }),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Funds added successfully",
        description: `${form.getValues().amount} USD has been added to your balance`,
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/wallet/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/transactions/${userId}`] });
      form.reset();
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error adding funds",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });
  
  const handleSubmit = (values: z.infer<typeof formSchema>) => {
    mutate(values);
  };
  
  // Estado para mostrar formulario de tarjeta
  const [showCardForm, setShowCardForm] = useState(false);
  
  // Calculate processing fee and total when amount or method changes
  const watchAmount = form.watch("amount");
  const watchMethod = form.watch("method");
  
  if (watchAmount && !isNaN(parseFloat(watchAmount))) {
    const amount = parseFloat(watchAmount);
    // Sin comisiones para ningún método de pago
    const fee = 0;
    
    if (processingFee !== fee) {
      setProcessingFee(fee);
      setTotal(amount + fee);
    }
  } else {
    if (processingFee !== 0) {
      setProcessingFee(0);
      setTotal(0);
    }
  }
  
  // Mostrar el formulario de tarjeta cuando se selecciona tarjeta
  if (watchMethod === "card" && !showCardForm) {
    setShowCardForm(true);
    setShowCryptoOptions(false);
  } else if (watchMethod !== "card" && showCardForm) {
    setShowCardForm(false);
  }
  
  // Mostrar opciones de criptomonedas cuando se selecciona crypto
  if (watchMethod === "crypto" && !showCryptoOptions) {
    setShowCryptoOptions(true);
    setShowCardForm(false);
  } else if (watchMethod !== "crypto" && showCryptoOptions) {
    setShowCryptoOptions(false);
  }
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-secondary text-foreground sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Funds</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Top up your D-OneCash balance using your preferred payment method.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <div className="relative">
                    <FormControl>
                      <Input 
                        type="text"
                        inputMode="decimal"
                        placeholder="0.00" 
                        className="pl-16" 
                        {...field} 
                      />
                    </FormControl>
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                      USD
                    </span>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    ≈ {watchAmount ? parseFloat(watchAmount).toFixed(2) : "0.00"} D1C
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="method"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Method</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a payment method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="card">
                        <div className="flex items-center">
                          <CreditCard className="w-4 h-4 mr-2" />
                          <span>Credit/Debit Card</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="bank">
                        <div className="flex items-center">
                          <DollarSign className="w-4 h-4 mr-2" />
                          <span>Bank Transfer</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="mercadopago">
                        <div className="flex items-center">
                          <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 2.182a9.818 9.818 0 1 1 0 19.636 9.818 9.818 0 0 1 0-19.636zm-2.4 5.304v7.2h1.371v-5.657h.086l2.057 5.657h1.6l2.056-5.657h.086v5.657h1.372v-7.2h-2.086l-2.142 5.914h-.086L7.686 7.486H5.6zm.857-1.715a.857.857 0 1 0 0-1.714.857.857 0 0 0 0 1.714zm4.8 0a.857.857 0 1 0 0-1.714.857.857 0 0 0 0 1.714z" />
                          </svg>
                          <span>Mercado Pago</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="paypal">
                        <div className="flex items-center">
                          <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="#00457C">
                            <path d="M7.016 18.5h-4.2c-.1 0-.2-.1-.2-.2l-.1-.4 2.8-17.8c0-.1.1-.2.3-.2h7.3c3.8 0 5.5 2 5.1 4.9-.5 3.5-2.7 5.4-6.1 5.4h-2.9c-.3 0-.4.1-.5.4l-.7 4.7c0 .1-.1.2-.2.2zm4.8-7.3c1.8 0 3.1-1.1 3.4-3.2.3-1.8-.8-3.2-2.7-3.2H9.624l-.8 5.2c0 .3.1.4.4.4 0 0 .576.8 2.6.8z"/>
                            <path d="M17.816 9.8c-.1-.1-.2-.1-.2-.1l-.4 2.7c0 .1-.1.2-.2.2h-1.4c-1.6 0-2.1-.7-1.9-2.2.2-1.3.8-2 1.9-2h.5c.1 0 .2-.1.2-.2l.4-2.5c0-.1.1-.2.2-.2h2c.1 0 .2.1.2.2l-.4 2.5c0 .1.1.2.2.2h1.1c.1 0 .2.1.2.2l-.3 1.8c0 .1-.1.2-.2.2h-1.1c-.1 0-.2.1-.2.2l-1.4 8.6c0 .1-.1.2-.2.2h-2c-.1 0-.2-.1-.2-.2l1.4-8.6c0-.1-.1-.2-.2-.2" fill="#00457C"/>
                          </svg>
                          <span>PayPal</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="stripe">
                        <div className="flex items-center">
                          <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="#635BFF">
                            <path d="M13.479 9.883c-1.626-.604-2.512-.996-2.512-1.676 0-.583.583-.828 1.318-.828 1.54 0 3.12.647 4.255 1.225l.626-3.87c-.868-.39-2.67-1.02-5.096-1.02-1.738 0-3.184.453-4.2 1.284-1.063.868-1.6 2.107-1.6 3.616 0 2.713 1.66 3.842 4.373 4.794 1.74.626 2.33 1.07 2.33 1.74 0 .69-.583 1.03-1.59 1.03-1.266 0-3.36-.646-4.77-1.5l-.608 3.916c1.17.713 3.322 1.353 5.58 1.353 1.847 0 3.38-.388 4.373-1.188 1.115-.9 1.696-2.2 1.696-3.872 0-2.773-1.696-3.903-4.174-4.855zm6.287-1.324h-2.922l.052-.313c.268-1.74.952-3.184 2.18-3.184.996 0 1.37.8 1.37 1.676 0 .695-.26 1.373-.68 1.82zm1.875-4.563c-.567-.455-1.42-.713-2.538-.713-1.226 0-2.304.36-3.217 1.038-1.37 1.03-2.24 2.57-2.607 4.238h-1.868l-.673 4.16h1.868l-1.768 10.988h4.793l1.77-10.988h3.043l.673-4.16h-3.043l.052-.313c.156-.972.583-1.16 1.45-1.16.495 0 .9.057 1.212.156l.85-3.247z"/>
                          </svg>
                          <span>Stripe</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="crypto">
                        <div className="flex items-center">
                          <Bitcoin className="w-4 h-4 mr-2" />
                          <span>Cryptocurrency Deposit</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Formulario de tarjeta de crédito */}
            {showCardForm && (
              <div className="space-y-4 mt-2 mb-4 p-3 border border-input rounded-md bg-background/50">
                <h3 className="text-sm font-medium mb-2">Datos de la Tarjeta</h3>
                
                <FormField
                  name="cardNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Número de Tarjeta</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="1234 5678 9012 3456"
                          className="font-mono"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    name="cardExpiry"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fecha de Expiración</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="MM/YY"
                            className="font-mono"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    name="cardCvv"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>CVV</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="123"
                            className="font-mono"
                            type="password"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  name="cardName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre del Titular</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="NOMBRE APELLIDO"
                          className="uppercase"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            )}
            
            {/* Opciones de Criptomonedas */}
            {showCryptoOptions && (
              <div className="space-y-4 mt-2 mb-4 p-3 border border-input rounded-md bg-background/50">
                <h3 className="text-sm font-medium mb-2">Selecciona una Criptomoneda</h3>
                
                <FormField
                  name="cryptoType"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormControl>
                        <RadioGroup
                          onValueChange={(value) => {
                            field.onChange(value);
                            setSelectedCrypto(value);
                          }}
                          defaultValue={field.value}
                          className="flex flex-col space-y-1"
                        >
                          <div className="flex items-center space-x-2 border border-input p-2 rounded-md">
                            <RadioGroupItem value="usdc" id="usdc" />
                            <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-xs">
                              $
                            </div>
                            <label htmlFor="usdc" className="font-medium cursor-pointer">
                              USDC
                            </label>
                            <span className="text-xs text-muted-foreground ml-auto">
                              Ethereum
                            </span>
                          </div>
                          <div className="flex items-center space-x-2 border border-input p-2 rounded-md">
                            <RadioGroupItem value="usdt" id="usdt" />
                            <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold text-xs">
                              $
                            </div>
                            <label htmlFor="usdt" className="font-medium cursor-pointer">
                              USDT
                            </label>
                            <span className="text-xs text-muted-foreground ml-auto">
                              Ethereum
                            </span>
                          </div>
                        </RadioGroup>
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <div className="mt-4 pt-4 border-t border-border">
                  <div className="flex justify-center">
                    <div className="p-3 border border-input bg-white rounded-md mb-3">
                      <div className="h-40 w-40 flex items-center justify-center bg-accent/10 relative">
                        <QrCode className="h-24 w-24 text-black" />
                        <div className="absolute inset-0 flex items-center justify-center bg-accent/80 text-foreground text-xs font-medium p-2 text-center">
                          QR para pago con {selectedCrypto.toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col space-y-2">
                    <div className="text-sm font-medium">Dirección de Depósito</div>
                    <div className="flex space-x-1">
                      <Input
                        ref={walletAddressRef}
                        readOnly
                        value={walletAddresses[selectedCrypto as keyof typeof walletAddresses]}
                        className="font-mono text-xs"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={copyToClipboard}
                        className="flex-shrink-0"
                      >
                        {copied ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-amber-600 mt-1">
                      <span className="font-medium">Importante:</span> Solo envía {selectedCrypto.toUpperCase()} a esta dirección. El depósito se acreditará después de 1 confirmación de red.
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      La tarifa de red varía según la congestión de la blockchain y se deducirá del monto enviado.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {watchAmount && watchMethod && (
              <div className="bg-accent rounded-lg p-3">
                <div className="flex justify-between text-sm mb-2">
                  <span>Monto</span>
                  <span className="font-mono">
                    {watchAmount ? parseFloat(watchAmount).toFixed(2) : "0.00"} USD
                  </span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Comisión de procesamiento</span>
                  <span className="font-mono">{processingFee.toFixed(2)} USD</span>
                </div>
                <div className="border-t border-secondary my-2"></div>
                <div className="flex justify-between text-sm font-medium">
                  <span>Total a pagar</span>
                  <span className="font-mono">{total.toFixed(2)} USD</span>
                </div>
                {watchMethod === "bank" && (
                  <div className="mt-3 text-xs text-amber-600 bg-amber-100 p-2 rounded-sm">
                    <Clock className="h-3 w-3 inline-block mr-1" />
                    Los fondos estarán disponibles en 24-48 horas hábiles
                  </div>
                )}
                {(watchMethod === "paypal" || watchMethod === "mercadopago" || watchMethod === "stripe" || watchMethod === "crypto") && (
                  <div className="mt-3 text-xs text-green-600 bg-green-100 p-2 rounded-sm">
                    <Zap className="h-3 w-3 inline-block mr-1" />
                    Los fondos estarán disponibles instantáneamente
                  </div>
                )}
                {watchMethod === "card" && (
                  <div className="mt-3 text-xs text-green-600 bg-green-100 p-2 rounded-sm">
                    <Zap className="h-3 w-3 inline-block mr-1" />
                    Los fondos estarán disponibles instantáneamente
                  </div>
                )}
              </div>
            )}
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isPending}
            >
              {isPending ? (
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-background" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : null}
              <span>{isPending ? "Procesando..." : "Añadir Fondos"}</span>
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}