import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useWallet } from "@/hooks/useWallet";
import { SendMoneyInput } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useState } from "react";
import SuccessAnimation from "@/components/SuccessAnimation";

interface SendMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Contact {
  id: string;
  name: string;
  email: string;
}

const formSchema = z.object({
  recipient: z.string().min(1, "Recipient is required"),
  amount: z.string()
    .min(1, "Amount is required")
    .refine(val => !isNaN(parseFloat(val)), {
      message: "Must be a valid number",
    })
    .refine(val => parseFloat(val) > 0, {
      message: "Amount must be greater than 0",
    }),
  note: z.string().optional(),
});

export default function SendMoneyModal({ isOpen, onClose }: SendMoneyModalProps) {
  const { userId, balance } = useWallet();
  const { toast } = useToast();
  const [fee, setFee] = useState(0);
  const [total, setTotal] = useState(0);
  const [showContacts, setShowContacts] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successData, setSuccessData] = useState({ recipient: "", amount: "" });
  
  // Mock contacts for demo purposes
  const contacts: Contact[] = [
    { id: "1", name: "María García", email: "maria@example.com" },
    { id: "2", name: "Juan Pérez", email: "juan@example.com" },
    { id: "3", name: "Ana Rodríguez", email: "ana@example.com" },
    { id: "4", name: "Carlos López", email: "carlos@example.com" },
    { id: "5", name: "Sofia Martínez", email: "sofia@example.com" },
  ];
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      recipient: "",
      amount: "",
      note: "",
    },
  });
  
  const { mutate, isPending } = useMutation({
    mutationFn: async (data: SendMoneyInput) => {
      const response = await fetch("/api/transactions/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...data,
          userId,
          amount: parseFloat(data.amount as unknown as string),
        }),
      });
      return response.json();
    },
    onSuccess: () => {
      // Guardar datos para mostrar en la animación de éxito
      setSuccessData({
        recipient: form.getValues().recipient,
        amount: form.getValues().amount
      });
      
      // Mostrar animación de éxito en lugar del toast
      setShowSuccess(true);
      
      // Actualizar datos
      queryClient.invalidateQueries({ queryKey: [`/api/wallet/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/transactions/${userId}`] });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error sending money",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });
  
  const handleSubmit = (values: z.infer<typeof formSchema>) => {
    const amount = parseFloat(values.amount);
    // Calcular comisión según el nuevo esquema:
    // - 2% para montos entre $0.01-$100
    // - $3.50 fijo para montos mayores a $100
    const calculatedFee = amount <= 100 ? amount * 0.02 : 3.50;
    const totalAmount = amount + calculatedFee;
    
    if (totalAmount > balance) {
      form.setError("amount", {
        type: "manual",
        message: "Fondos insuficientes",
      });
      return;
    }
    
    mutate({
      recipient: values.recipient,
      amount,
      note: values.note,
    });
  };
  
  // Calculate fee and total when amount changes
  const watchAmount = form.watch("amount");
  
  if (watchAmount && !isNaN(parseFloat(watchAmount))) {
    const amount = parseFloat(watchAmount);
    // Calcular comisión según el mismo esquema:
    // - 2% para montos entre $0.01-$100
    // - $3.50 fijo para montos mayores a $100
    const calculatedFee = amount <= 100 ? amount * 0.02 : 3.50;
    if (fee !== calculatedFee) {
      setFee(calculatedFee);
      setTotal(amount + calculatedFee);
    }
  } else {
    if (fee !== 0) {
      setFee(0);
      setTotal(0);
    }
  }
  
  const handleMaxClick = () => {
    const maxAmount = Math.max(0, (balance - balance * 0.01)).toFixed(2);
    form.setValue("amount", maxAmount);
  };
  
  const handleSelectContact = (contact: Contact) => {
    form.setValue("recipient", contact.email);
    setShowContacts(false);
  };
  
  // Función para cerrar la animación de éxito
  const handleSuccessClose = () => {
    setShowSuccess(false);
    onClose();
  };

  return (
    <>
      {/* Animación de operación exitosa */}
      {showSuccess && (
        <SuccessAnimation
          title="¡Transferencia Exitosa!"
          message={`Has enviado ${successData.amount} USDC a ${successData.recipient} correctamente.`}
          onClose={handleSuccessClose}
        />
      )}
    
      <Dialog open={isOpen && !showSuccess} onOpenChange={onClose}>
        <DialogContent className="bg-secondary text-foreground sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Send Money</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Send money to another D-OneCash user.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="recipient"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recipient</FormLabel>
                  <div className="flex">
                    <FormControl>
                      <Input 
                        placeholder="Email or username" 
                        className="rounded-l-lg" 
                        {...field} 
                      />
                    </FormControl>
                    <Button 
                      type="button" 
                      variant="secondary"
                      className="rounded-l-none"
                      onClick={() => setShowContacts(!showContacts)}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                      </svg>
                    </Button>
                  </div>
                  
                  {showContacts && (
                    <div className="mt-2 max-h-40 overflow-y-auto bg-background rounded-md border border-input">
                      {contacts.map(contact => (
                        <div 
                          key={contact.id} 
                          className="p-2 hover:bg-secondary cursor-pointer flex items-center"
                          onClick={() => handleSelectContact(contact)}
                        >
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-2">
                            <span className="text-primary text-sm font-medium">{contact.name.charAt(0)}</span>
                          </div>
                          <div>
                            <p className="text-sm font-medium">{contact.name}</p>
                            <p className="text-xs text-muted-foreground">{contact.email}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <div className="relative">
                    <FormControl>
                      <Input 
                        type="text"
                        inputMode="decimal"
                        placeholder="0.00" 
                        className="pl-16 pr-20" 
                        {...field} 
                      />
                    </FormControl>
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                      USD
                    </span>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2">
                      <Button 
                        type="button"
                        variant="secondary"
                        size="sm"
                        onClick={handleMaxClick}
                        className="h-7 text-xs"
                      >
                        Max
                      </Button>
                    </div>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    ≈ {watchAmount ? parseFloat(watchAmount).toFixed(2) : "0.00"} D1C
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="note"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Note (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="What is this for?" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="bg-accent rounded-lg p-3">
              <div className="flex justify-between text-sm mb-2">
                <span>Amount</span>
                <span className="font-mono">
                  {watchAmount ? parseFloat(watchAmount).toFixed(2) : "0.00"} USDC
                </span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span>Comisión aplicada</span>
                <span className="font-mono">{fee.toFixed(2)} USDC</span>
              </div>
              <div className="border-t border-secondary my-2"></div>
              <div className="flex justify-between text-sm font-medium">
                <span>Total</span>
                <span className="font-mono">{total.toFixed(2)} USDC</span>
              </div>
            </div>
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isPending}
            >
              {isPending ? (
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-background" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                <svg className="mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"></line>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
              )}
              <span>{isPending ? "Sending..." : "Send Money"}</span>
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
    </>
  );
}
