import { createContext, useState, useContext, useEffect, ReactNode } from 'react';

// Definimos los tipos de idiomas disponibles
type Language = 'es' | 'en';

// Interfaz para el contexto de traducción
interface TranslationContextType {
  language: Language;
  t: (key: string) => string;
  changeLanguage: (lang: Language) => void;
}

// Creamos el contexto
const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

// Diccionarios de traducción
const translations: Record<Language, Record<string, string>> = {
  es: {
    // Menú principal
    'menu.dashboard': 'Inicio',
    'menu.wallet': 'Billetera',
    'menu.stats': 'Estadísticas',
    'menu.contacts': 'Contactos',
    'menu.verification': 'KYC',
    'menu.loans': 'Préstamos',
    'menu.settings': 'Configuración',
    
    // Auth
    'auth.login': 'Iniciar Sesión',
    'auth.register': 'Registrarse',
    'auth.logout': 'Cerrar Sesión',
    'auth.profile': 'Perfil',
    'auth.welcome': 'Bienvenido de nuevo',
    'auth.credentials': 'Ingresa tus credenciales para acceder',
    'auth.email': 'Correo electrónico',
    'auth.password': 'Contraseña',
    'auth.email.placeholder': 'tucorreo@ejemplo.com',
    'auth.password.placeholder': 'Tu contraseña',
    'auth.submit': 'Iniciar Sesión',
    'auth.faceid': 'Iniciar con Face ID',
    'auth.or': 'O',
    'auth.register.link': '¿No tienes cuenta? Regístrate',
    
    // Registro
    'register.title': 'Crear cuenta',
    'register.subtitle': 'Ingresa tus datos para registrarte',
    'register.name': 'Nombre completo',
    'register.name.placeholder': 'Tu nombre completo',
    'register.submit': 'Registrarse',
    'register.login.link': '¿Ya tienes cuenta? Inicia sesión',
    
    // Face ID
    'faceid.title': 'Autenticación con Face ID',
    'faceid.start': 'Iniciar escáner',
    'faceid.scanning': 'Escaneando...',
    
    // Wallet
    'wallet.title': 'Mi Billetera',
    'wallet.balance': 'Saldo disponible',
    'wallet.send': 'Enviar',
    'wallet.receive': 'Recibir',
    'wallet.history': 'Historial de transacciones',
    
    // Contactos
    'contacts.title': 'Mis Contactos',
    'contacts.search': 'Buscar contactos',
    'contacts.add': 'Agregar contacto',
    'contacts.empty': 'No tienes contactos aún',
    'contacts.favorites': 'Favoritos',
    'contacts.all': 'Todos los contactos',
    
    // Préstamos
    'loans.title': 'Préstamos USDC con Colateral BTC',
    'loans.description': 'Solicita préstamos en USDC utilizando Bitcoin como garantía',
    'loans.ltv': 'LTV máximo: 50%',
    'loans.interest': 'Interés anual: 6%',
    'loans.amount': 'Monto del préstamo',
    'loans.collateral': 'Colateral (BTC)',
    'loans.apply': 'Solicitar préstamo',
    
    // KYC
    'kyc.title': 'Verificación de Identidad',
    'kyc.description': 'Sube tus documentos para verificar tu identidad',
    'kyc.step1': 'Información personal',
    'kyc.step2': 'Documento de identidad',
    'kyc.step3': 'Verificación facial',
    'kyc.complete': 'Verificación completa',
    
    // General
    'general.loading': 'Cargando...',
    'general.error': 'Ha ocurrido un error',
    'general.success': 'Operación exitosa',
    'general.cancel': 'Cancelar',
    'general.save': 'Guardar',
    'general.delete': 'Eliminar',
    'general.edit': 'Editar',
    'general.confirm': 'Confirmar',
  },
  en: {
    // Menú principal
    'menu.dashboard': 'Dashboard',
    'menu.wallet': 'Wallet',
    'menu.stats': 'Statistics',
    'menu.contacts': 'Contacts',
    'menu.verification': 'KYC',
    'menu.loans': 'Loans',
    'menu.settings': 'Settings',
    
    // Auth
    'auth.login': 'Sign In',
    'auth.register': 'Register',
    'auth.logout': 'Log Out',
    'auth.profile': 'Profile',
    'auth.welcome': 'Welcome Back',
    'auth.credentials': 'Enter your credentials to access',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.email.placeholder': 'your@email.com',
    'auth.password.placeholder': 'Your password',
    'auth.submit': 'Sign In',
    'auth.faceid': 'Sign In with Face ID',
    'auth.or': 'Or',
    'auth.register.link': 'Don\'t have an account? Register',
    
    // Registro
    'register.title': 'Create Account',
    'register.subtitle': 'Enter your details to register',
    'register.name': 'Full Name',
    'register.name.placeholder': 'Your full name',
    'register.submit': 'Register',
    'register.login.link': 'Already have an account? Sign in',
    
    // Face ID
    'faceid.title': 'Face ID Authentication',
    'faceid.start': 'Start Scanner',
    'faceid.scanning': 'Scanning...',
    
    // Wallet
    'wallet.title': 'My Wallet',
    'wallet.balance': 'Available Balance',
    'wallet.send': 'Send',
    'wallet.receive': 'Receive',
    'wallet.history': 'Transaction History',
    
    // Contactos
    'contacts.title': 'My Contacts',
    'contacts.search': 'Search contacts',
    'contacts.add': 'Add contact',
    'contacts.empty': 'You don\'t have any contacts yet',
    'contacts.favorites': 'Favorites',
    'contacts.all': 'All Contacts',
    
    // Préstamos
    'loans.title': 'USDC Loans with BTC Collateral',
    'loans.description': 'Request loans in USDC using Bitcoin as collateral',
    'loans.ltv': 'Maximum LTV: 50%',
    'loans.interest': 'Annual interest: 6%',
    'loans.amount': 'Loan amount',
    'loans.collateral': 'Collateral (BTC)',
    'loans.apply': 'Apply for loan',
    
    // KYC
    'kyc.title': 'Identity Verification',
    'kyc.description': 'Upload your documents to verify your identity',
    'kyc.step1': 'Personal Information',
    'kyc.step2': 'Identity Document',
    'kyc.step3': 'Facial Verification',
    'kyc.complete': 'Verification Complete',
    
    // General
    'general.loading': 'Loading...',
    'general.error': 'An error has occurred',
    'general.success': 'Operation successful',
    'general.cancel': 'Cancel',
    'general.save': 'Save',
    'general.delete': 'Delete',
    'general.edit': 'Edit',
    'general.confirm': 'Confirm',
  }
};

// Proveedor del contexto de traducción
export function TranslationProvider({ children }: { children: ReactNode }) {
  // Obtener el idioma guardado en localStorage o usar español por defecto
  const [language, setLanguage] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('d1c-language');
    return (savedLanguage === 'en' ? 'en' : 'es') as Language;
  });

  // Función para cambiar el idioma
  const changeLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('d1c-language', lang);
  };

  // Función para obtener una traducción
  const t = (key: string): string => {
    if (translations[language] && translations[language][key]) {
      return translations[language][key];
    }
    // Si no existe la traducción, mostrar el key como fallback
    return key;
  };

  // Exportar el contexto con los valores
  return (
    <TranslationContext.Provider value={{ language, t, changeLanguage }}>
      {children}
    </TranslationContext.Provider>
  );
}

// Hook personalizado para usar las traducciones
export function useTranslation() {
  const context = useContext(TranslationContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
}

// Componente selector de idioma
export function LanguageSelector() {
  const { language, changeLanguage } = useTranslation();
  
  return (
    <div className="flex items-center gap-1">
      <button
        onClick={() => changeLanguage('es')}
        className={`px-2 py-1 rounded-md text-sm font-medium ${
          language === 'es' 
            ? 'bg-primary text-white' 
            : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
        }`}
      >
        ES
      </button>
      <button
        onClick={() => changeLanguage('en')}
        className={`px-2 py-1 rounded-md text-sm font-medium ${
          language === 'en' 
            ? 'bg-primary text-white' 
            : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
        }`}
      >
        EN
      </button>
    </div>
  );
}