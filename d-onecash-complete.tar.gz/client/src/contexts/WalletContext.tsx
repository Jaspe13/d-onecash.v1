import { createContext, ReactNode, useEffect, useState } from "react";
import { User, Wallet } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface WalletContextProps {
  userId: number;
  balance: number;
  walletAddress: string;
  userData: User | null;
  isLoading: boolean;
  error: Error | null;
  refreshWallet: () => void;
}

export const WalletContext = createContext<WalletContextProps>({
  userId: 1, // Default user ID for the demo user
  balance: 0,
  walletAddress: "",
  userData: null,
  isLoading: false,
  error: null,
  refreshWallet: () => {},
});

interface WalletProviderProps {
  children: ReactNode;
}

export function WalletProvider({ children }: WalletProviderProps) {
  // In a real app, you would get the user ID from authentication
  // For the MVP, we'll use the demo user with ID 1
  const userId = 1;

  const {
    data: userData,
    isLoading: isUserLoading,
    error: userError,
    refetch: refetchUser,
  } = useQuery<User>({
    queryKey: [`/api/user/${userId}`],
    enabled: !!userId,
  });

  const {
    data: walletData,
    isLoading: isWalletLoading,
    error: walletError,
    refetch: refetchWallet,
  } = useQuery<Wallet>({
    queryKey: [`/api/wallet/${userId}`],
    enabled: !!userId,
  });

  const refreshWallet = () => {
    refetchUser();
    refetchWallet();
  };

  // If wallet data is not available yet, use default values from storage.ts
  const balance = walletData?.balance ?? 3428.65;
  const walletAddress = userData?.walletAddress ?? "d1c:0x7F5E8c21A53dE856DBC4a0a25E0C98d06Dff303C";
  
  const isLoading = isUserLoading || isWalletLoading;
  const error = userError || walletError;

  return (
    <WalletContext.Provider
      value={{
        userId,
        balance,
        walletAddress,
        userData: userData || null,
        isLoading,
        error: error as Error | null,
        refreshWallet,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}
