import { Helmet } from "react-helmet";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  Building2, 
  CreditCard, 
  Smartphone, 
  CheckCircle2, 
  Clock, 
  DollarSign,
  Shield,
  Zap,
  Users,
  TrendingUp
} from "lucide-react";

export default function Business() {
  const { toast } = useToast();
  const [hasBusinessAccount, setHasBusinessAccount] = useState(false);
  const [applicationStatus, setApplicationStatus] = useState<'none' | 'pending' | 'approved'>('none');
  
  // Estados del formulario de solicitud
  const [formData, setFormData] = useState({
    businessName: "",
    businessType: "",
    taxId: "",
    address: "",
    city: "",
    postalCode: "",
    country: "España",
    phone: "",
    email: "",
    website: "",
    monthlyVolume: "",
    description: "",
    contactName: "",
    contactPosition: ""
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmitApplication = () => {
    // Validar campos requeridos
    const requiredFields = ['businessName', 'businessType', 'taxId', 'address', 'city', 'phone', 'email', 'contactName'];
    const missingFields = requiredFields.filter(field => !formData[field as keyof typeof formData]);
    
    if (missingFields.length > 0) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    // Simular envío de solicitud
    setApplicationStatus('pending');
    toast({
      title: "Solicitud enviada",
      description: "Tu solicitud de cuenta empresarial está siendo revisada. Te contactaremos en 24-48 horas.",
    });
  };

  const handleApproveDemo = () => {
    setApplicationStatus('approved');
    setHasBusinessAccount(true);
    toast({
      title: "¡Cuenta aprobada!",
      description: "Tu cuenta empresarial ha sido activada. Ya puedes procesar pagos.",
    });
  };

  if (!hasBusinessAccount && applicationStatus === 'none') {
    return (
      <>
        <Helmet>
          <title>D-OneCash Business | Soluciones para Empresas</title>
          <meta name="description" content="Acepta pagos con tarjeta, contactless y transferencias con D-OneCash Business" />
        </Helmet>
        
        <div className="container mx-auto px-4 py-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold mb-4">D-OneCash Business</h1>
              <p className="text-lg text-muted-foreground">
                Accept payments from your customers with the most advanced technology
              </p>
            </div>

            {/* Características principales */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader className="text-center">
                  <Smartphone className="h-12 w-12 text-primary mx-auto mb-2" />
                  <CardTitle>Contactless Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    Accept payments by simply tapping the card to your mobile device
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <CreditCard className="h-12 w-12 text-primary mx-auto mb-2" />
                  <CardTitle>Virtual POS</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    Process card payments securely from your mobile device
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <DollarSign className="h-12 w-12 text-primary mx-auto mb-2" />
                  <CardTitle>Special Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    Reduced commissions for verified businesses
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Formulario de solicitud */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Apply for Business Account
                </CardTitle>
                <CardDescription>
                  Complete your business information to activate enterprise features
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="businessName">Business Name *</Label>
                    <Input
                      id="businessName"
                      value={formData.businessName}
                      onChange={(e) => handleInputChange('businessName', e.target.value)}
                      placeholder="Ex: The Good Taste Restaurant"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="businessType">Business Type *</Label>
                    <Select value={formData.businessType} onValueChange={(value) => handleInputChange('businessType', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="restaurant">Restaurant</SelectItem>
                        <SelectItem value="retail">Retail/Store</SelectItem>
                        <SelectItem value="services">Services</SelectItem>
                        <SelectItem value="hotel">Hotel/Accommodation</SelectItem>
                        <SelectItem value="healthcare">Healthcare</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="taxId">Tax ID *</Label>
                    <Input
                      id="taxId"
                      value={formData.taxId}
                      onChange={(e) => handleInputChange('taxId', e.target.value)}
                      placeholder="Ex: B12345678"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone *</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="Ex: +1 555 123 456"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address *</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    placeholder="Street, number, floor"
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">City *</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => handleInputChange('city', e.target.value)}
                      placeholder="Ex: New York"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="postalCode">Postal Code</Label>
                    <Input
                      id="postalCode"
                      value={formData.postalCode}
                      onChange={(e) => handleInputChange('postalCode', e.target.value)}
                      placeholder="Ex: 10001"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="country">Country</Label>
                    <Select value={formData.country} onValueChange={(value) => handleInputChange('country', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="United States">United States</SelectItem>
                        <SelectItem value="Mexico">Mexico</SelectItem>
                        <SelectItem value="Colombia">Colombia</SelectItem>
                        <SelectItem value="Argentina">Argentina</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="contacto@empresa.com"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="website">Website</Label>
                    <Input
                      id="website"
                      value={formData.website}
                      onChange={(e) => handleInputChange('website', e.target.value)}
                      placeholder="https://www.company.com"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="contactName">Contact Name *</Label>
                    <Input
                      id="contactName"
                      value={formData.contactName}
                      onChange={(e) => handleInputChange('contactName', e.target.value)}
                      placeholder="First and last name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="contactPosition">Position</Label>
                    <Input
                      id="contactPosition"
                      value={formData.contactPosition}
                      onChange={(e) => handleInputChange('contactPosition', e.target.value)}
                      placeholder="Ex: Manager, Owner"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="monthlyVolume">Estimated Monthly Volume</Label>
                  <Select value={formData.monthlyVolume} onValueChange={(value) => handleInputChange('monthlyVolume', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0-1000">$0 - $1,000 USD</SelectItem>
                      <SelectItem value="1000-5000">$1,000 - $5,000 USD</SelectItem>
                      <SelectItem value="5000-10000">$5,000 - $10,000 USD</SelectItem>
                      <SelectItem value="10000-25000">$10,000 - $25,000 USD</SelectItem>
                      <SelectItem value="25000+">More than $25,000 USD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Business Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Briefly describe your business and the products/services you offer"
                    rows={3}
                  />
                </div>

                <div className="flex gap-3">
                  <Button onClick={handleSubmitApplication} className="flex-1">
                    Submit Application
                  </Button>
                  <Button variant="outline" onClick={handleApproveDemo} className="text-xs">
                    Demo: Approve
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </>
    );
  }

  if (applicationStatus === 'pending') {
    return (
      <>
        <Helmet>
          <title>Application in Process | D-OneCash Business</title>
        </Helmet>
        
        <div className="container mx-auto px-4 py-6">
          <div className="max-w-2xl mx-auto text-center">
            <Clock className="h-16 w-16 text-primary mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-4">Application in Process</h1>
            <p className="text-muted-foreground mb-6">
              Your business account application is being reviewed by our team.
              We will contact you within the next 24-48 hours.
            </p>
            
            <Alert>
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>
                You will receive a confirmation email when your account is approved.
              </AlertDescription>
            </Alert>
            
            <Button variant="outline" onClick={handleApproveDemo} className="mt-4">
              Demo: Approve Account
            </Button>
          </div>
        </div>
      </>
    );
  }

  // Vista principal para cuentas empresariales aprobadas
  return (
    <>
      <Helmet>
        <title>POS & Payments | D-OneCash Business</title>
        <meta name="description" content="Process payments with your D-OneCash mobile POS" />
      </Helmet>
      
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
            <div>
              <h1 className="text-2xl font-bold">D-OneCash Business</h1>
              <p className="text-muted-foreground">Point of Sale Terminal</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs font-medium text-green-600 hidden sm:inline">Verified Account</span>
              <span className="text-xs font-medium text-green-600 sm:hidden">Verified</span>
            </div>
          </div>

          <Tabs defaultValue="pos" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="pos">POS</TabsTrigger>
              <TabsTrigger value="rates">Rates</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
            </TabsList>

            <TabsContent value="pos" className="space-y-6">
              <BusinessPOS />
            </TabsContent>

            <TabsContent value="rates" className="space-y-6">
              <BusinessRates />
            </TabsContent>

            <TabsContent value="reports" className="space-y-6">
              <BusinessReports />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}

// Componente del TPV
function BusinessPOS() {
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isNFCActive, setIsNFCActive] = useState(false);
  const [showApproved, setShowApproved] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'contactless' | 'qr'>('contactless');
  const [showQRScanner, setShowQRScanner] = useState(false);

  const handleStartNFC = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Amount Required",
        description: "Enter a valid amount to process the payment",
        variant: "destructive",
      });
      return;
    }

    setIsNFCActive(true);
    setIsProcessing(true);
    
    toast({
      title: "NFC Activated",
      description: "Tap your card to the device to process payment",
    });

    // Simular procesamiento de pago después de 3 segundos
    setTimeout(() => {
      setIsProcessing(false);
      setIsNFCActive(false);
      setShowApproved(true);
      
      // Ocultar la animación después de 3 segundos
      setTimeout(() => {
        setShowApproved(false);
        setAmount("");
      }, 3000);
    }, 3000);
  };

  const handleStartQRPayment = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Amount Required",
        description: "Enter a valid amount to process the payment",
        variant: "destructive",
      });
      return;
    }

    setShowQRScanner(true);
    setIsProcessing(true);
    
    toast({
      title: "QR Scanner Active",
      description: "Customer should scan this QR with their D-OneCash app",
    });

    // Simular escaneo de QR después de 4 segundos
    setTimeout(() => {
      setIsProcessing(false);
      setShowQRScanner(false);
      setShowApproved(true);
      
      // Ocultar la animación después de 3 segundos
      setTimeout(() => {
        setShowApproved(false);
        setAmount("");
      }, 3000);
    }, 4000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Point of Sale Terminal
          </CardTitle>
          <CardDescription>
            Process payments quickly and securely
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Amount Calculator */}
          <div className="space-y-4">
            <Label>Amount to Charge</Label>
            <div className="text-center p-6 bg-accent rounded-lg">
              <div className="text-4xl font-bold mb-2">
                ${amount || "0.00"}
              </div>
              <p className="text-sm text-muted-foreground">USD</p>
            </div>
            
            {/* Teclado numérico */}
            <div className="grid grid-cols-3 gap-3">
              {[1,2,3,4,5,6,7,8,9].map(num => (
                <Button
                  key={num}
                  variant="outline"
                  size="lg"
                  onClick={() => setAmount(prev => prev + num.toString())}
                  disabled={isProcessing}
                >
                  {num}
                </Button>
              ))}
              <Button
                variant="outline"
                size="lg"
                onClick={() => setAmount(prev => prev + ".")}
                disabled={isProcessing || amount.includes(".")}
              >
                .
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => setAmount(prev => prev + "0")}
                disabled={isProcessing}
              >
                0
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => setAmount(prev => prev.slice(0, -1))}
                disabled={isProcessing}
              >
                ⌫
              </Button>
            </div>
            
            <Button
              variant="secondary"
              onClick={() => setAmount("")}
              disabled={isProcessing}
              className="w-full"
            >
              Clear All
            </Button>
          </div>

          {/* Payment Methods */}
          <div className="space-y-4">
            <Label>Payment Method</Label>
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant={paymentMethod === 'contactless' ? 'default' : 'outline'}
                onClick={() => setPaymentMethod('contactless')}
                disabled={isProcessing}
                className="flex flex-col items-center gap-3 h-24"
              >
                <CreditCard className="h-8 w-8" />
                <div className="text-center">
                  <div className="text-sm font-medium">Contactless</div>
                  <div className="text-xs text-muted-foreground">Tap to Pay</div>
                </div>
              </Button>
              
              <Button
                variant={paymentMethod === 'qr' ? 'default' : 'outline'}
                onClick={() => setPaymentMethod('qr')}
                disabled={isProcessing}
                className="flex flex-col items-center gap-3 h-24"
              >
                <svg className="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect width="5" height="5" x="3" y="3" rx="1"/>
                  <rect width="5" height="5" x="16" y="3" rx="1"/>
                  <rect width="5" height="5" x="3" y="16" rx="1"/>
                  <path d="m21 16-3.5-3.5-3.5 3.5"/>
                  <path d="m21 21-3.5-3.5-3.5 3.5"/>
                </svg>
                <div className="text-center">
                  <div className="text-sm font-medium">QR Payment</div>
                  <div className="text-xs text-muted-foreground">D-OneCash App</div>
                </div>
              </Button>
            </div>
          </div>

          {/* Animación de NFC Activated */}
          {isNFCActive && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-white rounded-xl p-8 flex flex-col items-center gap-4 animate-in zoom-in duration-500">
                <div className="h-20 w-20 bg-blue-500 rounded-full flex items-center justify-center animate-pulse">
                  <Smartphone className="h-12 w-12 text-white" />
                </div>
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-blue-600">NFC ACTIVATED</h2>
                  <p className="text-lg text-muted-foreground">Tap your card to pay</p>
                  <p className="text-xl font-bold text-foreground">${amount}</p>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <div className="animate-pulse h-3 w-3 bg-blue-500 rounded-full"></div>
                  <div className="animate-pulse h-3 w-3 bg-blue-500 rounded-full" style={{animationDelay: '0.2s'}}></div>
                  <div className="animate-pulse h-3 w-3 bg-blue-500 rounded-full" style={{animationDelay: '0.4s'}}></div>
                </div>
              </div>
            </div>
          )}

          {/* Animación de APPROVED */}
          {showApproved && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-white rounded-xl p-8 flex flex-col items-center gap-4 animate-in zoom-in duration-500">
                <div className="h-20 w-20 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                  <CheckCircle2 className="h-12 w-12 text-white" />
                </div>
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-green-600">APPROVED</h2>
                  <p className="text-lg text-muted-foreground">${amount}</p>
                </div>
              </div>
            </div>
          )}

          {/* QR Scanner Modal */}
          {showQRScanner && (
            <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
              <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold mb-2">QR Payment</h3>
                  <p className="text-muted-foreground">Customer should scan this QR code</p>
                </div>
                
                {/* QR Code Display */}
                <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-8 mb-6">
                  <div className="flex flex-col items-center">
                    <div className="bg-black p-4 rounded-lg mb-4">
                      <svg className="h-32 w-32 text-white" viewBox="0 0 24 24" fill="currentColor">
                        <rect width="1" height="1" x="3" y="3"/>
                        <rect width="1" height="1" x="5" y="3"/>
                        <rect width="1" height="1" x="3" y="5"/>
                        <rect width="1" height="1" x="5" y="5"/>
                        <rect width="1" height="1" x="16" y="3"/>
                        <rect width="1" height="1" x="18" y="3"/>
                        <rect width="1" height="1" x="16" y="5"/>
                        <rect width="1" height="1" x="18" y="5"/>
                        <rect width="1" height="1" x="3" y="16"/>
                        <rect width="1" height="1" x="5" y="16"/>
                        <rect width="1" height="1" x="3" y="18"/>
                        <rect width="1" height="1" x="5" y="18"/>
                        <rect width="3" height="1" x="7" y="3"/>
                        <rect width="1" height="3" x="11" y="3"/>
                        <rect width="3" height="1" x="13" y="5"/>
                        <rect width="1" height="1" x="7" y="7"/>
                        <rect width="1" height="1" x="9" y="7"/>
                        <rect width="1" height="1" x="11" y="7"/>
                        <rect width="1" height="1" x="13" y="7"/>
                        <rect width="1" height="1" x="15" y="7"/>
                        <rect width="3" height="1" x="7" y="9"/>
                        <rect width="1" height="1" x="11" y="9"/>
                        <rect width="3" height="1" x="13" y="9"/>
                        <rect width="1" height="1" x="7" y="11"/>
                        <rect width="1" height="1" x="9" y="11"/>
                        <rect width="1" height="1" x="11" y="11"/>
                        <rect width="1" height="1" x="13" y="11"/>
                        <rect width="1" height="1" x="15" y="11"/>
                        <rect width="3" height="1" x="7" y="13"/>
                        <rect width="1" height="1" x="11" y="13"/>
                        <rect width="3" height="1" x="13" y="13"/>
                        <rect width="3" height="1" x="7" y="15"/>
                        <rect width="1" height="1" x="11" y="15"/>
                        <rect width="3" height="1" x="13" y="15"/>
                        <rect width="1" height="1" x="7" y="17"/>
                        <rect width="1" height="1" x="9" y="17"/>
                        <rect width="1" height="1" x="11" y="17"/>
                        <rect width="1" height="1" x="13" y="17"/>
                        <rect width="1" height="1" x="15" y="17"/>
                        <rect width="3" height="1" x="7" y="19"/>
                        <rect width="1" height="1" x="11" y="19"/>
                        <rect width="3" height="1" x="13" y="19"/>
                      </svg>
                    </div>
                    <p className="text-sm font-medium">Amount: ${amount}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="animate-pulse h-2 w-2 bg-green-500 rounded-full" />
                      <span className="text-xs text-muted-foreground">Waiting for scan...</span>
                    </div>
                  </div>
                </div>
                
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowQRScanner(false);
                    setIsProcessing(false);
                  }}
                  className="w-full"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Payment Processing Buttons */}
          <div className="space-y-4">
            {paymentMethod === 'contactless' && (
              <>
                <Button
                  onClick={handleStartNFC}
                  disabled={isProcessing || !amount}
                  className="w-full h-16 text-lg bg-green-500 hover:bg-green-600"
                  size="lg"
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
                      Tap your card...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Zap className="h-5 w-5" />
                      Start Contactless Payment
                    </div>
                  )}
                </Button>
              </>
            )}
            
            {paymentMethod === 'qr' && (
              <Button
                onClick={handleStartQRPayment}
                disabled={isProcessing || !amount}
                className="w-full h-16 text-lg bg-blue-500 hover:bg-blue-600"
                size="lg"
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
                    Waiting for customer...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect width="5" height="5" x="3" y="3" rx="1"/>
                      <rect width="5" height="5" x="16" y="3" rx="1"/>
                      <rect width="5" height="5" x="3" y="16" rx="1"/>
                      <path d="m21 16-3.5-3.5-3.5 3.5"/>
                      <path d="m21 21-3.5-3.5-3.5 3.5"/>
                    </svg>
                    Generate QR Payment
                  </div>
                )}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Componente de tarifas
function BusinessRates() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Business Rates
          </CardTitle>
          <CardDescription>
            Special commissions for verified accounts
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold">Payment Methods</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Web Payments</span>
                  <span className="font-medium">1% + $0.25</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">In-Store Payments</span>
                  <span className="font-medium">$0.25</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">QR Payments</span>
                  <span className="font-medium">$0.25</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-semibold">Other Services</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">D1C Transfers</span>
                  <span className="font-medium">0.5%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Bank Withdrawals</span>
                  <span className="font-medium">$2.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Monthly Fee</span>
                  <span className="font-medium">Free</span>
                </div>
              </div>
            </div>
          </div>
          
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              Funds are deposited to your account within 24 hours maximum. 
              No hidden fees or setup costs.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}

// Business Reports Component
function BusinessReports() {
  const todaysSales = 2450.00;
  const monthSales = 38750.50;
  const transactionCount = 156;

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Today's Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              ${todaysSales.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">{transactionCount} transactions</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              ${monthSales.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">+15% vs previous month</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              ${(monthSales * 0.015).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">1.5% average</p>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Sales Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Detailed reporting functionality coming soon.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}