import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { 
  CheckCircle2, 
  Upload, 
  Clock, 
  AlertCircle,
  CreditCard,
  FileText,
  User
} from "lucide-react";

// Estados posibles de verificación
type VerificationStatus = "not_started" | "in_progress" | "pending_review" | "verified" | "rejected";

export default function KYC() {
  const { toast } = useToast();
  
  // En una implementación real, estos estados vendrían del backend
  const [idStatus, setIdStatus] = useState<VerificationStatus>("not_started");
  const [addressStatus, setAddressStatus] = useState<VerificationStatus>("not_started");
  const [selfieStatus, setSelfieStatus] = useState<VerificationStatus>("not_started");
  const [currentUpload, setCurrentUpload] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  // Calcular progreso general
  const getStatusValue = (status: VerificationStatus): number => {
    switch (status) {
      case "verified": return 100;
      case "pending_review": return 75;
      case "in_progress": return 50;
      case "rejected": return 0;
      default: return 0;
    }
  };
  
  const overallProgress = Math.floor(
    (getStatusValue(idStatus) + getStatusValue(addressStatus) + getStatusValue(selfieStatus)) / 3
  );
  
  const getStatusBadge = (status: VerificationStatus) => {
    switch (status) {
      case "verified":
        return <Badge className="bg-green-100 text-green-800 border-green-300">
          <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Verificado
        </Badge>;
      case "pending_review":
        return <Badge className="bg-blue-100 text-blue-800 border-blue-300">
          <Clock className="w-3.5 h-3.5 mr-1" /> Pendiente
        </Badge>;
      case "in_progress":
        return <Badge className="bg-amber-100 text-amber-800 border-amber-300">
          <Upload className="w-3.5 h-3.5 mr-1" /> En progreso
        </Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 border-red-300">
          <AlertCircle className="w-3.5 h-3.5 mr-1" /> Rechazado
        </Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 border-gray-300">
          No iniciado
        </Badge>;
    }
  };
  
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, type: string) => {
    event.preventDefault();
    const file = event.target.files?.[0];
    if (!file) return;
    
    // Simular proceso de carga
    setIsUploading(true);
    setCurrentUpload(type);
    
    // En una implementación real, aquí enviaríamos el archivo al backend
    setTimeout(() => {
      // Actualizar estado según el tipo de documento
      if (type === "id") {
        setIdStatus("pending_review");
      } else if (type === "address") {
        setAddressStatus("pending_review");
      } else if (type === "selfie") {
        setSelfieStatus("pending_review");
      }
      
      setIsUploading(false);
      setCurrentUpload(null);
      
      toast({
        title: "Documento subido con éxito",
        description: "Tu documento ha sido enviado para revisión",
      });
      
      // Limpiar input de archivo
      event.target.value = "";
    }, 2000);
  };
  
  return (
    <div className="container py-4 max-w-4xl mx-auto">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">KYC</h1>
          <p className="text-muted-foreground">Complete su verificación KYC para aumentar sus límites de transacción y acceder a más funciones</p>
        </div>
        
        {/* Tarjeta de progreso general */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Progreso de Verificación</CardTitle>
            <CardDescription>Complete todos los pasos para verificar su identidad</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Progreso general</span>
                <span className="text-sm font-medium">{overallProgress}%</span>
              </div>
              <Progress value={overallProgress} className="h-2" />
            </div>
          </CardContent>
        </Card>
        
        {/* Documentos de identidad */}
        <div className="grid gap-4 md:grid-cols-3">
          {/* ID o Pasaporte */}
          <Card className="relative">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">ID Document</CardTitle>
                {getStatusBadge(idStatus)}
              </div>
              <CardDescription>Suba su DNI o pasaporte</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                <User className="mx-auto h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Suba su documento (pasaporte, DNI o licencia de conducir)
                </p>
                <Input
                  type="file"
                  className="hidden"
                  id="id-upload"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, "id")}
                  disabled={idStatus === "pending_review" || idStatus === "verified" || isUploading}
                />
              </div>
            </CardContent>
            <CardFooter>
              <label 
                htmlFor="id-upload" 
                className={`w-full ${isUploading && currentUpload === "id" ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                <Button 
                  className="w-full" 
                  disabled={idStatus === "pending_review" || idStatus === "verified" || (isUploading && currentUpload === "id")}
                >
                  {isUploading && currentUpload === "id" ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      Subiendo...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Subir documento
                    </>
                  )}
                </Button>
              </label>
            </CardFooter>
          </Card>
          
          {/* Comprobante de dirección */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">Proof of Address</CardTitle>
                {getStatusBadge(addressStatus)}
              </div>
              <CardDescription>Documento verificando su dirección</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                <FileText className="mx-auto h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Suba un documento reciente (no mayor a 3 meses)
                </p>
                <Input
                  type="file"
                  className="hidden"
                  id="address-upload"
                  accept="image/*,application/pdf"
                  onChange={(e) => handleFileUpload(e, "address")}
                  disabled={addressStatus === "pending_review" || addressStatus === "verified" || isUploading}
                />
              </div>
            </CardContent>
            <CardFooter>
              <label 
                htmlFor="address-upload" 
                className={`w-full ${isUploading && currentUpload === "address" ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                <Button 
                  className="w-full" 
                  disabled={addressStatus === "pending_review" || addressStatus === "verified" || (isUploading && currentUpload === "address")}
                >
                  {isUploading && currentUpload === "address" ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      Subiendo...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Subir documento
                    </>
                  )}
                </Button>
              </label>
            </CardFooter>
          </Card>
          
          {/* Selfie con ID */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">Selfie with ID</CardTitle>
                {getStatusBadge(selfieStatus)}
              </div>
              <CardDescription>Una foto de usted sosteniendo su ID</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                <CreditCard className="mx-auto h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Asegúrese que su información sea visible
                </p>
                <Input
                  type="file"
                  className="hidden"
                  id="selfie-upload"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, "selfie")}
                  disabled={selfieStatus === "pending_review" || selfieStatus === "verified" || isUploading}
                />
              </div>
            </CardContent>
            <CardFooter>
              <label 
                htmlFor="selfie-upload" 
                className={`w-full ${isUploading && currentUpload === "selfie" ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                <Button 
                  className="w-full" 
                  disabled={selfieStatus === "pending_review" || selfieStatus === "verified" || (isUploading && currentUpload === "selfie")}
                >
                  {isUploading && currentUpload === "selfie" ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      Subiendo...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Subir documento
                    </>
                  )}
                </Button>
              </label>
            </CardFooter>
          </Card>
        </div>
        
        {/* Información legal */}
        <Card className="bg-muted/50">
          <CardHeader className="pb-2">
            <CardTitle>Información Legal</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Sus documentos son procesados con seguridad y confidencialidad. D-OneCash cumple con las leyes de protección de datos y anti-lavado de dinero.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}