import { Helmet } from "react-helmet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useWallet } from "@/hooks/useWallet";
import { useQuery } from "@tanstack/react-query";
import { Transaction } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

export default function Statistics() {
  const { userId } = useWallet();
  
  const { data: transactions } = useQuery({
    queryKey: [`/api/transactions/${userId}`],
    enabled: !!userId,
  });
  
  // Process data for charts
  const getChartData = () => {
    if (!transactions || transactions.length === 0) {
      return {
        monthly: [],
        byType: [],
      };
    }
    
    // Monthly activity
    const monthlyData: Record<string, { month: string, amount: number }> = {};
    const now = new Date();
    
    // Initialize last 6 months
    for (let i = 5; i >= 0; i--) {
      const month = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthKey = month.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      monthlyData[monthKey] = { month: monthKey, amount: 0 };
    }
    
    // Fill in data
    transactions.forEach((transaction: Transaction) => {
      const date = new Date(transaction.createdAt);
      const monthKey = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      
      if (monthlyData[monthKey]) {
        if (transaction.type === 'receive' || transaction.type === 'reward') {
          monthlyData[monthKey].amount += transaction.amount;
        } else {
          monthlyData[monthKey].amount -= transaction.amount;
        }
      }
    });
    
    // Transaction types
    const typeCount: Record<string, number> = {
      send: 0,
      receive: 0,
      reward: 0,
      card: 0,
    };
    
    transactions.forEach((transaction: Transaction) => {
      if (typeCount[transaction.type] !== undefined) {
        typeCount[transaction.type]++;
      }
    });
    
    const byTypeData = Object.entries(typeCount).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value,
    }));
    
    return {
      monthly: Object.values(monthlyData),
      byType: byTypeData,
    };
  };
  
  const chartData = getChartData();
  
  const COLORS = ['#0AD678', '#FF4B55', '#FFB845', '#3A7BD5'];
  
  return (
    <>
      <Helmet>
        <title>Statistics | D-OneCash</title>
        <meta name="description" content="View detailed statistics and insights about your financial activity with D-OneCash." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Financial Statistics</h1>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{transactions?.length || 0}</div>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Sent</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">
                {transactions
                  ? `$${transactions
                      .filter((t: Transaction) => t.type === 'send')
                      .reduce((sum: number, t: Transaction) => sum + t.amount, 0)
                      .toFixed(2)}`
                  : '$0.00'}
              </div>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Received</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {transactions
                  ? `$${transactions
                      .filter((t: Transaction) => t.type === 'receive')
                      .reduce((sum: number, t: Transaction) => sum + t.amount, 0)
                      .toFixed(2)}`
                  : '$0.00'}
              </div>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Rewards</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-400">
                {transactions
                  ? `$${transactions
                      .filter((t: Transaction) => t.type === 'reward')
                      .reduce((sum: number, t: Transaction) => sum + t.amount, 0)
                      .toFixed(2)}`
                  : '$0.00'}
              </div>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {chartData.monthly.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={chartData.monthly}
                      margin={{ top: 20, right: 30, left: 20, bottom: 50 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                      <XAxis dataKey="month" angle={-45} textAnchor="end" height={70} stroke="#BBBBBB" />
                      <YAxis stroke="#BBBBBB" />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#222', border: '1px solid #333' }}
                        formatter={(value: number) => [`$${value.toFixed(2)}`, 'Amount']}
                      />
                      <Bar
                        dataKey="amount"
                        fill="#0AD678"
                        radius={[4, 4, 0, 0]}
                        barSize={30}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">No data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Transaction Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {chartData.byType.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={chartData.byType}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {chartData.byType.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: '#222', border: '1px solid #333' }}
                        formatter={(value: number) => [value, 'Transactions']}
                      />
                      <Legend verticalAlign="bottom" height={36} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">No data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
