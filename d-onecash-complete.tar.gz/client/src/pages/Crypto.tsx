import { useState } from "react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar } from "@/components/ui/avatar";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Copy, ChevronRight, TrendingUp, TrendingDown, Plus } from "lucide-react";
import { t } from "@/components/ui/LanguageToggle";
import { useWallet } from "@/hooks/useWallet";
import { useToast } from "@/hooks/use-toast";

// Datos de ejemplo para criptomonedas
const cryptocurrencies = [
  { id: "btc", name: "Bitcoin", symbol: "BTC", price: 60842.35, change24h: 2.34, logo: "B", color: "#F7931A" },
  { id: "eth", name: "Ethereum", symbol: "ETH", price: 3241.18, change24h: 1.25, logo: "E", color: "#627EEA" },
  { id: "xrp", name: "XRP", symbol: "XRP", price: 0.5078, change24h: -1.45, logo: "X", color: "#23292F" },
  { id: "ada", name: "Cardano", symbol: "ADA", price: 0.4565, change24h: 0.87, logo: "A", color: "#0033AD" },
  { id: "d1c", name: "D-OneCash", symbol: "D1C", price: 0.0974, change24h: 5.26, logo: "D", color: "#10B981" }
];

// Objeto para almacenar balances ficticios de criptomonedas
const cryptoBalances = {
  "btc": 0.025,
  "eth": 1.258,
  "xrp": 354.25,
  "ada": 450.75,
  "d1c": 1250.50
};

// Opciones de ahorro
const ahorroOptions = [
  { period: "1_month", rate: 3.5 },
  { period: "2_months", rate: 4.2 },
  { period: "3_months", rate: 5.0 },
  { period: "6_months", rate: 6.5 },
  { period: "12_months", rate: 8.0 }
];

export default function Crypto() {
  const { userData, balance } = useWallet();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("assets");
  const [buyAmount, setBuyAmount] = useState("");
  const [sellAmount, setSellAmount] = useState("");
  const [selectedCrypto, setSelectedCrypto] = useState("btc");
  const [ahorroAmount, setAhorroAmount] = useState("");
  const [ahorroPeriod, setAhorroPeriod] = useState("3_months");
  
  // Función para truncar números largos
  const formatNumber = (num: number) => {
    if (num < 0.01) return num.toFixed(6);
    if (num < 1) return num.toFixed(4);
    if (num < 10) return num.toFixed(2);
    return num.toLocaleString('en-US', { maximumFractionDigits: 2 });
  };
  
  // Calcular comisión y total para la compra
  const calculateBuyCommission = () => {
    const amount = parseFloat(buyAmount) || 0;
    // 5% para cantidades menores a $100, comisión fija de $3.50 para montos mayores
    const commission = amount <= 100 ? amount * 0.05 : 3.50;
    return { commission, total: amount + commission };
  };
  
  // Calcular comisión y total para la venta
  const calculateSellCommission = () => {
    const amount = parseFloat(sellAmount) || 0;
    // Misma estructura de comisión para venta
    const commission = amount <= 100 ? amount * 0.05 : 3.50;
    return { commission, total: amount - commission };
  };
  
  // Calcular recompensas estimadas de ahorro
  const calculateAhorroRewards = () => {
    const amount = parseFloat(ahorroAmount) || 0;
    const selectedOption = ahorroOptions.find(option => option.period === ahorroPeriod);
    if (!selectedOption) return 0;
    
    const rate = selectedOption.rate / 100;
    const periodInMonths = parseInt(ahorroPeriod.split('_')[0]);
    return amount * rate * (periodInMonths / 12);
  };
  
  // Obtener info de la criptomoneda seleccionada
  const getSelectedCryptoInfo = () => {
    return cryptocurrencies.find(crypto => crypto.id === selectedCrypto) || cryptocurrencies[0];
  };

  // Obtener balance de la cripto seleccionada
  const getSelectedCryptoBalance = () => {
    return cryptoBalances[selectedCrypto as keyof typeof cryptoBalances] || 0;
  };
  
  // Manejar compra de cripto
  const handleBuy = () => {
    toast({
      title: t("app.crypto.transaction_success"),
      description: `${buyAmount} USD → ${(parseFloat(buyAmount) / getSelectedCryptoInfo().price).toFixed(6)} ${getSelectedCryptoInfo().symbol}`,
    });
    setBuyAmount("");
  };
  
  // Manejar venta de cripto
  const handleSell = () => {
    toast({
      title: t("app.crypto.transaction_success"),
      description: `${sellAmount} ${getSelectedCryptoInfo().symbol} → ${(parseFloat(sellAmount) * getSelectedCryptoInfo().price).toFixed(2)} USD`,
    });
    setSellAmount("");
  };
  
  // Manejar ahorro
  const handleAhorro = () => {
    toast({
      title: t("app.crypto.transaction_pending"),
      description: `${ahorroAmount} ${getSelectedCryptoInfo().symbol} → ${t("app.crypto." + ahorroPeriod)}`,
    });
    setAhorroAmount("");
  };
  
  // Copiar dirección de billetera al portapapeles
  const copyToClipboard = () => {
    if (userData?.walletAddress) {
      navigator.clipboard.writeText(userData.walletAddress);
      toast({
        title: t("app.crypto.address_copied")
      });
    }
  };
  
  return (
    <>
      <Helmet>
        <title>{t("app.crypto.page_title")} | D-OneCash</title>
        <meta name="description" content={t("app.crypto.subtitle")} />
      </Helmet>
      
      <div className="container mx-auto px-4 pb-20">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold">{t("app.crypto.page_title")}</h1>
            <p className="text-muted-foreground">{t("app.crypto.subtitle")}</p>
          </div>
          
          <Tabs defaultValue="assets" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="assets">{t("app.crypto.my_assets")}</TabsTrigger>
              <TabsTrigger value="trade">{t("app.crypto.market")}</TabsTrigger>
              <TabsTrigger value="ahorro">{t("app.crypto.staking")}</TabsTrigger>
            </TabsList>
            
            {/* Mis Activos */}
            <TabsContent value="assets" className="space-y-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>{t("app.crypto.my_assets")}</CardTitle>
                  <CardDescription>
                    {t("app.crypto.available_balance")}: ${formatNumber(balance)}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(cryptoBalances).map(([id, amount]) => {
                      const crypto = cryptocurrencies.find(c => c.id === id);
                      if (!crypto) return null;
                      
                      const value = amount * crypto.price;
                      return (
                        <div key={id} className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8 bg-primary/10 text-primary">
                              <span style={{ color: crypto.color }}>{crypto.logo}</span>
                            </Avatar>
                            <div>
                              <p className="font-medium">{crypto.name}</p>
                              <p className="text-xs text-muted-foreground">{formatNumber(amount)} {crypto.symbol}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">${formatNumber(value)}</p>
                            <p className={`text-xs ${crypto.change24h >= 0 ? 'text-green-500' : 'text-destructive'}`}>
                              {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h}%
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>{t("app.crypto.receive")}</CardTitle>
                  <CardDescription>{t("app.crypto.your_wallet_address")}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center justify-between bg-muted p-3 rounded-md">
                      <p className="font-mono text-xs text-muted-foreground truncate mr-2">
                        {userData?.walletAddress || '0x0000000000000000000000000000000000000000'}
                      </p>
                      <Button variant="ghost" size="icon" onClick={copyToClipboard} className="flex-shrink-0">
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <p className="text-sm text-muted-foreground">
                      {t("app.crypto.qr_description")}
                    </p>
                    
                    <div className="flex justify-center py-4">
                      {/* Simulación de código QR simple */}
                      <div className="w-48 h-48 bg-muted flex items-center justify-center">
                        <span className="text-xs">QR {userData?.walletAddress?.substring(0, 8)}...</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Mercado y Trading */}
            <TabsContent value="trade" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>{t("app.crypto.market")}</CardTitle>
                  <CardDescription>{t("app.crypto.available_balance")}: ${formatNumber(balance)}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {cryptocurrencies.map(crypto => (
                      <div key={crypto.id} className="flex items-center justify-between border-b border-muted pb-3 last:border-0 last:pb-0">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8 bg-primary/10 text-primary">
                            <span style={{ color: crypto.color }}>{crypto.logo}</span>
                          </Avatar>
                          <div>
                            <p className="font-medium">{crypto.name}</p>
                            <p className="text-xs text-muted-foreground">{crypto.symbol}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">${formatNumber(crypto.price)}</p>
                          <p className={`text-xs flex items-center gap-1 ${crypto.change24h >= 0 ? 'text-green-500' : 'text-destructive'}`}>
                            {crypto.change24h >= 0 ? (
                              <TrendingUp className="h-3 w-3" />
                            ) : (
                              <TrendingDown className="h-3 w-3" />
                            )}
                            {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h}%
                          </p>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => setSelectedCrypto(crypto.id)}>
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Comprar */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>{t("app.crypto.buy")}</CardTitle>
                    <CardDescription>
                      {t("app.crypto.available_balance")}: ${formatNumber(balance)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">{t("app.crypto.select_crypto")}</label>
                        <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {cryptocurrencies.map(crypto => (
                              <SelectItem key={crypto.id} value={crypto.id}>
                                <div className="flex items-center gap-2">
                                  <span style={{ color: crypto.color }}>{crypto.logo}</span>
                                  <span>{crypto.name} ({crypto.symbol})</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">{t("app.crypto.amount")} (USD)</label>
                        <Input
                          type="number"
                          placeholder="0.00"
                          value={buyAmount}
                          onChange={(e) => setBuyAmount(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">
                          ≈ {buyAmount && formatNumber(parseFloat(buyAmount) / getSelectedCryptoInfo().price)} {getSelectedCryptoInfo().symbol}
                        </p>
                      </div>
                      
                      {buyAmount && (
                        <div className="pt-2 space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{t("app.crypto.commission")}</span>
                            <span>${formatNumber(calculateBuyCommission().commission)}</span>
                          </div>
                          <Separator />
                          <div className="flex justify-between font-medium">
                            <span>{t("app.crypto.total")}</span>
                            <span>${formatNumber(calculateBuyCommission().total)}</span>
                          </div>
                        </div>
                      )}
                      
                      <Button 
                        className="w-full" 
                        type="button" 
                        onClick={handleBuy}
                        disabled={!buyAmount || parseFloat(buyAmount) <= 0 || parseFloat(buyAmount) > balance}
                      >
                        {t("app.crypto.buy")} {getSelectedCryptoInfo().symbol}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
                
                {/* Vender */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>{t("app.crypto.sell")}</CardTitle>
                    <CardDescription>
                      {t("app.crypto.available_balance")}: {formatNumber(getSelectedCryptoBalance())} {getSelectedCryptoInfo().symbol}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">{t("app.crypto.select_crypto")}</label>
                        <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {cryptocurrencies.map(crypto => (
                              <SelectItem key={crypto.id} value={crypto.id}>
                                <div className="flex items-center gap-2">
                                  <span style={{ color: crypto.color }}>{crypto.logo}</span>
                                  <span>{crypto.name} ({crypto.symbol})</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">{t("app.crypto.amount")} ({getSelectedCryptoInfo().symbol})</label>
                        <Input
                          type="number"
                          placeholder="0.00"
                          value={sellAmount}
                          onChange={(e) => setSellAmount(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">
                          ≈ ${sellAmount && formatNumber(parseFloat(sellAmount) * getSelectedCryptoInfo().price)} USD
                        </p>
                      </div>
                      
                      {sellAmount && (
                        <div className="pt-2 space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{t("app.crypto.commission")}</span>
                            <span>${formatNumber(calculateSellCommission().commission)}</span>
                          </div>
                          <Separator />
                          <div className="flex justify-between font-medium">
                            <span>{t("app.crypto.total")}</span>
                            <span>${formatNumber(calculateSellCommission().total)}</span>
                          </div>
                        </div>
                      )}
                      
                      <Button 
                        className="w-full" 
                        type="button" 
                        onClick={handleSell}
                        disabled={!sellAmount || parseFloat(sellAmount) <= 0 || parseFloat(sellAmount) > getSelectedCryptoBalance()}
                      >
                        {t("app.crypto.sell")} {getSelectedCryptoInfo().symbol}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Staking */}
            <TabsContent value="ahorro" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>{t("app.crypto.staking")}</CardTitle>
                  <CardDescription>
                    {t("app.crypto.available_balance")}: {formatNumber(getSelectedCryptoBalance())} {getSelectedCryptoInfo().symbol}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">{t("app.crypto.select_crypto")}</label>
                      <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {cryptocurrencies.map(crypto => (
                            <SelectItem key={crypto.id} value={crypto.id}>
                              <div className="flex items-center gap-2">
                                <span style={{ color: crypto.color }}>{crypto.logo}</span>
                                <span>{crypto.name} ({crypto.symbol})</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">{t("app.crypto.amount")} ({getSelectedCryptoInfo().symbol})</label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={ahorroAmount}
                        onChange={(e) => setAhorroAmount(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">{t("app.crypto.staking_period")}</label>
                      <Select value={ahorroPeriod} onValueChange={setAhorroPeriod}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {ahorroOptions.map(option => (
                            <SelectItem key={option.period} value={option.period}>
                              {t(`app.crypto.${option.period}`)} - {option.rate}% APY
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {ahorroAmount && (
                      <div className="pt-2 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{t("app.crypto.reward_rate")}</span>
                          <span>{ahorroOptions.find(o => o.period === ahorroPeriod)?.rate}% APY</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>{t("app.crypto.staking_period")}</span>
                          <span>{t(`app.crypto.${ahorroPeriod}`)}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-medium">
                          <span>{t("app.crypto.estimated_rewards")}</span>
                          <span className="text-green-500">+{formatNumber(calculateAhorroRewards())} {getSelectedCryptoInfo().symbol}</span>
                        </div>
                      </div>
                    )}
                    
                    <Button 
                      className="w-full" 
                      type="button" 
                      onClick={handleStake}
                      disabled={!stakingAmount || parseFloat(stakingAmount) <= 0 || parseFloat(stakingAmount) > getSelectedCryptoBalance()}
                    >
                      {t("app.crypto.stake")} {getSelectedCryptoInfo().symbol}
                    </Button>
                  </form>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>{t("app.crypto.my_assets")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Alert>
                    <AlertDescription className="text-center py-8">
                      No tienes activos en staking aún
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}