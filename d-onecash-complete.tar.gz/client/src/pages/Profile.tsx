import { Helmet } from "react-helmet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/useWallet";

export default function Profile() {
  const { userData } = useWallet();
  
  return (
    <>
      <Helmet>
        <title>Profile | D-OneCash</title>
        <meta name="description" content="Manage your D-OneCash profile, security settings, and personal information." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col items-center mb-6">
          <Avatar className="h-24 w-24 mb-4">
            <AvatarImage src="" alt="Profile" />
            <AvatarFallback className="bg-primary/10 text-primary text-lg">
              {userData?.fullName ? userData.fullName.charAt(0).toUpperCase() : "D"}
            </AvatarFallback>
          </Avatar>
          <h1 className="text-2xl font-bold">{userData?.fullName || "Demo User"}</h1>
          <p className="text-muted-foreground">{userData?.email || "demo@donecash.com"}</p>
          <div className="mt-2">
            <Button variant="outline" size="sm" className="mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"></path>
              </svg>
              Edit Profile
            </Button>
          </div>
        </div>
        
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Account Details</CardTitle>
              <CardDescription>Your personal information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between py-1 border-b border-accent">
                  <span className="text-muted-foreground">Username</span>
                  <span className="font-medium">{userData?.username || "demo"}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-accent">
                  <span className="text-muted-foreground">Email</span>
                  <span className="font-medium">{userData?.email || "demo@donecash.com"}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-accent">
                  <span className="text-muted-foreground">Phone</span>
                  <span className="font-medium">{userData?.phoneNumber || "+1234567890"}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-muted-foreground">Member Since</span>
                  <span className="font-medium">Apr 2023</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Wallet Information</CardTitle>
              <CardDescription>Your wallet details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between py-1 border-b border-accent">
                  <span className="text-muted-foreground">Wallet Address</span>
                  <span className="font-medium text-xs font-mono truncate max-w-[150px]">
                    {userData?.walletAddress || "d1c:0x7F5E8c21A53dE856DBC4a0a25E0C98d06Dff303C"}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-accent">
                  <span className="text-muted-foreground">Default Currency</span>
                  <span className="font-medium">USDC</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-muted-foreground">Advanced Mode</span>
                  <span className="text-yellow-400">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
                      <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                  </span>
                </div>
              </div>
              
              <Button variant="outline" className="w-full mt-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="7" height="9" x="3" y="3" rx="1"></rect>
                  <rect width="7" height="5" x="14" y="3" rx="1"></rect>
                  <rect width="7" height="9" x="14" y="12" rx="1"></rect>
                  <rect width="7" height="5" x="3" y="16" rx="1"></rect>
                </svg>
                View Connected Apps
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Security</CardTitle>
              <CardDescription>Manage your security settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Two-Factor Authentication</h3>
                    <p className="text-xs text-muted-foreground">Protect your account with 2FA</p>
                  </div>
                  <Button variant="outline" size="sm">Enable</Button>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Change Password</h3>
                    <p className="text-xs text-muted-foreground">Update your password regularly</p>
                  </div>
                  <Button variant="outline" size="sm">Change</Button>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Recovery Options</h3>
                    <p className="text-xs text-muted-foreground">Set up account recovery methods</p>
                  </div>
                  <Button variant="outline" size="sm">Setup</Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Preferences</CardTitle>
              <CardDescription>Customize your app experience</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Notifications</h3>
                    <p className="text-xs text-muted-foreground">Manage notification preferences</p>
                  </div>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Language</h3>
                    <p className="text-xs text-muted-foreground">Change display language</p>
                  </div>
                  <span className="text-muted-foreground">English</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Dark Mode</h3>
                    <p className="text-xs text-muted-foreground">Toggle dark/light theme</p>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
                  </svg>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
