import { Helmet } from "react-helmet";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Phone, 
  Mail, 
  Clock, 
  CheckCircle,
  HelpCircle,
  FileText,
  CreditCard,
  Wallet,
  Shield,
  Zap,
  Users,
  Globe
} from "lucide-react";

interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'support';
  timestamp: Date;
}

interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export default function Help() {
  const { toast } = useToast();
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      content: 'Hello! Welcome to D-OneCash support. How can I help you today?',
      sender: 'support',
      timestamp: new Date()
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const faqs: FAQ[] = [
    {
      id: '1',
      question: 'How do I add funds to my wallet?',
      answer: 'You can add funds by going to your Wallet page and clicking "Add Funds". We support credit/debit cards, bank transfers, and cryptocurrency deposits.',
      category: 'wallet'
    },
    {
      id: '2',
      question: 'What are the transaction fees?',
      answer: 'For personal transfers: $0.50 for amounts $0.01-$100, $3.50 for amounts over $100. Business rates: 1% + $0.25 for web payments, $0.25 for in-store payments.',
      category: 'fees'
    },
    {
      id: '3',
      question: 'How do I verify my account?',
      answer: 'Go to the KYC section in your profile and upload the required documents. Verification typically takes 24-48 hours.',
      category: 'account'
    },
    {
      id: '4',
      question: 'Can I request a loan?',
      answer: 'Yes! You can request loans up to 50% of your Bitcoin value with a 6% annual interest rate. Visit the Loans section to apply.',
      category: 'loans'
    },
    {
      id: '5',
      question: 'How do virtual cards work?',
      answer: 'Virtual cards are instantly generated and can be used for online purchases. You can create, fund, and manage them from the Cards section.',
      category: 'cards'
    },
    {
      id: '6',
      question: 'Is my money safe?',
      answer: 'Yes, we use bank-level security, encryption, and are fully regulated. Your funds are insured and protected by multiple security layers.',
      category: 'security'
    }
  ];

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const supportResponses = [
    "I'd be happy to help you with that! Let me check your account details.",
    "Thanks for reaching out. Here's what I found about your question...",
    "That's a great question! Let me provide you with the information you need.",
    "I understand your concern. Here's how we can resolve this issue...",
    "Thank you for your patience. I've reviewed your request and here's the solution...",
  ];

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: newMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setChatMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsTyping(true);

    setTimeout(() => {
      const randomResponse = supportResponses[Math.floor(Math.random() * supportResponses.length)];
      const supportMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        content: randomResponse,
        sender: 'support',
        timestamp: new Date()
      };
      
      setChatMessages(prev => [...prev, supportMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    toast({
      title: "Message sent successfully",
      description: "We'll get back to you within 24 hours.",
      variant: "default",
    });

    setContactForm({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  const quickActions = [
    { icon: <Wallet className="h-5 w-5" />, label: "Account Balance", description: "Check your current balance", color: "bg-blue-500/10 text-blue-600" },
    { icon: <CreditCard className="h-5 w-5" />, label: "Transaction History", description: "View recent transactions", color: "bg-purple-500/10 text-purple-600" },
    { icon: <Shield className="h-5 w-5" />, label: "Security Settings", description: "Manage account security", color: "bg-green-500/10 text-green-600" },
    { icon: <FileText className="h-5 w-5" />, label: "Documentation", description: "Read our guides and FAQs", color: "bg-orange-500/10 text-orange-600" },
  ];

  const stats = [
    { icon: <Users className="h-8 w-8" />, label: "24/7", description: "Support Available", color: "text-blue-600" },
    { icon: <Zap className="h-8 w-8" />, label: "< 2 min", description: "Average Response", color: "text-green-600" },
    { icon: <Globe className="h-8 w-8" />, label: "99.9%", description: "Uptime Guarantee", color: "text-purple-600" },
  ];

  return (
    <>
      <Helmet>
        <title>Help & Support | D-OneCash</title>
        <meta name="description" content="Get help and support for your D-OneCash account. Chat with our support team or browse FAQs." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-7xl mx-auto">
            {/* Hero Section */}
            <div className="text-center mb-12 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-green-500/20 blur-3xl -z-10 rounded-full transform scale-150"></div>
              <div className="relative z-10 bg-background/80 backdrop-blur-sm p-6 md:p-8 rounded-2xl border shadow-xl">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                  <MessageCircle className="h-8 w-8 text-primary" />
                </div>
                <h1 className="text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-green-600 bg-clip-text text-transparent">
                  Help & Support
                </h1>
                <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
                  Get instant help with our live chat, browse FAQs, or contact our support team. We're here 24/7 to assist you.
                </p>
                
                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
                  {stats.map((stat, index) => (
                    <div key={index} className="text-center">
                      <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-2 ${stat.color}`}>
                        {stat.icon}
                      </div>
                      <div className="text-2xl font-bold">{stat.label}</div>
                      <div className="text-sm text-muted-foreground">{stat.description}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <Tabs defaultValue="chat" className="space-y-8">
              <div className="flex justify-center">
                <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full max-w-2xl bg-background/80 backdrop-blur-sm border shadow-lg">
                  <TabsTrigger value="chat" className="text-xs md:text-sm">Live Chat</TabsTrigger>
                  <TabsTrigger value="faq" className="text-xs md:text-sm">FAQs</TabsTrigger>
                  <TabsTrigger value="contact" className="text-xs md:text-sm">Contact</TabsTrigger>
                  <TabsTrigger value="status" className="text-xs md:text-sm">Status</TabsTrigger>
                </TabsList>
              </div>

              {/* Live Chat Tab */}
              <TabsContent value="chat" className="space-y-8">
                <div className="grid lg:grid-cols-4 gap-6">
                  {/* Quick Actions */}
                  <div className="lg:col-span-1 order-2 lg:order-1">
                    <Card className="bg-background/80 backdrop-blur-sm border shadow-lg">
                      <CardHeader className="pb-4">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <HelpCircle className="h-5 w-5" />
                          Quick Actions
                        </CardTitle>
                        <CardDescription className="text-sm">
                          Common issues and help topics
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {quickActions.map((action, index) => (
                          <Button
                            key={index}
                            variant="ghost"
                            className="w-full justify-start h-auto p-4 hover:bg-accent/50 transition-all duration-200"
                            onClick={() => {
                              const message = `I need help with: ${action.label}`;
                              setNewMessage(message);
                            }}
                          >
                            <div className="flex items-center gap-3 w-full">
                              <div className={`p-2 rounded-lg ${action.color}`}>
                                {action.icon}
                              </div>
                              <div className="text-left flex-1">
                                <p className="font-medium text-sm">{action.label}</p>
                                <p className="text-xs text-muted-foreground">{action.description}</p>
                              </div>
                            </div>
                          </Button>
                        ))}
                      </CardContent>
                    </Card>
                  </div>

                  {/* Chat Interface */}
                  <div className="lg:col-span-3 order-1 lg:order-2">
                    <Card className="h-[600px] flex flex-col bg-background/80 backdrop-blur-sm border shadow-lg">
                      <CardHeader className="pb-4 border-b bg-gradient-to-r from-primary/5 to-green-500/5">
                        <div className="flex items-center gap-3">
                          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                          <div>
                            <CardTitle className="flex items-center gap-2 text-lg">
                              <MessageCircle className="h-5 w-5" />
                              Live Support Chat
                            </CardTitle>
                            <CardDescription className="text-sm">
                              Our support team is online and ready to help
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      
                      <ScrollArea className="flex-1 p-4" ref={chatScrollRef}>
                        <div className="space-y-4">
                          {chatMessages.map((message) => (
                            <div
                              key={message.id}
                              className={`flex gap-3 ${
                                message.sender === 'user' ? 'flex-row-reverse' : ''
                              }`}
                            >
                              <Avatar className="h-8 w-8 border-2 border-background shadow-md">
                                {message.sender === 'user' ? (
                                  <AvatarFallback className="bg-primary text-primary-foreground">
                                    <User className="h-4 w-4" />
                                  </AvatarFallback>
                                ) : (
                                  <AvatarFallback className="bg-gradient-to-br from-green-500 to-primary text-white">
                                    <Bot className="h-4 w-4" />
                                  </AvatarFallback>
                                )}
                              </Avatar>
                              <div
                                className={`max-w-[80%] md:max-w-[70%] rounded-2xl px-4 py-3 shadow-md ${
                                  message.sender === 'user'
                                    ? 'bg-primary text-primary-foreground rounded-br-sm'
                                    : 'bg-background border rounded-bl-sm'
                                }`}
                              >
                                <p className="text-sm leading-relaxed">{message.content}</p>
                                <p className="text-xs mt-2 opacity-70">
                                  {message.timestamp.toLocaleTimeString()}
                                </p>
                              </div>
                            </div>
                          ))}
                          
                          {isTyping && (
                            <div className="flex gap-3">
                              <Avatar className="h-8 w-8 border-2 border-background shadow-md">
                                <AvatarFallback className="bg-gradient-to-br from-green-500 to-primary text-white">
                                  <Bot className="h-4 w-4" />
                                </AvatarFallback>
                              </Avatar>
                              <div className="bg-background border rounded-2xl rounded-bl-sm px-4 py-3 shadow-md">
                                <div className="flex gap-1">
                                  <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                      
                      <div className="p-4 border-t bg-gradient-to-r from-background to-accent/10">
                        <div className="flex gap-2">
                          <Input
                            placeholder="Type your message..."
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            className="flex-1 bg-background/50 backdrop-blur-sm"
                          />
                          <Button 
                            onClick={handleSendMessage} 
                            size="icon"
                            className="bg-gradient-to-r from-primary to-green-600 hover:from-primary/90 hover:to-green-600/90"
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              {/* FAQs Tab */}
              <TabsContent value="faq" className="space-y-6">
                <Card className="bg-background/80 backdrop-blur-sm border shadow-lg">
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl">Frequently Asked Questions</CardTitle>
                    <CardDescription>Find answers to common questions about D-OneCash</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4">
                      {faqs.map((faq) => (
                        <div key={faq.id} className="border rounded-xl p-6 hover:shadow-md transition-all duration-200 bg-background/50">
                          <div className="flex items-start gap-4">
                            <Badge variant="secondary" className="text-xs font-medium px-3 py-1">
                              {faq.category}
                            </Badge>
                            <div className="flex-1">
                              <h3 className="font-semibold mb-3 text-lg">{faq.question}</h3>
                              <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Contact Us Tab */}
              <TabsContent value="contact" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-8">
                  <Card className="bg-background/80 backdrop-blur-sm border shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-xl">Send us a message</CardTitle>
                      <CardDescription>We'll get back to you within 24 hours</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleContactSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Name</label>
                            <Input
                              value={contactForm.name}
                              onChange={(e) => setContactForm({...contactForm, name: e.target.value})}
                              className="bg-background/50"
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Email</label>
                            <Input
                              type="email"
                              value={contactForm.email}
                              onChange={(e) => setContactForm({...contactForm, email: e.target.value})}
                              className="bg-background/50"
                              required
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Subject</label>
                          <Input
                            value={contactForm.subject}
                            onChange={(e) => setContactForm({...contactForm, subject: e.target.value})}
                            className="bg-background/50"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Message</label>
                          <Textarea
                            rows={5}
                            value={contactForm.message}
                            onChange={(e) => setContactForm({...contactForm, message: e.target.value})}
                            className="bg-background/50 resize-none"
                            required
                          />
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-primary to-green-600 hover:from-primary/90 hover:to-green-600/90">
                          Send Message
                        </Button>
                      </form>
                    </CardContent>
                  </Card>

                  <div className="space-y-6">
                    <Card className="bg-background/80 backdrop-blur-sm border shadow-lg">
                      <CardHeader>
                        <CardTitle className="text-xl">Contact Information</CardTitle>
                        <CardDescription>Other ways to reach our support team</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center gap-4 p-4 border rounded-xl bg-background/50 hover:shadow-md transition-all duration-200">
                          <div className="p-3 bg-blue-500/10 text-blue-600 rounded-lg">
                            <Phone className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-semibold">Phone Support</p>
                            <p className="text-sm text-muted-foreground">+1 (555) 123-4567</p>
                            <p className="text-xs text-muted-foreground">Mon-Fri 9AM-6PM EST</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-4 p-4 border rounded-xl bg-background/50 hover:shadow-md transition-all duration-200">
                          <div className="p-3 bg-green-500/10 text-green-600 rounded-lg">
                            <Mail className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-semibold">Email Support</p>
                            <p className="text-sm text-muted-foreground">support@d-onecash.com</p>
                            <p className="text-xs text-muted-foreground">Response within 24 hours</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-4 p-4 border rounded-xl bg-background/50 hover:shadow-md transition-all duration-200">
                          <div className="p-3 bg-purple-500/10 text-purple-600 rounded-lg">
                            <Clock className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-semibold">Business Hours</p>
                            <p className="text-sm text-muted-foreground">Mon-Fri: 9AM - 6PM EST</p>
                            <p className="text-sm text-muted-foreground">Sat: 10AM - 4PM EST</p>
                            <p className="text-xs text-muted-foreground">Closed on Sundays</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              {/* System Status Tab */}
              <TabsContent value="status" className="space-y-6">
                <Card className="bg-background/80 backdrop-blur-sm border shadow-lg">
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl">System Status</CardTitle>
                    <CardDescription>Current status of all D-OneCash services</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid gap-4">
                      {[
                        { service: 'Payment Processing', status: 'operational', description: 'All payment systems running normally' },
                        { service: 'Wallet Services', status: 'operational', description: 'Send, receive, and manage funds' },
                        { service: 'Card Services', status: 'operational', description: 'Virtual and physical card operations' },
                        { service: 'Loan Services', status: 'operational', description: 'Loan applications and management' },
                        { service: 'Business Services', status: 'operational', description: 'POS terminal and business tools' },
                        { service: 'API Services', status: 'operational', description: 'All API endpoints responding' },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-6 border rounded-xl bg-background/50 hover:shadow-md transition-all duration-200">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-1">
                              <span className="font-semibold text-lg">{item.service}</span>
                              <div className="flex items-center gap-2">
                                <CheckCircle className="h-4 w-4 text-green-500" />
                                <span className="text-sm text-green-600 font-medium capitalize">{item.status}</span>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border border-green-200 dark:border-green-800 rounded-xl">
                      <div className="flex items-center gap-3 mb-2">
                        <CheckCircle className="h-6 w-6 text-green-600" />
                        <p className="font-semibold text-green-800 dark:text-green-200 text-lg">All systems operational</p>
                      </div>
                      <p className="text-green-700 dark:text-green-300">
                        All D-OneCash services are running smoothly. Last updated: {new Date().toLocaleString()}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </>
  );
}