import { useState } from "react";
import { Helmet } from "react-helmet";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LogoVerde } from "@/lib/LogoVerde";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { ArrowUp, ArrowDown, DollarSign } from "lucide-react";
import { cn } from "@/lib/utils";

interface Cryptocurrency {
  id: string;
  name: string;
  ticker: string;
  logo: React.ReactNode;
  price: number;
  change24h: number;
  marketCap: number;
  volume: string;
  circulating: string;
}

// Datos de ejemplo para las criptomonedas
const cryptocurrencies: Cryptocurrency[] = [
  {
    id: "btc",
    name: "Bitcoin",
    ticker: "BTC",
    logo: (
      <div className="w-8 h-8 rounded-full bg-[#F7931A] flex items-center justify-center text-white font-bold">
        ₿
      </div>
    ),
    price: 106735.26,
    change24h: 3.34,
    marketCap: 2130802815853,
    volume: "63.228 BTC",
    circulating: "19.984 BTC"
  },
  {
    id: "eth",
    name: "Ethereum",
    ticker: "ETH",
    logo: (
      <div className="w-8 h-8 rounded-full bg-[#627EEA] flex items-center justify-center text-white">
        <svg width="16" height="24" viewBox="0 0 16 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M7.9935 0L7.83594 0.546915V16.4161L7.9935 16.5742L15.9869 11.841L7.9935 0Z" fill="white"/>
          <path d="M7.99341 0L0 11.841L7.99341 16.5742V8.87067V0Z" fill="#ECECEC"/>
          <path d="M7.9935 17.9667L7.90332 18.0793V23.7309L7.9935 23.9998L16 13.2358L7.9935 17.9667Z" fill="white"/>
          <path d="M7.99341 23.9998V17.9667L0 13.2358L7.99341 23.9998Z" fill="#ECECEC"/>
          <path d="M7.99341 16.5741L15.9869 11.8409L7.99341 8.87061V16.5741Z" fill="#C6C6C6"/>
          <path d="M0 11.8409L7.99341 16.5741V8.87061L0 11.8409Z" fill="#E4E4E4"/>
        </svg>
      </div>
    ),
    price: 3479.58,
    change24h: -4.40,
    marketCap: 398351743536,
    volume: "12.35M ETH",
    circulating: "120.73M ETH"
  },
  {
    id: "usdt",
    name: "Tether",
    ticker: "USDT",
    logo: (
      <div className="w-8 h-8 rounded-full bg-[#26A17B] flex items-center justify-center text-white font-bold">
        ₮
      </div>
    ),
    price: 1.00,
    change24h: 0.04,
    marketCap: 151975367603,
    volume: "172.26B USDT",
    circulating: "151.98B USDT"
  },
  {
    id: "xrp",
    name: "XRP",
    ticker: "XRP",
    logo: (
      <div className="w-8 h-8 rounded-full bg-[#23292F] flex items-center justify-center text-white">
        <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M9.54289 3.53713L13.0858 0H9.54289L7.47867 2.0642L5.41445 0H1.8858L7.47867 5.5929L9.54289 3.53713Z" fill="white"/>
          <path d="M0 10.8787L3.54291 14.0358H7.07154L3.51578 10.4801L0 10.8787Z" fill="white"/>
          <path d="M10.9285 14.0358H14.4571L18 10.4929L14.4571 10.1072L10.9285 14.0358Z" fill="white"/>
        </svg>
      </div>
    ),
    price: 2.35,
    change24h: -7.92,
    marketCap: 137644775274,
    volume: "1.60B XRP",
    circulating: "58.67B XRP"
  },
  {
    id: "ada",
    name: "Cardano",
    ticker: "ADA",
    logo: (
      <div className="w-8 h-8 rounded-full bg-[#0033AD] flex items-center justify-center text-white">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z" fill="#0033AD"/>
          <path d="M6.28307 3.04614C6.43347 2.80794 6.77427 2.80794 6.92467 3.04614C7.04347 3.23614 6.99827 3.48514 6.82227 3.62114C6.28787 4.01454 5.89447 4.57954 5.71847 5.22354C5.68907 5.33154 5.59867 5.41114 5.49067 5.42534C5.23587 5.47054 4.98107 5.33454 4.92507 5.07974C4.90507 4.97174 4.91347 4.86374 4.96707 4.76654C5.19367 4.03334 5.66147 3.38934 6.28307 3.04614Z" fill="white"/>
          <path d="M9.68947 3.09135C9.85467 2.92615 10.1389 2.93455 10.2949 3.09975C10.7589 3.56335 11.1271 4.14255 11.3229 4.78655C11.3789 4.97655 11.2933 5.17515 11.1341 5.27155C10.8961 5.41255 10.5889 5.32214 10.4481 5.08394C10.3149 4.54954 10.0177 4.07655 9.61267 3.72895C9.45067 3.57255 9.46747 3.31775 9.68947 3.09135Z" fill="white"/>
          <path d="M4.49573 6.28806C4.73393 6.21286 4.98873 6.36486 5.06393 6.60306C5.08393 6.71106 5.07553 6.81905 5.02193 6.91625C4.79533 7.64945 4.79533 8.43805 5.02193 9.17125C5.08393 9.40945 4.93193 9.66425 4.69373 9.73945C4.44733 9.80625 4.19253 9.65425 4.11733 9.41605C3.83613 8.50285 3.83613 7.53125 4.11733 6.60306C4.19253 6.36486 4.45573 6.22385 4.49573 6.28806Z" fill="white"/>
          <path d="M11.4414 6.60306C11.5166 6.36486 11.7714 6.21286 12.0096 6.28806C12.7596 6.53126 12.7596 6.52286 12.688 6.60306C12.9692 7.52285 12.9692 8.49445 12.688 9.41605C12.6128 9.65425 12.358 9.80625 12.1198 9.73945C11.3698 9.49625 11.3698 9.50465 11.4414 9.42445C11.2094 8.49445 11.2094 7.52285 11.4414 6.60306Z" fill="white"/>
          <path d="M6.34734 10.4293C6.78574 10.8089 7.37654 11.0217 7.97934 11.0433C8.20674 11.0517 8.40534 11.2161 8.41374 11.4435C8.43374 11.6899 8.23514 11.9113 7.98874 11.9365C7.21094 11.9701 6.44394 11.6815 5.87394 11.1579C5.69794 11.0013 5.69794 10.7211 5.86314 10.5601C6.05734 10.3673 6.17714 10.2833 6.34734 10.4293Z" fill="white"/>
          <path d="M9.95587 10.5013C10.1291 10.3193 10.4111 10.3193 10.5841 10.5013C11.1121 11.0249 11.8539 11.3136 12.6317 11.2885C12.8781 11.2716 13.0851 11.4645 13.0767 11.7025C13.0683 11.9489 12.8697 12.1417 12.6233 12.1585C11.6927 12.2005 10.7789 11.8773 10.0959 11.2461C9.92147 11.0875 9.75547 10.7127 9.95587 10.5013Z" fill="white"/>
          <path d="M7.53393 4.04611C7.67493 3.87851 7.91313 3.87851 8.05413 4.04611C8.35453 4.38531 8.35453 4.38531 8.31453 4.49331C8.19473 5.11491 8.19473 5.75891 8.31453 6.38051C8.36973 6.61031 8.23373 6.85671 8.00393 6.92111C7.86293 6.95891 7.71093 6.93051 7.59113 6.83331C7.47973 6.73611 7.42373 6.58411 7.44373 6.43211C7.59113 5.69051 7.59113 4.92351 7.43233 4.18191C7.40293 4.05371 7.44373 3.92551 7.53393 4.04611Z" fill="white"/>
          <path d="M7.47793 9.61882C7.48633 9.39982 7.65233 9.23382 7.87133 9.22542C8.09873 9.21703 8.28633 9.38302 8.29474 9.61043C8.28063 10.2756 8.50723 10.9239 8.94563 11.4139C9.10324 11.6017 9.08323 11.8987 8.90303 12.0621C8.72283 12.2339 8.42663 12.2255 8.24643 12.0453C7.67643 11.4139 7.37603 10.5427 7.47793 9.61882Z" fill="white"/>
          <path d="M5.59866 7.54411C5.42686 7.41591 5.40686 7.16951 5.53506 6.99771C5.64306 6.84571 5.85366 6.81211 6.01966 6.90091C6.60046 7.19291 7.27506 7.19291 7.85586 6.90091C8.09406 6.80371 8.36686 6.92091 8.46406 7.15911C8.56126 7.39731 8.44406 7.67011 8.20586 7.76731C7.44306 8.14649 6.53826 8.14649 5.77546 7.77571C5.68526 7.73571 5.61006 7.64551 5.59866 7.54411Z" fill="white"/>
          <path d="M5.59866 8.45412C5.41846 8.32592 5.40686 8.07952 5.53506 7.90772C5.66326 7.72752 5.90966 7.71912 6.08146 7.84732C6.61586 8.11752 7.23746 8.10912 7.77186 7.84732C7.95206 7.71912 8.19866 7.72752 8.32686 7.90772C8.45506 8.08792 8.44666 8.33432 8.26646 8.46252C7.53586 8.82432 6.66606 8.82432 5.93546 8.46252C5.79446 8.42252 5.66626 8.53052 5.59866 8.45412Z" fill="white"/>
          <path d="M10.2952 7.15911C10.3923 6.92091 10.6652 6.80371 10.9033 6.90091C11.6661 7.27171 12.5709 7.27171 13.3337 6.90091C13.5719 6.80371 13.8447 6.92091 13.9419 7.15911C14.0391 7.39731 13.9219 7.67011 13.6837 7.76731C12.9293 8.14649 12.0245 8.14649 11.2701 7.76731C11.0488 7.67851 9.75066 7.82211 10.2952 7.15911Z" fill="white"/>
          <path d="M10.2952 8.27392C10.3923 8.03572 10.6652 7.91852 10.9033 8.01572C11.6661 8.38652 12.5709 8.38652 13.3337 8.01572C13.5719 7.91852 13.8447 8.03572 13.9419 8.27392C14.0391 8.51212 13.9219 8.78492 13.6837 8.88212C12.9293 9.2613 12.0245 9.2613 11.2701 8.88212C11.0488 8.78492 9.75066 8.93692 10.2952 8.27392Z" fill="white"/>
        </svg>
      </div>
    ),
    price: 0.7522,
    change24h: -6.08,
    marketCap: 26573823640,
    volume: "1.40B ADA",
    circulating: "35.32B ADA"
  },
  {
    id: "usdc",
    name: "USD Coin",
    ticker: "USDC",
    logo: (
      <div className="w-8 h-8 rounded-full bg-[#2775CA] flex items-center justify-center text-white font-bold">
        $
      </div>
    ),
    price: 0.9997,
    change24h: -0.02,
    marketCap: 61156840527,
    volume: "10.15B USDC",
    circulating: "61.17B USDC"
  },
  {
    id: "d1c",
    name: "D-OneCash",
    ticker: "D1C",
    logo: <LogoVerde className="w-8 h-8" />,
    price: 1.0,
    change24h: 0.12,
    marketCap: 100000000,
    volume: "2.45M D1C",
    circulating: "100M D1C"
  }
];

export default function Invest() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("market");
  const [selectedCrypto, setSelectedCrypto] = useState<Cryptocurrency | null>(null);
  const [buyAmount, setBuyAmount] = useState("");
  const [sellAmount, setSellAmount] = useState("");
  const [showBuySellModal, setShowBuySellModal] = useState(false);
  const [tradeAction, setTradeAction] = useState<"buy" | "sell">("buy");

  // Iniciar proceso de compra
  const handleBuy = (crypto: Cryptocurrency) => {
    setSelectedCrypto(crypto);
    setTradeAction("buy");
    setBuyAmount("");
    setShowBuySellModal(true);
  };

  // Iniciar proceso de venta
  const handleSell = (crypto: Cryptocurrency) => {
    setSelectedCrypto(crypto);
    setTradeAction("sell");
    setSellAmount("");
    setShowBuySellModal(true);
  };

  // Ejecutar transacción
  const handleExecuteTrade = () => {
    if (!selectedCrypto) return;
    
    const amount = tradeAction === "buy" ? buyAmount : sellAmount;
    
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive"
      });
      return;
    }
    
    // Simular transacción exitosa
    toast({
      title: `${tradeAction === "buy" ? "Purchase" : "Sale"} successful`,
      description: `You have ${tradeAction === "buy" ? "bought" : "sold"} ${amount} ${selectedCrypto.ticker}`,
      variant: "default"
    });
    
    // Cerrar modal
    setShowBuySellModal(false);
    
    // Limpiar formulario
    setBuyAmount("");
    setSellAmount("");
  };

  // Formatear valores numéricos
  const formatNumber = (num: number) => {
    if (num >= 1000000000) {
      return `$${(num / 1000000000).toFixed(2)}B`;
    }
    if (num >= 1000000) {
      return `$${(num / 1000000).toFixed(2)}M`;
    }
    if (num >= 1000) {
      return `$${(num / 1000).toFixed(2)}K`;
    }
    if (num < 1) {
      return `$${num.toFixed(4)}`;
    }
    return `$${num.toFixed(2)}`;
  };

  return (
    <>
      <Helmet>
        <title>Invest | D-OneCash</title>
        <meta name="description" content="Invest in cryptocurrencies with D-OneCash" />
      </Helmet>
      
      <div className="container mx-auto px-4 pb-20 max-w-4xl">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold">Invest</h1>
            <p className="text-muted-foreground">Buy and sell cryptocurrencies with D-OneCash</p>
          </div>
          
          <Tabs defaultValue="market" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="market">Market</TabsTrigger>
              <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
            
            {/* Market Tab */}
            <TabsContent value="market">
              <Card>
                <CardHeader>
                  <CardTitle>Crypto Market</CardTitle>
                  <CardDescription>
                    Explore and trade digital assets with low fees
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-2">#</th>
                          <th className="text-left py-3 px-2">Name</th>
                          <th className="text-right py-3 px-2">Price</th>
                          <th className="text-right py-3 px-2">24h %</th>
                          <th className="text-right py-3 px-2">Market Cap</th>
                          <th className="text-right py-3 px-2"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {cryptocurrencies.map((crypto, index) => (
                          <tr key={crypto.id} className="border-b hover:bg-accent/5">
                            <td className="py-4 px-2">{index + 1}</td>
                            <td className="py-4 px-2">
                              <div className="flex items-center gap-2">
                                {crypto.logo}
                                <div>
                                  <div className="font-medium">{crypto.name}</div>
                                  <div className="text-xs text-muted-foreground">{crypto.ticker}</div>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-2 text-right font-medium">
                              {formatNumber(crypto.price)}
                            </td>
                            <td className="py-4 px-2 text-right">
                              <span 
                                className={cn(
                                  "text-sm font-medium",
                                  crypto.change24h > 0 ? "text-green-500" : "text-red-500"
                                )}
                              >
                                {crypto.change24h > 0 ? "+" : ""}{crypto.change24h.toFixed(2)}%
                              </span>
                            </td>
                            <td className="py-4 px-2 text-right text-sm text-muted-foreground">
                              {formatNumber(crypto.marketCap)}
                            </td>
                            <td className="py-4 px-2">
                              <div className="flex items-center gap-1 justify-end">
                                <Button 
                                  variant="outline"
                                  size="sm"
                                  className="h-8 px-2 text-xs"
                                  onClick={() => handleBuy(crypto)}
                                >
                                  <ArrowDown className="mr-1 h-3 w-3" />
                                  Buy
                                </Button>
                                <Button 
                                  variant="outline"
                                  size="sm"
                                  className="h-8 px-2 text-xs"
                                  onClick={() => handleSell(crypto)}
                                >
                                  <ArrowUp className="mr-1 h-3 w-3" />
                                  Sell
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Portfolio Tab */}
            <TabsContent value="portfolio">
              <Card>
                <CardHeader>
                  <CardTitle>Your Portfolio</CardTitle>
                  <CardDescription>
                    Manage your cryptocurrency holdings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border p-6 flex flex-col items-center justify-center">
                    <DollarSign className="h-12 w-12 text-muted-foreground/50 mb-4" />
                    <h3 className="text-lg font-medium mb-2">No assets yet</h3>
                    <p className="text-sm text-muted-foreground text-center mb-4">
                      Start building your portfolio by buying some cryptocurrency
                    </p>
                    <Button onClick={() => setActiveTab("market")}>Explore Market</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* History Tab */}
            <TabsContent value="history">
              <Card>
                <CardHeader>
                  <CardTitle>Transaction History</CardTitle>
                  <CardDescription>
                    Your recent cryptocurrency transactions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border p-6 flex flex-col items-center justify-center">
                    <h3 className="text-lg font-medium mb-2">No transaction history</h3>
                    <p className="text-sm text-muted-foreground text-center mb-4">
                      Your transaction history will appear here
                    </p>
                    <Button onClick={() => setActiveTab("market")}>Start Trading</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Buy/Sell Modal */}
      {selectedCrypto && (
        <div className={`fixed inset-0 bg-background/80 flex items-center justify-center z-50 ${showBuySellModal ? 'block' : 'hidden'}`}>
          <div className="bg-card rounded-lg shadow-lg max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">
                {tradeAction === "buy" ? "Buy" : "Sell"} {selectedCrypto.name}
              </h3>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setShowBuySellModal(false)}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              </Button>
            </div>
            
            <div className="flex items-center gap-2 mb-4">
              {selectedCrypto.logo}
              <div>
                <div className="font-medium">{selectedCrypto.name}</div>
                <div className="text-sm text-muted-foreground">{selectedCrypto.ticker}</div>
              </div>
              <div className="ml-auto">
                <div className="font-medium">{formatNumber(selectedCrypto.price)}</div>
                <div className={cn(
                  "text-sm text-right",
                  selectedCrypto.change24h > 0 ? "text-green-500" : "text-red-500"
                )}>
                  {selectedCrypto.change24h > 0 ? "+" : ""}{selectedCrypto.change24h.toFixed(2)}%
                </div>
              </div>
            </div>
            
            <Separator className="my-4" />
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">
                  Amount to {tradeAction === "buy" ? "buy" : "sell"}
                </label>
                <div className="flex">
                  <Input
                    type="number"
                    placeholder={`Enter ${selectedCrypto.ticker} amount`}
                    value={tradeAction === "buy" ? buyAmount : sellAmount}
                    onChange={(e) => {
                      if (tradeAction === "buy") {
                        setBuyAmount(e.target.value);
                      } else {
                        setSellAmount(e.target.value);
                      }
                    }}
                    className="rounded-r-none"
                  />
                  <div className="bg-secondary flex items-center px-3 border border-l-0 border-input rounded-r-md">
                    {selectedCrypto.ticker}
                  </div>
                </div>
              </div>
              
              {tradeAction === "buy" && buyAmount && !isNaN(parseFloat(buyAmount)) && (
                <div className="p-3 bg-secondary/50 rounded-md">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Price</span>
                    <span>${selectedCrypto.price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Amount</span>
                    <span>{parseFloat(buyAmount).toFixed(6)} {selectedCrypto.ticker}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Fee (0.5%)</span>
                    <span>${(parseFloat(buyAmount) * selectedCrypto.price * 0.005).toFixed(2)}</span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>${(parseFloat(buyAmount) * selectedCrypto.price * 1.005).toFixed(2)}</span>
                  </div>
                </div>
              )}
              
              {tradeAction === "sell" && sellAmount && !isNaN(parseFloat(sellAmount)) && (
                <div className="p-3 bg-secondary/50 rounded-md">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Price</span>
                    <span>${selectedCrypto.price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Amount</span>
                    <span>{parseFloat(sellAmount).toFixed(6)} {selectedCrypto.ticker}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Fee (0.5%)</span>
                    <span>${(parseFloat(sellAmount) * selectedCrypto.price * 0.005).toFixed(2)}</span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between font-medium">
                    <span>You receive</span>
                    <span>${(parseFloat(sellAmount) * selectedCrypto.price * 0.995).toFixed(2)}</span>
                  </div>
                </div>
              )}
              
              <div className="pt-2">
                <Button
                  className="w-full"
                  onClick={handleExecuteTrade}
                >
                  {tradeAction === "buy" ? "Buy" : "Sell"} {selectedCrypto.ticker}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}