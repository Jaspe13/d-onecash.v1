import { Helmet } from "react-helmet";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { 
  Users, 
  Plus, 
  Edit2, 
  Trash2, 
  Shield, 
  AlertTriangle,
  Heart,
  Clock,
  Mail,
  Phone,
  User,
  Percent,
  FileText,
  Home,
  CheckCircle2,
  Info
} from "lucide-react";

interface Heir {
  id: number;
  name: string;
  email?: string;
  phone: string;
  relationship: string;
  percentage: number;
  documentType?: string;
  documentNumber?: string;
  address?: string;
  isActive: boolean;
}

interface InheritanceSettings {
  isEnabled: boolean;
  inactivityPeriodMonths: number;
  emergencyContact?: string;
  emergencyContactPhone?: string;
  lastActivity: Date;
  notificationsSent: number;
}

export default function Heirs() {
  const { toast } = useToast();
  const [heirs, setHeirs] = useState<Heir[]>([
    {
      id: 1,
      name: "Maria Rodriguez",
      email: "maria@email.com",
      phone: "+1 555-0123",
      relationship: "Spouse",
      percentage: 60,
      documentType: "Driver License",
      documentNumber: "DL123456789",
      address: "123 Main St, New York, NY 10001",
      isActive: true
    },
    {
      id: 2,
      name: "Carlos Rodriguez",
      email: "carlos@email.com",
      phone: "+1 555-0124",
      relationship: "Son",
      percentage: 25,
      documentType: "Passport",
      documentNumber: "P987654321",
      address: "456 Oak Ave, Los Angeles, CA 90001",
      isActive: true
    },
    {
      id: 3,
      name: "Ana Rodriguez",
      email: "ana@email.com",
      phone: "+1 555-0125",
      relationship: "Daughter",
      percentage: 15,
      documentType: "State ID",
      documentNumber: "ID555666777",
      address: "789 Pine St, Chicago, IL 60601",
      isActive: true
    }
  ]);

  const [settings, setSettings] = useState<InheritanceSettings>({
    isEnabled: true,
    inactivityPeriodMonths: 6,
    emergencyContact: "Emergency Contact",
    emergencyContactPhone: "+1 555-9999",
    lastActivity: new Date(),
    notificationsSent: 0
  });

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingHeir, setEditingHeir] = useState<Heir | null>(null);
  const [newHeir, setNewHeir] = useState({
    name: '',
    email: '',
    phone: '',
    relationship: '',
    percentage: 0,
    documentType: '',
    documentNumber: '',
    address: ''
  });

  const totalPercentage = heirs.reduce((sum, heir) => sum + heir.percentage, 0);
  const isValidDistribution = totalPercentage === 100;

  const handleAddHeir = () => {
    if (newHeir.name && newHeir.phone && newHeir.relationship && newHeir.percentage > 0) {
      const heir: Heir = {
        id: Date.now(),
        ...newHeir,
        isActive: true
      };
      setHeirs([...heirs, heir]);
      setNewHeir({
        name: '',
        email: '',
        phone: '',
        relationship: '',
        percentage: 0,
        documentType: '',
        documentNumber: '',
        address: ''
      });
      setIsAddDialogOpen(false);
      toast({
        title: "Heir added successfully",
        description: `${newHeir.name} has been added to your inheritance plan.`,
      });
    }
  };

  const handleDeleteHeir = (id: number) => {
    setHeirs(heirs.filter(heir => heir.id !== id));
    toast({
      title: "Heir removed",
      description: "The heir has been removed from your inheritance plan.",
    });
  };

  const handleUpdateSettings = (updates: Partial<InheritanceSettings>) => {
    setSettings({ ...settings, ...updates });
    toast({
      title: "Settings updated",
      description: "Your inheritance settings have been saved.",
    });
  };

  const relationships = [
    "Spouse",
    "Son",
    "Daughter",
    "Father",
    "Mother",
    "Brother",
    "Sister",
    "Partner",
    "Friend",
    "Other"
  ];

  const documentTypes = [
    "Driver License",
    "Passport",
    "State ID",
    "Social Security Card",
    "Birth Certificate",
    "Other"
  ];

  return (
    <>
      <Helmet>
        <title>Heirs & Inheritance | D-OneCash</title>
        <meta name="description" content="Manage your inheritance plan and designate beneficiaries for your D-OneCash account." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-green-600 bg-clip-text text-transparent">
                    Heirs & Inheritance
                  </h1>
                  <p className="text-muted-foreground mt-1">
                    Secure your family's financial future with our inheritance planning system
                  </p>
                </div>
              </div>
            </div>

            {/* Alert for total percentage */}
            {!isValidDistribution && heirs.length > 0 && (
              <Alert className="mb-6 border-amber-200 bg-amber-50 dark:bg-amber-950/20">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <AlertTitle className="text-amber-800 dark:text-amber-200">
                  Invalid Distribution
                </AlertTitle>
                <AlertDescription className="text-amber-700 dark:text-amber-300">
                  The total percentage must equal 100%. Current total: {totalPercentage}%
                </AlertDescription>
              </Alert>
            )}

            {/* Settings Card */}
            <Card className="mb-8 bg-background/80 backdrop-blur-sm border shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Inheritance Settings
                </CardTitle>
                <CardDescription>
                  Configure how your inheritance plan works and when it activates
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label className="text-base font-medium">Enable Inheritance Plan</Label>
                    <p className="text-sm text-muted-foreground">
                      Activate automatic inheritance distribution after account inactivity
                    </p>
                  </div>
                  <Switch
                    checked={settings.isEnabled}
                    onCheckedChange={(checked) => handleUpdateSettings({ isEnabled: checked })}
                  />
                </div>

                {settings.isEnabled && (
                  <>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Inactivity Period (Months)</Label>
                        <Input
                          type="number"
                          value={settings.inactivityPeriodMonths}
                          onChange={(e) => handleUpdateSettings({ inactivityPeriodMonths: parseInt(e.target.value) || 6 })}
                          min="1"
                          max="24"
                        />
                        <p className="text-xs text-muted-foreground">
                          Account must be inactive for this period before inheritance process begins
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label>Emergency Contact</Label>
                        <Input
                          value={settings.emergencyContact || ''}
                          onChange={(e) => handleUpdateSettings({ emergencyContact: e.target.value })}
                          placeholder="Emergency contact name"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Emergency Contact Phone</Label>
                      <Input
                        value={settings.emergencyContactPhone || ''}
                        onChange={(e) => handleUpdateSettings({ emergencyContactPhone: e.target.value })}
                        placeholder="+1 555-0000"
                      />
                    </div>

                    {/* Activity Status */}
                    <div className="p-4 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                        <span className="font-medium text-green-800 dark:text-green-200">Account Active</span>
                      </div>
                      <p className="text-sm text-green-700 dark:text-green-300">
                        Last activity: {settings.lastActivity.toLocaleDateString()} - Your account is active and inheritance plan is on standby.
                      </p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Heirs Management */}
            <Card className="bg-background/80 backdrop-blur-sm border shadow-lg">
              <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Designated Heirs
                    </CardTitle>
                    <CardDescription>
                      Add and manage beneficiaries who will receive your funds
                    </CardDescription>
                  </div>
                  
                  <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-gradient-to-r from-primary to-green-600 hover:from-primary/90 hover:to-green-600/90">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Heir
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Add New Heir</DialogTitle>
                        <DialogDescription>
                          Add a beneficiary to your inheritance plan with their contact details and inheritance percentage.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="name">Full Name *</Label>
                            <Input
                              id="name"
                              value={newHeir.name}
                              onChange={(e) => setNewHeir({ ...newHeir, name: e.target.value })}
                              placeholder="Enter full name"
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="relationship">Relationship *</Label>
                            <Select value={newHeir.relationship} onValueChange={(value) => setNewHeir({ ...newHeir, relationship: value })}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select relationship" />
                              </SelectTrigger>
                              <SelectContent>
                                {relationships.map((rel) => (
                                  <SelectItem key={rel} value={rel}>{rel}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="phone">Phone Number *</Label>
                            <Input
                              id="phone"
                              value={newHeir.phone}
                              onChange={(e) => setNewHeir({ ...newHeir, phone: e.target.value })}
                              placeholder="+1 555-0000"
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="percentage">Inheritance Percentage *</Label>
                            <Input
                              id="percentage"
                              type="number"
                              value={newHeir.percentage}
                              onChange={(e) => setNewHeir({ ...newHeir, percentage: parseFloat(e.target.value) || 0 })}
                              placeholder="25"
                              min="0.01"
                              max="100"
                              step="0.01"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="email">Email Address</Label>
                          <Input
                            id="email"
                            type="email"
                            value={newHeir.email}
                            onChange={(e) => setNewHeir({ ...newHeir, email: e.target.value })}
                            placeholder="heir@email.com"
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="documentType">Document Type</Label>
                            <Select value={newHeir.documentType} onValueChange={(value) => setNewHeir({ ...newHeir, documentType: value })}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select document type" />
                              </SelectTrigger>
                              <SelectContent>
                                {documentTypes.map((type) => (
                                  <SelectItem key={type} value={type}>{type}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="documentNumber">Document Number</Label>
                            <Input
                              id="documentNumber"
                              value={newHeir.documentNumber}
                              onChange={(e) => setNewHeir({ ...newHeir, documentNumber: e.target.value })}
                              placeholder="Document number"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="address">Address</Label>
                          <Textarea
                            id="address"
                            value={newHeir.address}
                            onChange={(e) => setNewHeir({ ...newHeir, address: e.target.value })}
                            placeholder="Complete address"
                            rows={3}
                          />
                        </div>
                      </div>
                      
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddHeir}>
                          Add Heir
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              
              <CardContent>
                {heirs.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No heirs designated</h3>
                    <p className="text-muted-foreground mb-4">
                      Start building your inheritance plan by adding beneficiaries
                    </p>
                    <Button onClick={() => setIsAddDialogOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Your First Heir
                    </Button>
                  </div>
                ) : (
                  <>
                    {/* Distribution Summary */}
                    <div className="mb-6 p-4 bg-accent/10 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium">Total Distribution</span>
                        <Badge variant={isValidDistribution ? "default" : "destructive"}>
                          {totalPercentage}%
                        </Badge>
                      </div>
                      <Progress value={totalPercentage} className="h-2" />
                      <p className="text-sm text-muted-foreground mt-2">
                        {isValidDistribution 
                          ? "✅ Perfect! Your inheritance is fully distributed." 
                          : `❌ Please adjust percentages. ${100 - totalPercentage}% remaining.`
                        }
                      </p>
                    </div>

                    {/* Heirs List */}
                    <div className="space-y-4">
                      {heirs.map((heir) => (
                        <div key={heir.id} className="border rounded-lg p-6 bg-background/50 hover:shadow-md transition-all duration-200">
                          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                            <div className="flex-1 space-y-3">
                              <div className="flex items-center gap-3">
                                <div className="p-2 bg-primary/10 rounded-full">
                                  <User className="h-4 w-4 text-primary" />
                                </div>
                                <div>
                                  <h3 className="font-semibold text-lg">{heir.name}</h3>
                                  <Badge variant="secondary" className="text-xs">
                                    {heir.relationship}
                                  </Badge>
                                </div>
                                <div className="ml-auto">
                                  <Badge variant="outline" className="text-lg font-semibold">
                                    {heir.percentage}%
                                  </Badge>
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                                <div className="flex items-center gap-2">
                                  <Phone className="h-4 w-4 text-muted-foreground" />
                                  <span>{heir.phone}</span>
                                </div>
                                {heir.email && (
                                  <div className="flex items-center gap-2">
                                    <Mail className="h-4 w-4 text-muted-foreground" />
                                    <span>{heir.email}</span>
                                  </div>
                                )}
                                {heir.documentType && heir.documentNumber && (
                                  <div className="flex items-center gap-2">
                                    <FileText className="h-4 w-4 text-muted-foreground" />
                                    <span>{heir.documentType}: {heir.documentNumber}</span>
                                  </div>
                                )}
                                {heir.address && (
                                  <div className="flex items-center gap-2 col-span-full">
                                    <Home className="h-4 w-4 text-muted-foreground" />
                                    <span>{heir.address}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setEditingHeir(heir)}
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteHeir(heir.id)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Information Section */}
            <Card className="mt-8 bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
                  <Info className="h-5 w-5" />
                  How Inheritance Works
                </CardTitle>
              </CardHeader>
              <CardContent className="text-blue-700 dark:text-blue-300">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 mt-0.5 text-blue-600" />
                    <div>
                      <h4 className="font-medium mb-1">Inactivity Detection</h4>
                      <p className="text-sm">
                        If your account remains inactive for {settings.inactivityPeriodMonths} months, we'll send notifications via email and SMS.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Mail className="h-5 w-5 mt-0.5 text-blue-600" />
                    <div>
                      <h4 className="font-medium mb-1">Final Notice</h4>
                      <p className="text-sm">
                        You'll have 7 days to confirm you're alive by opening the app and confirming your status.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Users className="h-5 w-5 mt-0.5 text-blue-600" />
                    <div>
                      <h4 className="font-medium mb-1">Fund Distribution</h4>
                      <p className="text-sm">
                        If no response, funds are distributed to designated heirs. Without heirs, funds are held for 1 year before joining company reserves.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}