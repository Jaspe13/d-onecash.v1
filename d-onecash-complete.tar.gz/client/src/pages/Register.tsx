import { useState } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { registerSchema } from "@shared/schema";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { D1CLogo } from "@/lib/D1CLogo";
import { LanguageToggle, t } from "@/components/ui/LanguageToggle";
import { ThemeToggle } from "@/components/ui/ThemeToggle";

export default function Register() {
  const [location, navigate] = useLocation();
  const [error, setError] = useState<string | null>(null);

  const form = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      email: "",
      phoneNumber: "",
      fullName: "",
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (values: z.infer<typeof registerSchema>) => {
      return apiRequest("/api/register", {
        method: "POST",
        body: JSON.stringify(values),
        headers: {
          "Content-Type": "application/json",
        },
      });
    },
    onSuccess: (data) => {
      // Almacenar información del usuario en localStorage (solo para demostración)
      localStorage.setItem("currentUser", JSON.stringify(data.user));
      navigate("/");
    },
    onError: (error: any) => {
      setError(error.message || t("register.error"));
    },
  });

  function onSubmit(values: z.infer<typeof registerSchema>) {
    setError(null);
    registerMutation.mutate(values);
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Helmet>
        <title>{t("register.title")} | D-OneCash</title>
        <meta name="description" content={t("register.description")} />
      </Helmet>

      {/* Header */}
      <header className="h-16 border-b flex items-center justify-end px-4">
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <LanguageToggle />
        </div>
      </header>

      {/* Main Content - Centered */}
      <div className="flex-1 flex flex-col items-center justify-center">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <img 
            src="/src/assets/d-onecash-logo.png" 
            alt="D-OneCash Logo" 
            className="h-32 w-auto mb-4"
          />
        </div>
        
        {/* Card */}
        <div className="w-full max-w-md px-6">
          <Card>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-center">
                {t("register.create_account")}
              </CardTitle>
              <CardDescription className="text-center">
                {t("register.enter_details")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("register.username")}</FormLabel>
                        <FormControl>
                          <Input placeholder={t("register.username_placeholder")} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("register.email")}</FormLabel>
                        <FormControl>
                          <Input 
                            type="email" 
                            placeholder={t("register.email_placeholder")} 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("register.password")}</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder={t("register.password_placeholder")} 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("register.full_name")}</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder={t("register.full_name_placeholder")} 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phoneNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("register.phone_number")}</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder={t("register.phone_placeholder")} 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending 
                      ? t("register.creating_account") 
                      : t("register.create_account")}
                  </Button>
                </form>
              </Form>

              <div className="mt-6 text-center">
                <p>
                  {t("register.already_have_account")}{" "}
                  <Button variant="link" className="p-0" onClick={() => navigate("/login")}>
                    {t("register.sign_in")}
                  </Button>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}