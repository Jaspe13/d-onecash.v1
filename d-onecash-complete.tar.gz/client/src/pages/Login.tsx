import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { loginSchema } from "@shared/schema";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { AlertCircle, Fingerprint, Camera, Check } from "lucide-react";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import logoImage from "@assets/D-OneCash.png";

export default function Login() {
  const [location, navigate] = useLocation();
  const [error, setError] = useState<string | null>(null);
  const [showFaceIdDialog, setShowFaceIdDialog] = useState(false);
  const [faceIdStep, setFaceIdStep] = useState(1);
  
  // Función que simula el inicio de sesión con Face ID
  const handleFaceIdLogin = () => {
    setError(null);
    
    // Crear un usuario demo para la simulación
    const demoUser = {
      id: 1,
      username: 'usuario_demo',
      email: 'demo@d-onecash.com',
      fullName: 'Usuario Demo'
    };
    localStorage.setItem("currentUser", JSON.stringify(demoUser));
    
    setShowFaceIdDialog(true);
    setFaceIdStep(1);
  };
  
  // Función que inicializa el escaneo facial
  const startFaceIdScan = () => {
    setFaceIdStep(2);
    // Simulamos el escaneo y luego el éxito después de un tiempo
    setTimeout(() => {
      setFaceIdStep(3);
      // Esperamos un momento más y luego iniciamos sesión
      setTimeout(() => {
        setShowFaceIdDialog(false);
        navigate("/");
      }, 1500);
    }, 2000);
  };

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (values: z.infer<typeof loginSchema>) => {
      return apiRequest("/api/login", {
        method: "POST",
        body: JSON.stringify(values),
        headers: {
          "Content-Type": "application/json",
        },
      });
    },
    onSuccess: (data) => {
      localStorage.setItem("currentUser", JSON.stringify(data.user));
      navigate("/");
    },
    onError: (error: any) => {
      setError(error.message || "Error de inicio de sesión. Por favor, intente de nuevo.");
    },
  });

  function onSubmit(values: z.infer<typeof loginSchema>) {
    setError(null);
    loginMutation.mutate(values);
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Helmet>
        <title>Iniciar Sesión | D-OneCash</title>
        <meta name="description" content="Accede a tu cuenta D-OneCash para gestionar tus finanzas digitales." />
      </Helmet>
      
      {/* Diálogo de Face ID */}
      <Dialog open={showFaceIdDialog} onOpenChange={setShowFaceIdDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-center flex-col">
              {faceIdStep === 1 && (
                <>
                  <Camera className="h-16 w-16 text-emerald-500 mb-3" />
                  <span>Face ID</span>
                </>
              )}
              {faceIdStep === 2 && (
                <>
                  <div className="flex flex-col items-center justify-center relative">
                    <div className="h-32 w-32 rounded-full border-4 border-emerald-500 flex items-center justify-center mb-3 relative overflow-hidden">
                      <div className="absolute top-0 left-0 h-full w-full bg-emerald-500/20 z-10"></div>
                      <div className="absolute top-0 left-0 h-full w-full flex items-center justify-center">
                        <div className="h-24 w-24 rounded-full bg-foreground/20 flex items-center justify-center">
                          <Fingerprint className="h-12 w-12 text-foreground" />
                        </div>
                      </div>
                      <div className="absolute top-0 left-0 h-0 w-full bg-emerald-500/30 z-20"></div>
                    </div>
                    <span>Verificando...</span>
                  </div>
                </>
              )}
              {faceIdStep === 3 && (
                <>
                  <div className="h-16 w-16 rounded-full bg-emerald-500 flex items-center justify-center mb-3">
                    <Check className="h-10 w-10 text-white" />
                  </div>
                  <span>¡Verificado!</span>
                </>
              )}
            </DialogTitle>
            <DialogDescription className="text-center pt-4">
              {faceIdStep === 1 && "Posiciona tu rostro frente a la cámara para iniciar sesión"}
              {faceIdStep === 2 && "Mantén tu rostro centrado y quieto"}
              {faceIdStep === 3 && "Iniciando sesión..."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center items-center py-4">
            {faceIdStep === 1 && (
              <Button 
                onClick={startFaceIdScan}
                className="mx-auto bg-emerald-600 hover:bg-emerald-700"
              >
                Iniciar escáner
              </Button>
            )}
            {faceIdStep === 2 && (
              <div className="h-10 flex items-center justify-center">
                <span className="text-sm text-muted-foreground">Escaneando...</span>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <header className="h-16 border-b flex items-center justify-end px-4">
        <div className="flex items-center gap-3">
          <ThemeToggle />
        </div>
      </header>

      {/* Main Content - Centered */}
      <div className="flex-1 flex flex-col items-center justify-center">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <img 
            src={logoImage} 
            alt="D-OneCash Logo" 
            className="h-48 w-auto mb-4" 
          />
        </div>
        
        {/* Card */}
        <div className="w-full max-w-md px-6">
          <Card>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-center">
                Bienvenido de nuevo
              </CardTitle>
              <CardDescription className="text-center">
                Ingresa tus credenciales para acceder
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Enter your password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing in..." : "Sign In"}
                  </Button>
                  
                  <div className="mt-4 flex justify-center">
                    <Button 
                      variant="outline"
                      className="flex items-center gap-2"
                      onClick={handleFaceIdLogin}
                      type="button"
                    >
                      <Fingerprint className="w-4 h-4" />
                      Sign in with Face ID
                    </Button>
                  </div>
                </form>
              </Form>

              <div className="mt-6 text-center">
                <p>
                  Don't have an account?{" "}
                  <Button variant="link" className="p-0" onClick={() => navigate("/register")}>
                    Create Account
                  </Button>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}