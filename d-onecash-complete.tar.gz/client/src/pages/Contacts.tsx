import { Helmet } from "react-helmet";
import { t } from "@/components/ui/LanguageToggle";
import ContactsList from "@/components/ContactsList";

export default function Contacts() {
  return (
    <div className="container py-4 mx-auto max-w-4xl">
      <Helmet>
        <title>D-OneCash - Contacts</title>
      </Helmet>
      
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">My Contacts</h1>
          <p className="text-muted-foreground">Manage your contacts for quick money transfers</p>
        </div>
        
        <ContactsList />
      </div>
    </div>
  );
}