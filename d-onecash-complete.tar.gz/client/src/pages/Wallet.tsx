import { Helmet } from "react-helmet";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useWallet } from "@/hooks/useWallet";
import TransactionHistory from "@/components/TransactionHistory";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import AddMoneyModal from "@/components/AddMoneyModal";

export default function Wallet() {
  const { balance } = useWallet();
  const { toast } = useToast();
  const [addMoneyDialogOpen, setAddMoneyDialogOpen] = useState(false);
  
  // Estados para staking
  const [stakingDialogOpen, setStakingDialogOpen] = useState(false);
  const [stakingAmount, setStakingAmount] = useState("");
  const [stakingPeriod, setStakingPeriod] = useState("1");
  const [hasStakingPosition, setHasStakingPosition] = useState(false);
  const [activeStakingAmount, setActiveStakingAmount] = useState(0);
  const [stakingEndDate, setStakingEndDate] = useState<Date | null>(null);
  const [expectedReward, setExpectedReward] = useState(0);
  
  // Estados para tarjetas virtuales
  const [hasVirtualCard, setHasVirtualCard] = useState(false);
  const [createCardDialogOpen, setCreateCardDialogOpen] = useState(false);
  const [viewCardDetailsOpen, setViewCardDetailsOpen] = useState(false);
  const [physicalCardDialogOpen, setPhysicalCardDialogOpen] = useState(false);
  const [reloadCardDialogOpen, setReloadCardDialogOpen] = useState(false);
  const [addCardDialogOpen, setAddCardDialogOpen] = useState(false);
  const [cardLastFour, setCardLastFour] = useState("4321");
  const [cardHolder, setCardHolder] = useState("JUAN PÉREZ");
  const [cardExpiry, setCardExpiry] = useState("02/28");
  const [cardNumber, setCardNumber] = useState("**** **** **** 4321");
  const [cardCVV, setCardCVV] = useState("***");
  const [showCardDetails, setShowCardDetails] = useState(false);
  const [cardBalance, setCardBalance] = useState(200.50);
  const [reloadAmount, setReloadAmount] = useState("");
  const [isCardLocked, setIsCardLocked] = useState(false);
  const [cardSecurityDialogOpen, setCardSecurityDialogOpen] = useState(false);
  
  // Calcular la recompensa esperada según el monto y periodo
  const calculateReward = (amount: number, months: number) => {
    const annualRate = 0.069; // 6.9% anual
    const monthlyRate = annualRate / 12;
    return amount * monthlyRate * months;
  };
  
  // Calcular la APR según el periodo
  const getAPR = (months: number) => {
    // Base APR is 6.9%
    const baseApr = 6.9;
    
    // Bonus APR based on staking period
    let bonusApr = 0;
    if (months >= 12) {
      bonusApr = 0.3; // +0.3% for 12 months
    } else if (months >= 6) {
      bonusApr = 0.2; // +0.2% for 6 months
    } else if (months >= 3) {
      bonusApr = 0.1; // +0.1% for 3 months
    }
    
    return (baseApr + bonusApr).toFixed(1);
  };
  
  // Actualizar cálculos cuando cambia el monto o periodo
  const updateCalculations = () => {
    const amount = parseFloat(stakingAmount) || 0;
    const months = parseInt(stakingPeriod) || 1;
    const reward = calculateReward(amount, months);
    setExpectedReward(reward);
  };
  
  const handleStakingAmountChange = (value: string) => {
    setStakingAmount(value);
    updateCalculations();
  };
  
  const handleStakingPeriodChange = (value: string) => {
    setStakingPeriod(value);
    updateCalculations();
  };
  
  const handleMaxAmount = () => {
    // Usar el 95% del balance como máximo para staking
    const maxAmount = Math.floor(balance * 0.95);
    setStakingAmount(maxAmount.toString());
    updateCalculations();
  };
  
  const handleStartStaking = () => {
    const amount = parseFloat(stakingAmount);
    const months = parseInt(stakingPeriod);
    
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0",
        variant: "destructive",
      });
      return;
    }
    
    if (amount > balance) {
      toast({
        title: "Insufficient Funds",
        description: "You don't have enough funds to stake this amount",
        variant: "destructive",
      });
      return;
    }
    
    if (amount < 100) {
      toast({
        title: "Minimum Amount Not Reached",
        description: "The minimum amount for staking is 100 D1C",
        variant: "destructive",
      });
      return;
    }
    
    // Simular la creación de una posición de staking
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + months);
    
    setActiveStakingAmount(amount);
    setStakingEndDate(endDate);
    setHasStakingPosition(true);
    setStakingDialogOpen(false);
    
    toast({
      title: "Staking Started",
      description: `You have locked ${amount} D1C for ${months} ${months === 1 ? 'month' : 'months'}`,
      variant: "default",
    });
  };
  
  // Calcular días restantes para el periodo de staking
  const getRemainingDays = () => {
    if (!stakingEndDate) return 0;
    
    const now = new Date();
    const diffTime = stakingEndDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  };
  
  // Calcular el progreso del período de staking
  const getStakingProgress = () => {
    if (!stakingEndDate) return 0;
    
    const period = parseInt(stakingPeriod);
    const totalDays = period * 30; // Aproximación de días por mes
    const remainingDays = getRemainingDays();
    const elapsedDays = totalDays - remainingDays;
    
    return Math.min(100, Math.max(0, (elapsedDays / totalDays) * 100));
  };
  
  // Simular retiro anticipado
  const handleEarlyWithdrawal = () => {
    toast({
      title: "Staking Released",
      description: `You have withdrawn ${activeStakingAmount} D1C before the deadline. You will not receive rewards.`,
      variant: "default",
    });
    
    setHasStakingPosition(false);
    setActiveStakingAmount(0);
    setStakingEndDate(null);
  };
  
  return (
    <>
      <Helmet>
        <title>Wallet | D-OneCash</title>
        <meta name="description" content="Manage your D-OneCash wallet, transactions and balances." />
      </Helmet>
      
      {/* Modal para añadir fondos */}
      <AddMoneyModal 
        isOpen={addMoneyDialogOpen} 
        onClose={() => setAddMoneyDialogOpen(false)} 
      />
      
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Your Wallet</h1>
        
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <CardTitle>Total Balance</CardTitle>
            <CardDescription>Your available funds</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row items-start sm:items-baseline justify-between space-y-4 sm:space-y-0">
              <div>
                <span className="text-3xl font-bold">
                  {new Intl.NumberFormat('es-ES', {
                    style: 'currency',
                    currency: 'USD',
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  }).format(balance)}
                </span>
                <span className="ml-2 text-muted-foreground">USD</span>
                <div className="mt-1 text-xs text-muted-foreground">
                  ≈ {balance.toFixed(2)} D1C
                  <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary ml-2">1 D1C = 1 USD</span>
                </div>
              </div>
              <Button 
                variant="outline" 
                className="bg-green-500 text-white hover:bg-green-600 rounded-full w-full sm:w-auto transition-all shadow-sm hover:shadow-md"
                onClick={() => setAddMoneyDialogOpen(true)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Add Funds
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue={window.location.search.includes('tab=cards') ? 'cards' : window.location.search.includes('tab=staking') ? 'staking' : 'transactions'} className="mb-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="cards">Cards</TabsTrigger>
            <TabsTrigger value="staking">Staking</TabsTrigger>
          </TabsList>
          
          <TabsContent value="transactions" className="mt-4">
            <TransactionHistory />
          </TabsContent>
          
          <TabsContent value="cards" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Virtual Cards</CardTitle>
                <CardDescription>Manage your payment cards</CardDescription>
              </CardHeader>
              {!hasVirtualCard ? (
                <CardContent className="flex flex-col items-center justify-center py-8">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-muted-foreground mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect width="20" height="14" x="2" y="5" rx="2"></rect>
                    <line x1="2" x2="22" y1="10" y2="10"></line>
                  </svg>
                  <p className="text-center text-muted-foreground mb-4">
                    You don't have any virtual cards yet.
                  </p>
                  <Button onClick={() => setCreateCardDialogOpen(true)}>
                    Create Virtual Card
                  </Button>
                </CardContent>
              ) : (
                <CardContent className="py-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                    {/* Tarjeta principal mejorada */}
                    <div 
                      className="relative bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-800 rounded-2xl p-6 text-white aspect-[1.6/1] flex flex-col justify-between cursor-pointer hover:scale-105 transition-all duration-300 shadow-xl overflow-hidden"
                      onClick={() => setViewCardDetailsOpen(true)}
                    >
                      {/* Patrón de fondo decorativo */}
                      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-white/10 to-transparent rounded-full -mr-16 -mt-16"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-white/5 to-transparent rounded-full -ml-12 -mb-12"></div>
                      
                      <div className="flex justify-between items-start relative z-10">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-8 h-6 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-sm flex items-center justify-center">
                              <div className="w-3 h-2 bg-yellow-600 rounded-[1px]"></div>
                            </div>
                            <p className="text-xs opacity-90 font-medium">CHIP</p>
                          </div>
                          <p className="text-xs opacity-80 mb-1">D-OneCash Virtual</p>
                          <h3 className="text-lg font-bold">VISA DEBIT</h3>
                        </div>
                        <div className="text-right">
                          <svg className="h-10 w-16 opacity-90" viewBox="0 0 64 20" fill="currentColor">
                            <path d="M25.5 2h13l-6.5 16h-13l6.5-16zm-10.5 0h-13l-6.5 16h13l6.5-16zm26 0h13l6.5 16h-13l-6.5-16z"/>
                            <text x="32" y="14" fontSize="8" textAnchor="middle" fill="currentColor" fontWeight="bold">VISA</text>
                          </svg>
                        </div>
                      </div>
                      
                      <div className="relative z-10 space-y-4">
                        <p className="text-lg font-mono tracking-[0.2em] font-medium">**** **** **** {cardLastFour}</p>
                        
                        <div className="flex justify-between items-end">
                          <div>
                            <p className="text-xs opacity-80 mb-1">CARD HOLDER</p>
                            <p className="text-sm font-medium">DEMO USER</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs opacity-80 mb-1">VALID THRU</p>
                            <p className="text-sm font-medium">{cardExpiry}</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Badge de balance */}
                      <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1">
                        <p className="text-xs font-medium">${cardBalance.toFixed(2)}</p>
                      </div>
                    </div>
                    
                    {/* Botón para añadir nueva tarjeta mejorado */}
                    <div 
                      className="border-2 border-dashed border-accent-foreground/20 rounded-2xl p-6 aspect-[1.6/1] flex flex-col justify-center items-center cursor-pointer hover:border-primary hover:bg-primary/5 transition-all duration-300 group"
                      onClick={() => setAddCardDialogOpen(true)}
                    >
                      <div className="bg-primary/10 h-16 w-16 rounded-full flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="12" y1="5" x2="12" y2="19"></line>
                          <line x1="5" y1="12" x2="19" y2="12"></line>
                        </svg>
                      </div>
                      <h3 className="text-base font-semibold mb-2">Add New Card</h3>
                      <p className="text-sm text-muted-foreground text-center">Create another virtual card for your transactions</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                      <div className="flex items-center">
                        <div className="bg-primary/10 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M17 8h1a4 4 0 1 1 0 8h-1"></path>
                            <path d="M6 8H5a4 4 0 1 0 0 8h1"></path>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                          </svg>
                        </div>
                        <p className="text-xs opacity-80 mb-1">Titular</p>
                        <p className="text-sm font-medium">{cardHolder}</p>
                      </div>
                      <div>
                        <p className="text-xs opacity-80 mb-1">Expira</p>
                        <p className="text-sm font-medium">{cardExpiry}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                      <div className="flex items-center">
                        <div className="bg-primary/10 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M17 8h1a4 4 0 1 1 0 8h-1"></path>
                            <path d="M6 8H5a4 4 0 1 0 0 8h1"></path>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                          </svg>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Detalles de la Tarjeta</h4>
                          <p className="text-xs text-muted-foreground">Ver información completa</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => setViewCardDetailsOpen(true)}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m9 18 6-6-6-6"></path>
                        </svg>
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                      <div className="flex items-center">
                        <div className="bg-primary/10 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                          </svg>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Solicitar Tarjeta Física</h4>
                          <p className="text-xs text-muted-foreground">Costo: $6.00 USD</p>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setPhysicalCardDialogOpen(true)}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m9 18 6-6-6-6"></path>
                        </svg>
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                      <div className="flex items-center">
                        <div className="bg-primary/10 p-2 rounded-full mr-3">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M12 2v20"></path>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                          </svg>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Recargar Tarjeta</h4>
                          <p className="text-xs text-muted-foreground">Añadir fondos desde tu billetera</p>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setReloadCardDialogOpen(true)}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m9 18 6-6-6-6"></path>
                        </svg>
                      </Button>
                    </div>
                    
                    <div className="flex justify-between items-center p-3 bg-accent rounded-lg">
                      <div className="flex items-center">
                        <div className={`p-2 rounded-full mr-3 ${isCardLocked ? 'bg-red-100' : 'bg-primary/10'}`}>
                          <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${isCardLocked ? 'text-red-600' : 'text-primary'}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            {isCardLocked ? (
                              <>
                                <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                              </>
                            ) : (
                              <>
                                <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 5.8-4.9 5 5 0 0 1 4.2 4.9"></path>
                                <path d="M15 11h4l-3-3"></path>
                                <path d="M16 8v3"></path>
                              </>
                            )}
                          </svg>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Card Security</h4>
                          <p className={`text-xs ${isCardLocked ? 'text-red-600' : 'text-muted-foreground'}`}>
                            {isCardLocked ? 'Card is locked' : 'Lock/Unlock card'}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => setCardSecurityDialogOpen(true)}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m9 18 6-6-6-6"></path>
                        </svg>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
          </TabsContent>
          
          <TabsContent value="staking" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Staking</CardTitle>
                <CardDescription>Gana recompensas bloqueando tus tokens D1C</CardDescription>
              </CardHeader>
              <CardContent>
                {!hasStakingPosition ? (
                  <div className="flex flex-col items-center justify-center py-6">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-muted-foreground mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 2v20"></path>
                      <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                    <p className="text-center text-muted-foreground mb-4">
                      No tienes posiciones de staking activas.
                    </p>
                    
                    <div className="bg-secondary p-4 rounded-lg mb-4 w-full">
                      <h3 className="text-center font-bold mb-2">Gana hasta 7.2% APR</h3>
                      <p className="text-center text-sm text-muted-foreground mb-2">
                        Bloquea tus tokens D1C y gana intereses.
                      </p>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Monto Mínimo</span>
                        <span>100 D1C</span>
                      </div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Período de Bloqueo</span>
                        <span>1, 2, 3, 6 o 12 Meses</span>
                      </div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Retiro Anticipado</span>
                        <span>Sin penalización</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Pago de Recompensas</span>
                        <span>Al finalizar el período</span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 w-full mb-4">
                      <div className="bg-accent p-3 rounded-lg text-center">
                        <h4 className="font-medium text-sm mb-1">1-2 Meses</h4>
                        <p className="text-xl font-bold text-primary">6.9% APR</p>
                      </div>
                      <div className="bg-accent p-3 rounded-lg text-center">
                        <h4 className="font-medium text-sm mb-1">3-6 Meses</h4>
                        <p className="text-xl font-bold text-primary">7.0% APR</p>
                      </div>
                      <div className="bg-accent p-3 rounded-lg text-center">
                        <h4 className="font-medium text-sm mb-1">12 Meses</h4>
                        <p className="text-xl font-bold text-primary">7.2% APR</p>
                      </div>
                    </div>
                    
                    <Button onClick={() => setStakingDialogOpen(true)}>
                      Comenzar Staking
                    </Button>
                  </div>
                ) : (
                  <div className="py-4">
                    <div className="bg-accent p-4 rounded-lg mb-4">
                      <div className="flex justify-between items-center mb-3">
                        <h3 className="font-bold">Posición de Staking Activa</h3>
                        <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                          {getAPR(parseInt(stakingPeriod))}% APR
                        </span>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-muted-foreground">Monto Bloqueado</span>
                            <span className="font-medium">{activeStakingAmount.toFixed(2)} D1C</span>
                          </div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-muted-foreground">Fecha de Finalización</span>
                            <span className="font-medium">
                              {stakingEndDate?.toLocaleDateString('es-ES', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric'
                              })}
                            </span>
                          </div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-muted-foreground">Días Restantes</span>
                            <span className="font-medium">{getRemainingDays()} días</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Recompensa Estimada</span>
                            <span className="font-medium text-primary">
                              +{calculateReward(activeStakingAmount, parseInt(stakingPeriod)).toFixed(2)} D1C
                            </span>
                          </div>
                        </div>
                        
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Progreso</span>
                            <span>{Math.round(getStakingProgress())}%</span>
                          </div>
                          <Progress value={getStakingProgress()} className="h-2" />
                        </div>
                        
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={handleEarlyWithdrawal}
                        >
                          Retirar Anticipadamente
                        </Button>
                      </div>
                    </div>
                    
                    <div className="text-sm text-muted-foreground">
                      <p className="mb-2">
                        <span className="font-medium text-foreground">Nota:</span> El retiro anticipado es posible en cualquier momento, pero perderás las recompensas acumuladas.
                      </p>
                      <p>
                        Las recompensas se calculan diariamente pero se pagan al final del período de staking.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Diálogo de staking */}
      <Dialog open={stakingDialogOpen} onOpenChange={setStakingDialogOpen}>
        <DialogContent className="bg-secondary text-foreground sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Comenzar Staking</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Bloquea tus tokens D1C y gana recompensas.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Monto a Bloquear</label>
              <div className="relative">
                <Input
                  type="text"
                  inputMode="decimal"
                  placeholder="0.00"
                  className="pl-14 pr-20"
                  value={stakingAmount}
                  onChange={(e) => handleStakingAmountChange(e.target.value)}
                />
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                  D1C
                </span>
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <Button 
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={handleMaxAmount}
                    className="h-7 text-xs"
                  >
                    Max
                  </Button>
                </div>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Monto mínimo: 100 D1C
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Período de Staking</label>
              <Select 
                value={stakingPeriod} 
                onValueChange={handleStakingPeriodChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Mes - 6.9% APR</SelectItem>
                  <SelectItem value="2">2 Meses - 6.9% APR</SelectItem>
                  <SelectItem value="3">3 Meses - 7.0% APR</SelectItem>
                  <SelectItem value="6">6 Meses - 7.0% APR</SelectItem>
                  <SelectItem value="12">12 Meses - 7.2% APR</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="bg-accent rounded-lg p-3">
              <div className="flex justify-between text-sm mb-2">
                <span>Cantidad a Bloquear</span>
                <span className="font-mono">
                  {parseFloat(stakingAmount || "0").toFixed(2)} D1C
                </span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span>APR</span>
                <span className="font-mono text-primary">
                  {getAPR(parseInt(stakingPeriod))}%
                </span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span>Fecha de Finalización</span>
                <span className="font-mono">
                  {(() => {
                    const date = new Date();
                    date.setMonth(date.getMonth() + parseInt(stakingPeriod));
                    return date.toLocaleDateString('es-ES', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric'
                    });
                  })()}
                </span>
              </div>
              <div className="border-t border-secondary my-2"></div>
              <div className="flex justify-between text-sm font-medium">
                <span>Recompensa Estimada</span>
                <span className="font-mono text-primary">
                  +{expectedReward.toFixed(2)} D1C
                </span>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setStakingDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleStartStaking}>
              Comenzar Staking
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo para crear tarjeta virtual */}
      <Dialog open={createCardDialogOpen} onOpenChange={setCreateCardDialogOpen}>
        <DialogContent className="bg-secondary text-foreground sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Crear Tarjeta Virtual</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Crea una tarjeta virtual para tus compras en línea de forma segura.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-3">
            <div className="bg-gradient-to-r from-primary to-primary/80 rounded-xl p-5 text-primary-foreground">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <p className="text-xs opacity-80 mb-1">D-OneCash Virtual Card</p>
                  <h3 className="text-lg font-bold">Tarjeta Virtual</h3>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="20" height="14" x="2" y="5" rx="2"></rect>
                  <line x1="2" x2="22" y1="10" y2="10"></line>
                </svg>
              </div>
              <div className="mb-6">
                <p className="text-sm font-mono tracking-wider text-center">**** **** **** ****</p>
              </div>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-xs opacity-80 mb-1">Titular</p>
                  <p className="text-sm font-medium">{cardHolder}</p>
                </div>
                <div>
                  <p className="text-xs opacity-80 mb-1">Expira</p>
                  <p className="text-sm font-medium">--/--</p>
                </div>
              </div>
            </div>
            
            <div className="bg-accent p-4 rounded-lg">
              <h4 className="text-sm font-medium mb-3">Beneficios de la Tarjeta Virtual</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5"></path>
                  </svg>
                  <span>Compras en línea seguras</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5"></path>
                  </svg>
                  <span>Sin cuota de emisión o mantenimiento</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5"></path>
                  </svg>
                  <span>Controla tus gastos fácilmente</span>
                </li>
              </ul>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateCardDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              setHasVirtualCard(true);
              setCreateCardDialogOpen(false);
              toast({
                title: "Tarjeta Virtual Creada",
                description: "Tu nueva tarjeta virtual ha sido creada con éxito.",
                variant: "default",
              });
            }}>
              Crear Tarjeta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo para ver detalles de la tarjeta */}
      <Dialog open={viewCardDetailsOpen} onOpenChange={setViewCardDetailsOpen}>
        <DialogContent className="bg-secondary text-foreground sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detalles de la Tarjeta</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Información confidencial de tu tarjeta virtual.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-3">
            <div className="bg-gradient-to-r from-primary to-primary/80 rounded-xl p-5 text-primary-foreground">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <p className="text-xs opacity-80 mb-1">D-OneCash Virtual Card</p>
                  <h3 className="text-lg font-bold">Tarjeta Virtual</h3>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="20" height="14" x="2" y="5" rx="2"></rect>
                  <line x1="2" x2="22" y1="10" y2="10"></line>
                </svg>
              </div>
              <div className="mb-6">
                <p className="text-sm font-mono tracking-wider text-center">
                  {showCardDetails ? "4539 1657 4829 4321" : "**** **** **** 4321"}
                </p>
              </div>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-xs opacity-80 mb-1">Titular</p>
                  <p className="text-sm font-medium">{cardHolder}</p>
                </div>
                <div>
                  <p className="text-xs opacity-80 mb-1">Expira</p>
                  <p className="text-sm font-medium">{cardExpiry}</p>
                </div>
                <div>
                  <p className="text-xs opacity-80 mb-1">CVV</p>
                  <p className="text-sm font-medium">{showCardDetails ? "123" : "***"}</p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-center">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowCardDetails(!showCardDetails)}
              >
                {showCardDetails ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path>
                    <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path>
                    <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path>
                    <line x1="2" x2="22" y1="2" y2="22"></line>
                  </svg>
                )}
                {showCardDetails ? "Ocultar Detalles" : "Mostrar Detalles"}
              </Button>
            </div>
            
            <div className="bg-accent p-4 rounded-lg">
              <h4 className="text-sm font-medium mb-2">Información de la Tarjeta</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Tipo de Tarjeta</span>
                  <span className="text-xs font-medium">Visa Débito Virtual</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Estado</span>
                  <span className="text-xs font-medium text-green-500">Activa</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Fecha de Emisión</span>
                  <span className="text-xs font-medium">{new Date().toLocaleDateString('es-ES')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs text-muted-foreground">Límite Diario</span>
                  <span className="text-xs font-medium">$1,000.00 USD</span>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => {
              navigator.clipboard.writeText("4539165748294321");
              toast({
                title: "Número Copiado",
                description: "Número de tarjeta copiado al portapapeles",
                variant: "default",
              });
            }}>
              Copiar Número
            </Button>
            <Button variant="outline" size="sm" onClick={() => {
              navigator.clipboard.writeText("123");
              toast({
                title: "CVV Copiado",
                description: "Código de seguridad copiado al portapapeles",
                variant: "default",
              });
            }}>
              Copiar CVV
            </Button>
            <Button onClick={() => setViewCardDetailsOpen(false)}>
              Cerrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo para solicitar tarjeta física */}
      <Dialog open={physicalCardDialogOpen} onOpenChange={setPhysicalCardDialogOpen}>
        <DialogContent className="bg-secondary text-foreground sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Solicitar Tarjeta Física</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Solicita una tarjeta física vinculada a tu cuenta D-OneCash.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-3">
            <div className="bg-accent p-4 rounded-lg">
              <h4 className="text-sm font-medium mb-3">Detalles de la Solicitud</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Costo de emisión</span>
                  <span className="text-sm font-medium">$6.00 USD</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Tiempo de entrega</span>
                  <span className="text-sm font-medium">7-10 días hábiles</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Validez</span>
                  <span className="text-sm font-medium">4 años</span>
                </div>
              </div>
            </div>
            
            <div className="border border-accent p-4 rounded-lg">
              <h4 className="text-sm font-medium mb-3">Beneficios</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5"></path>
                  </svg>
                  <span>Aceptada en millones de comercios físicos</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5"></path>
                  </svg>
                  <span>Tecnología contactless para pagos rápidos</span>
                </li>
                <li className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5"></path>
                  </svg>
                  <span>Retiros en cajeros automáticos</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-yellow-50 p-3 rounded-lg">
              <div className="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                  <line x1="12" x2="12" y1="9" y2="13"></line>
                  <line x1="12" x2="12.01" y1="17" y2="17"></line>
                </svg>
                <p className="text-xs text-yellow-800">El costo de la tarjeta será debitado de tu saldo D-OneCash. Asegúrate de tener fondos suficientes.</p>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setPhysicalCardDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              if (balance >= 6) {
                setPhysicalCardDialogOpen(false);
                toast({
                  title: "Tarjeta Física Solicitada",
                  description: "Tu tarjeta física ha sido solicitada. Se te ha cobrado $6.00 USD.",
                  variant: "default",
                });
              } else {
                toast({
                  title: "Fondos Insuficientes",
                  description: "No tienes suficiente saldo para solicitar una tarjeta física.",
                  variant: "destructive",
                });
              }
            }}>
              Solicitar por $6.00
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo para recargar tarjeta */}
      <Dialog open={reloadCardDialogOpen} onOpenChange={setReloadCardDialogOpen}>
        <DialogContent className="bg-secondary text-foreground sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Recargar Tarjeta Virtual</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Añade fondos a tu tarjeta virtual desde tu billetera D-OneCash.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-3">
            <div className="bg-accent rounded-lg p-4">
              <div className="flex justify-between text-sm mb-1">
                <span>Saldo en Billetera</span>
                <span className="font-medium">${balance.toFixed(2)} USDC</span>
              </div>
              <div className="flex justify-between text-sm mb-1">
                <span>Saldo Actual en Tarjeta</span>
                <span className="font-medium">${cardBalance.toFixed(2)}</span>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Monto a Recargar</label>
              <div className="relative">
                <Input
                  type="text"
                  inputMode="decimal"
                  placeholder="0.00"
                  className="pl-6 pr-4"
                  value={reloadAmount}
                  onChange={(e) => setReloadAmount(e.target.value)}
                />
                <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                El monto se descontará de tu saldo en la billetera D-OneCash.
              </p>
            </div>
            
            <div className="flex gap-2">
              {[50, 100, 200, 500].map((amount) => (
                <Button
                  key={amount}
                  variant="outline"
                  size="sm"
                  onClick={() => setReloadAmount(amount.toString())}
                >
                  ${amount}
                </Button>
              ))}
            </div>
            
            <div className="bg-primary/10 p-3 rounded-lg">
              <div className="flex justify-between text-sm font-medium">
                <span>Nuevo Saldo en Tarjeta</span>
                <span className="text-primary">
                  ${(cardBalance + (parseFloat(reloadAmount) || 0)).toFixed(2)}
                </span>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setReloadCardDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              const amount = parseFloat(reloadAmount);
              if (!isNaN(amount) && amount > 0) {
                if (amount <= balance) {
                  setCardBalance(cardBalance + amount);
                  setReloadCardDialogOpen(false);
                  toast({
                    title: "Recarga Exitosa",
                    description: `Has recargado $${amount.toFixed(2)} a tu tarjeta virtual.`,
                    variant: "default",
                  });
                } else {
                  toast({
                    title: "Fondos Insuficientes",
                    description: "No tienes suficiente saldo en tu billetera para esta recarga.",
                    variant: "destructive",
                  });
                }
              } else {
                toast({
                  title: "Monto Inválido",
                  description: "Por favor ingresa un monto válido mayor a cero.",
                  variant: "destructive",
                });
              }
            }}>
              Recargar Tarjeta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo para añadir una tarjeta adicional */}
      <Dialog open={addCardDialogOpen} onOpenChange={setAddCardDialogOpen}>
        <DialogContent className="bg-secondary text-foreground sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Añadir Nueva Tarjeta Virtual</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Crea una tarjeta virtual adicional para diferentes usos.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-3">
            <div className="bg-gradient-to-r from-green-600/80 to-green-500/60 rounded-xl p-4 text-white aspect-[1.6/1] flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs opacity-80 mb-1">D-OneCash Virtual Card</p>
                  <h3 className="text-lg font-bold">Visa Prepago</h3>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="20" height="14" x="2" y="5" rx="2"></rect>
                  <line x1="2" x2="22" y1="10" y2="10"></line>
                </svg>
              </div>
              
              <div className="mt-2">
                <p className="text-sm font-mono tracking-widest">**** **** **** ****</p>
              </div>
              
              <div className="flex justify-between items-center mt-2">
                <div>
                  <p className="text-xs opacity-80 mb-1">Saldo</p>
                  <p className="text-sm font-bold">$0.00</p>
                </div>
                <div>
                  <p className="text-xs opacity-80 mb-1">Expira</p>
                  <p className="text-sm font-medium">--/--</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Opciones de Tarjeta</h3>
              <div className="grid grid-cols-3 gap-2">
                <Button 
                  variant="outline" 
                  className="flex flex-col h-auto py-3 border-primary/30 hover:border-primary"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mb-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 11V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5M4 15v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5" />
                    <path d="M8 10V8" />
                    <path d="M12 10V8" />
                    <path d="M16 10V8" />
                    <rect width="16" height="12" x="4" y="6" rx="2" />
                  </svg>
                  <span className="text-xs">Compras</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="flex flex-col h-auto py-3 border-primary/30"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mb-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                  <span className="text-xs">Suscripciones</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="flex flex-col h-auto py-3 border-primary/30"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mb-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" />
                    <line x1="7" y1="7" x2="7.01" y2="7" />
                  </svg>
                  <span className="text-xs">Viajes</span>
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Configurar Límite</h3>
              <div className="flex gap-4">
                <div className="flex-1">
                  <Input 
                    type="text" 
                    inputMode="decimal"
                    placeholder="Límite de gasto mensual" 
                    className="w-full"
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Establece un límite de gasto mensual para esta tarjeta (opcional).
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddCardDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              toast({
                title: "Nueva Tarjeta Creada",
                description: "Tu tarjeta virtual adicional ha sido creada exitosamente.",
                variant: "default",
              });
              setAddCardDialogOpen(false);
            }}>
              Crear Tarjeta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Seguridad de la Tarjeta */}
      <Dialog open={cardSecurityDialogOpen} onOpenChange={setCardSecurityDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${isCardLocked ? 'text-red-600' : 'text-green-600'}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {isCardLocked ? (
                  <>
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                  </>
                ) : (
                  <>
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 5.8-4.9 5 5 0 0 1 4.2 4.9"></path>
                  </>
                )}
              </svg>
              Card Security
            </DialogTitle>
            <DialogDescription>
              {isCardLocked ? 'Your card is currently locked' : 'Manage your card security settings'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Current Status */}
            <div className={`p-4 rounded-lg border-2 ${isCardLocked ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isCardLocked ? 'bg-red-100' : 'bg-green-100'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${isCardLocked ? 'text-red-600' : 'text-green-600'}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    {isCardLocked ? (
                      <>
                        <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                      </>
                    ) : (
                      <>
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="m9 12 2 2 4-4"></path>
                      </>
                    )}
                  </svg>
                </div>
                <div>
                  <h3 className={`font-semibold ${isCardLocked ? 'text-red-700' : 'text-green-700'}`}>
                    {isCardLocked ? 'Card Locked' : 'Card Active'}
                  </h3>
                  <p className={`text-sm ${isCardLocked ? 'text-red-600' : 'text-green-600'}`}>
                    {isCardLocked 
                      ? 'All transactions are blocked' 
                      : 'Card is ready for transactions'
                    }
                  </p>
                </div>
              </div>
            </div>

            {/* Card Information */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Card Details</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex justify-between">
                  <span>Card Number:</span>
                  <span className="font-mono">{cardNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cardholder:</span>
                  <span>{cardHolder}</span>
                </div>
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className={`font-medium ${isCardLocked ? 'text-red-600' : 'text-green-600'}`}>
                    {isCardLocked ? 'LOCKED' : 'ACTIVE'}
                  </span>
                </div>
              </div>
            </div>

            {/* Security Information */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="m9 9 1.5 1.5L15 6"></path>
                </svg>
                <div className="text-sm text-blue-700">
                  <p className="font-medium mb-1">Security Information</p>
                  <p>
                    {isCardLocked 
                      ? 'When locked, your card cannot be used for any transactions including online purchases, ATM withdrawals, or in-store payments.'
                      : 'You can lock your card instantly if it\'s lost or stolen. Unlock it anytime when you find it or get a replacement.'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCardSecurityDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={() => {
                const newLockStatus = !isCardLocked;
                setIsCardLocked(newLockStatus);
                setCardSecurityDialogOpen(false);
                toast({
                  title: newLockStatus ? "Card Locked" : "Card Unlocked",
                  description: newLockStatus 
                    ? "Your card has been locked. All transactions are now blocked." 
                    : "Your card has been unlocked. You can now make transactions.",
                  variant: newLockStatus ? "destructive" : "default",
                });
              }}
              className={`${isCardLocked ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'} text-white`}
            >
              {isCardLocked ? (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 5.8-4.9 5 5 0 0 1 4.2 4.9"></path>
                  </svg>
                  Unlock Card
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                  </svg>
                  Lock Card
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
