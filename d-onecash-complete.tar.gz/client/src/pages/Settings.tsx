import { Helmet } from "react-helmet";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Camera, Check, Fingerprint, ShieldAlert, Palette, Sun, Moon } from "lucide-react";
import { useTheme } from "next-themes";

export default function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);
  const [transactionAlerts, setTransactionAlerts] = useState(true);
  const [securityAlerts, setSecurityAlerts] = useState(true);
  const [language, setLanguage] = useState("english");
  const [currency, setCurrency] = useState("usd");
  const [useFaceId, setUseFaceId] = useState(false);
  const [showFaceIdSetup, setShowFaceIdSetup] = useState(false);
  const [faceIdSetupStep, setFaceIdSetupStep] = useState(1);
  const [faceIdSetupComplete, setFaceIdSetupComplete] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const { toast } = useToast();

  // Check if Face ID was previously enabled
  useEffect(() => {
    const faceIdEnabled = localStorage.getItem("d1c_faceid_enabled");
    if (faceIdEnabled === "true") {
      setUseFaceId(true);
    }
  }, []);

  // Efecto para detectar el tema preferido o guardado
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
      setTheme("light");
      document.documentElement.classList.add("light");
    }
  }, []);

  // Función para cambiar el tema
  const toggleTheme = () => {
    if (theme === "dark") {
      setTheme("light");
      document.documentElement.classList.add("light");
      localStorage.setItem("theme", "light");
      toast({
        title: "Theme Updated",
        description: "Switched to light mode",
      });
    } else {
      setTheme("dark");
      document.documentElement.classList.remove("light");
      localStorage.setItem("theme", "dark");
      toast({
        title: "Theme Updated", 
        description: "Switched to dark mode",
      });
    }
  };

  // Efecto para simular el escaneo facial y completarlo automáticamente
  useEffect(() => {
    if (faceIdSetupStep === 2) {
      const timer = setTimeout(() => {
        handleFaceIdSetupComplete();
      }, 4000); // 4 segundos para el escaneo
      return () => clearTimeout(timer);
    }
  }, [faceIdSetupStep]);

  const handleFaceIdSetupComplete = () => {
    setFaceIdSetupComplete(true);
    setFaceIdSetupStep(3);
    // Guardar la configuración en localStorage
    localStorage.setItem("d1c_faceid_enabled", "true");
    
    setTimeout(() => {
      setShowFaceIdSetup(false);
      // Mostrar una notificación
      toast({
        title: "Face ID Configured",
        description: "You can now use Face ID to log in to your account",
        variant: "default",
      });
    }, 2000);
  };
  
  const handleFaceIdToggle = (checked: boolean) => {
    setUseFaceId(checked);
    if (checked) {
      // Si el usuario lo activa, mostrar el proceso de configuración
      setShowFaceIdSetup(true);
      setFaceIdSetupStep(1);
      setFaceIdSetupComplete(false);
    } else {
      // Si el usuario lo desactiva, eliminar la configuración
      localStorage.removeItem("d1c_faceid_enabled");
      toast({
        title: "Face ID Disabled",
        description: "Face ID login has been disabled",
        variant: "default",
      });
    }
  };

  const handleSavePreferences = () => {
    toast({
      title: "Preferences Saved",
      description: "Your settings have been updated successfully.",
      variant: "default",
    });
  };

  const handleResetSettings = () => {
    toast({
      title: "Settings Reset",
      description: "Your settings have been reset to default values.",
      variant: "default",
    });
  };

  return (
    <>
      <Helmet>
        <title>Settings | D-OneCash</title>
        <meta name="description" content="Configure your D-OneCash application settings, notifications, preferences, and account options." />
      </Helmet>
      
      {/* Modal para configurar Face ID */}
      <Dialog open={showFaceIdSetup} onOpenChange={setShowFaceIdSetup}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-center flex-col">
              {faceIdSetupStep === 1 && (
                <>
                  <Camera className="h-16 w-16 text-emerald-500 mb-3" />
                  <span>Configure Face ID</span>
                </>
              )}
              {faceIdSetupStep === 2 && (
                <>
                  <div className="flex flex-col items-center justify-center relative">
                    <div className="h-32 w-32 rounded-full border-4 border-emerald-500 flex items-center justify-center mb-3 relative overflow-hidden">
                      <div className="absolute top-0 left-0 h-full w-full bg-emerald-500/20 z-10"></div>
                      <div className="absolute top-0 left-0 h-full w-full flex items-center justify-center">
                        <div className="h-24 w-24 rounded-full bg-foreground/20 flex items-center justify-center">
                          <Fingerprint className="h-12 w-12 text-foreground" />
                        </div>
                      </div>
                      <div className="absolute top-0 left-0 h-0 w-full bg-emerald-500/30 z-20 animate-scan"></div>
                    </div>
                    <span>Scanning your face...</span>
                  </div>
                </>
              )}
              {faceIdSetupStep === 3 && (
                <>
                  <div className="h-16 w-16 rounded-full bg-emerald-500 flex items-center justify-center mb-3">
                    <Check className="h-10 w-10 text-white" />
                  </div>
                  <span>Face ID Configured!</span>
                </>
              )}
            </DialogTitle>
            <DialogDescription className="text-center pt-4">
              {faceIdSetupStep === 1 && "Position your face in front of the camera to set up Face ID"}
              {faceIdSetupStep === 2 && "Keep your face centered and still"}
              {faceIdSetupStep === 3 && "You can now use Face ID to log in to your account"}
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center items-center py-4">
            {faceIdSetupStep === 1 && (
              <Button 
                onClick={() => setFaceIdSetupStep(2)}
                className="mx-auto bg-emerald-600 hover:bg-emerald-700"
              >
                Start Scan
              </Button>
            )}
            {faceIdSetupStep === 2 && (
              <div className="h-10 flex items-center justify-center">
                <span className="text-sm text-muted-foreground">Scanning...</span>
              </div>
            )}
          </div>
          
          {faceIdSetupStep === 1 && (
            <DialogFooter className="sm:justify-start">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setShowFaceIdSetup(false);
                  setUseFaceId(false);
                }}
              >
                Cancel
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
      
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Settings</h1>
        
        <Tabs defaultValue="preferences" className="mb-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-1 p-1 bg-accent/30 rounded-xl h-auto">
            <TabsTrigger 
              value="preferences" 
              className="rounded-lg px-4 py-3 text-sm font-medium transition-all data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm"
            >
              <span className="hidden sm:inline">Preferences</span>
              <span className="sm:hidden">Prefs</span>
            </TabsTrigger>
            <TabsTrigger 
              value="appearance" 
              className="rounded-lg px-4 py-3 text-sm font-medium transition-all data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm"
            >
              <span className="hidden sm:inline">Appearance</span>
              <span className="sm:hidden">Look</span>
            </TabsTrigger>
            <TabsTrigger 
              value="notifications" 
              className="rounded-lg px-4 py-3 text-sm font-medium transition-all data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm"
            >
              <span className="hidden sm:inline">Notifications</span>
              <span className="sm:hidden">Alerts</span>
            </TabsTrigger>
            <TabsTrigger 
              value="security" 
              className="rounded-lg px-4 py-3 text-sm font-medium transition-all data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm"
            >
              <span className="hidden sm:inline">Security</span>
              <span className="sm:hidden">Safe</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>General Preferences</CardTitle>
                <CardDescription>Customize your application experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="language">Language</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger id="language">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent position="popper">
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="spanish">Spanish</SelectItem>
                        <SelectItem value="french">French</SelectItem>
                        <SelectItem value="german">German</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="currency">Display Currency</Label>
                    <Select value={currency} onValueChange={setCurrency}>
                      <SelectTrigger id="currency">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent position="popper">
                        <SelectItem value="usd">USD</SelectItem>
                        <SelectItem value="eur">EUR</SelectItem>
                        <SelectItem value="gbp">GBP</SelectItem>
                        <SelectItem value="d1c">D1C</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  

                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="advanced-mode">Advanced Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable advanced blockchain features
                      </p>
                    </div>
                    <Switch id="advanced-mode" />
                  </div>
                </div>
                
                <div className="flex justify-between pt-4">
                  <Button variant="outline" onClick={handleResetSettings}>
                    Reset to Default
                  </Button>
                  <Button onClick={handleSavePreferences}>Save Preferences</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Appearance Tab */}
          <TabsContent value="appearance" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Appearance Settings
                </CardTitle>
                <CardDescription>Customize the visual appearance of your application</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base font-medium">Theme Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        Choose between light and dark appearance
                      </p>
                    </div>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="rounded-full w-12 h-12" 
                      onClick={toggleTheme}
                      aria-label="Toggle theme"
                    >
                      {theme === "dark" ? (
                        <Sun className="h-6 w-6 text-amber-500" />
                      ) : (
                        <Moon className="h-6 w-6 text-blue-500" />
                      )}
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button
                      variant={theme === "light" ? "default" : "outline"}
                      size="lg"
                      onClick={() => {
                        if (theme === "dark") toggleTheme();
                      }}
                      className="flex items-center gap-3 h-auto p-4 justify-start"
                    >
                      <Sun className="h-6 w-6 text-amber-500" />
                      <div className="text-left">
                        <p className="font-medium">Light Mode</p>
                        <p className="text-sm opacity-70">Clean and bright interface</p>
                      </div>
                    </Button>
                    
                    <Button
                      variant={theme === "dark" ? "default" : "outline"}
                      size="lg"
                      onClick={() => {
                        if (theme === "light") toggleTheme();
                      }}
                      className="flex items-center gap-3 h-auto p-4 justify-start"
                    >
                      <Moon className="h-6 w-6 text-blue-500" />
                      <div className="text-left">
                        <p className="font-medium">Dark Mode</p>
                        <p className="text-sm opacity-70">Easy on the eyes</p>
                      </div>
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-accent/20 rounded-lg">
                    <div className="space-y-0.5">
                      <Label className="text-base font-medium">Current Theme</Label>
                      <p className="text-sm text-muted-foreground">
                        You are currently using {theme === "dark" ? "Dark" : "Light"} mode
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {theme === "dark" ? (
                        <Moon className="h-5 w-5 text-blue-500" />
                      ) : (
                        <Sun className="h-5 w-5 text-amber-500" />
                      )}
                      <span className="font-medium">{theme === "dark" ? "Dark" : "Light"}</span>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <p className="text-sm text-muted-foreground">
                      Your theme preference will be saved and applied across all your sessions. 
                      Click the buttons above to switch between light and dark modes instantly.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>Control how and when you receive notifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="all-notifications">All Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable or disable all notifications
                      </p>
                    </div>
                    <Switch 
                      id="all-notifications" 
                      checked={notifications} 
                      onCheckedChange={setNotifications} 
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="transaction-alerts">Transaction Alerts</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive alerts for new transactions
                      </p>
                    </div>
                    <Switch 
                      id="transaction-alerts" 
                      checked={transactionAlerts} 
                      onCheckedChange={setTransactionAlerts}
                      disabled={!notifications}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="security-alerts">Security Alerts</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive alerts for security-related events
                      </p>
                    </div>
                    <Switch 
                      id="security-alerts" 
                      checked={securityAlerts} 
                      onCheckedChange={setSecurityAlerts}
                      disabled={!notifications}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="marketing-emails">Marketing Emails</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive promotional emails and updates
                      </p>
                    </div>
                    <Switch 
                      id="marketing-emails" 
                      checked={marketingEmails} 
                      onCheckedChange={setMarketingEmails}
                      disabled={!notifications}
                    />
                  </div>
                </div>
                
                <div className="flex justify-end pt-4">
                  <Button onClick={handleSavePreferences}>Save Notification Settings</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Security Tab */}
          <TabsContent value="security" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>Manage your account security options</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="p-4 border border-accent rounded-lg">
                    <h3 className="font-medium mb-2">Biometric Authentication</h3>
                    <div className="flex items-center justify-between mb-3">
                      <div className="space-y-0.5">
                        <Label htmlFor="faceid-login">Face ID Login</Label>
                        <p className="text-sm text-muted-foreground">
                          Use Face ID to log in to your account quickly and securely
                        </p>
                      </div>
                      <Switch 
                        id="faceid-login" 
                        checked={useFaceId} 
                        onCheckedChange={handleFaceIdToggle}
                      />
                    </div>
                    {useFaceId && (
                      <div className="text-sm text-emerald-600 font-medium mb-3">
                        Face ID is enabled for this device
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground mb-3">
                      Face ID data is stored securely on your device and never transmitted.
                    </p>
                  </div>

                  <div className="p-4 border border-accent rounded-lg">
                    <h3 className="font-medium mb-2">Two-Factor Authentication</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Add an extra layer of security to your account by enabling two-factor authentication.
                    </p>
                    <Button>Enable 2FA</Button>
                  </div>
                  
                  <div className="p-4 border border-accent rounded-lg">
                    <h3 className="font-medium mb-2">Change Password</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Update your password regularly to keep your account secure.
                    </p>
                    <Button variant="outline">Change Password</Button>
                  </div>
                  
                  <div className="p-4 border border-accent rounded-lg">
                    <h3 className="font-medium mb-2">Session Management</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      View and manage your active sessions across different devices.
                    </p>
                    <Button variant="outline">View Active Sessions</Button>
                  </div>
                  
                  <div className="p-4 border border-destructive/30 rounded-lg">
                    <h3 className="font-medium text-destructive mb-2">Danger Zone</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      These actions are irreversible. Please proceed with caution.
                    </p>
                    <div className="flex flex-col space-y-2">
                      <Button variant="outline" className="border-destructive/50 text-destructive hover:bg-destructive/10">
                        Reset Recovery Keys
                      </Button>
                      <Button variant="outline" className="border-destructive/50 text-destructive hover:bg-destructive/10">
                        Delete Account
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
