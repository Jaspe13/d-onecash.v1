import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { useWallet } from "@/hooks/useWallet";
import CollateralModal from "@/components/CollateralModal";

// Precio simulado de BTC
const BTC_PRICE = 60842.35;
// Precio de USDC (1:1 con USD)
const USDC_PRICE = 1.0;
// Tasa de interés anual
const ANNUAL_INTEREST_RATE = 0.06;
// Porcentaje máximo de préstamo sobre el valor del colateral
const MAX_LOAN_PERCENTAGE = 0.5;

interface LoanData {
  id: number;
  amountUSDC: number;
  collateralBTC: number;
  startDate: Date;
  endDate: Date | null;
  status: "active" | "repaid";
  interestRate: number;
}

export default function Loans() {
  const { toast } = useToast();
  const { balance, refreshWallet } = useWallet();
  const [activeTab, setActiveTab] = useState("request");
  const [btcAmount, setBtcAmount] = useState("");
  const [maxLoanAmount, setMaxLoanAmount] = useState(0);
  const [loanAmount, setLoanAmount] = useState("");
  const [repayAmount, setRepayAmount] = useState("");
  const [activeLoan, setActiveLoan] = useState<LoanData | null>(null);
  const [loanHistory, setLoanHistory] = useState<LoanData[]>([]);
  
  // Estado para el modal de colateral
  const [showCollateralModal, setShowCollateralModal] = useState(false);
  const [pendingLoan, setPendingLoan] = useState<{
    btcAmount: number;
    usdcAmount: number;
  } | null>(null);
  const [showQRModal, setShowQRModal] = useState(false);
  const [btcPaymentStatus, setBtcPaymentStatus] = useState<'pending' | 'confirmed' | 'completed'>('pending');
  const [loanTerm, setLoanTerm] = useState("");
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [loanProcessing, setLoanProcessing] = useState(false);
  const [loanCompleted, setLoanCompleted] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [repaymentOpen, setRepaymentOpen] = useState(false);
  const [policyOpen, setPolicyOpen] = useState(false);

  // Saldo BTC del usuario (dato de ejemplo)
  const userBTCBalance = 2.5; // 2.5 BTC - suficiente para todos los rangos

  // Calcular el monto máximo de préstamo en función del colateral
  useEffect(() => {
    const btcValue = parseFloat(btcAmount) || 0;
    // Máximo 50% del valor del BTC
    const maxLoan = btcValue * BTC_PRICE * MAX_LOAN_PERCENTAGE;
    setMaxLoanAmount(maxLoan);
  }, [btcAmount]);

  // Calcular interés acumulado hasta el momento
  const calculateAccruedInterest = (loan: LoanData) => {
    const now = new Date();
    const loanStart = new Date(loan.startDate);
    // Diferencia en días
    const diffTime = Math.abs(now.getTime() - loanStart.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    // Interés diario (interés anual / 365)
    const dailyInterest = loan.interestRate / 365;
    // Interés acumulado
    return loan.amountUSDC * dailyInterest * diffDays;
  };

  // Calcular el total a pagar (préstamo + interés)
  const calculateTotalRepayment = () => {
    if (!activeLoan) return 0;
    const interest = calculateAccruedInterest(activeLoan);
    return activeLoan.amountUSDC + interest;
  };

  // Formatear números para mostrar
  const formatNumber = (num: number) => {
    if (num < 0.01) return num.toFixed(6);
    if (num < 1) return num.toFixed(4);
    if (num < 10) return num.toFixed(2);
    return num.toLocaleString('en-US', { maximumFractionDigits: 2 });
  };

  // Iniciar solicitud de préstamo
  const handleRequestLoan = () => {
    const btcValue = parseFloat(btcAmount);
    const usdcValue = parseFloat(loanAmount);
    
    if (!btcValue || !usdcValue || !loanTerm) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive"
      });
      return;
    }
    
    if (usdcValue > maxLoanAmount) {
      toast({
        title: "Error",
        description: "Loan amount exceeds maximum allowed",
        variant: "destructive"
      });
      return;
    }
    
    // Abrir modal de confirmación de términos
    setShowConfirmationModal(true);
  };

  // Confirmar préstamo después de aceptar términos
  const handleConfirmLoan = async () => {
    if (!termsAccepted) return;
    
    const btcValue = parseFloat(btcAmount);
    const usdcValue = parseFloat(loanAmount);
    
    // Iniciar procesamiento
    setLoanProcessing(true);
    
    // Simular procesamiento (2 segundos)
    setTimeout(() => {
      setLoanProcessing(false);
      setLoanCompleted(true);
      
      // Después de 3 segundos, cerrar modal y continuar con colateral
      setTimeout(() => {
        // Guardar los datos del préstamo pendiente
        setPendingLoan({
          btcAmount: btcValue,
          usdcAmount: usdcValue
        });
        
        // Cerrar modal de confirmación y abrir modal de colateral
        setShowConfirmationModal(false);
        setShowCollateralModal(true);
        setTermsAccepted(false);
        setLoanCompleted(false);
      }, 3000);
    }, 2000);
  };
  
  // Finalizar la solicitud de préstamo después de enviar el colateral
  const handleCollateralConfirmed = async () => {
    if (!pendingLoan) return;
    
    try {
      // Añadir los fondos del préstamo al wallet
      const response = await fetch(`/api/wallet/1`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          balance: balance + pendingLoan.usdcAmount
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update wallet balance');
      }

      // Crear una transacción de préstamo en el historial
      const transactionResponse = await fetch('/api/transactions/loan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: 1,
          type: 'receive',
          amount: pendingLoan.usdcAmount,
          fee: 0,
          sender: 'D-OneCash Loan',
          note: `Loan of $${pendingLoan.usdcAmount} with ${pendingLoan.btcAmount} BTC as collateral`,
          status: 'completed'
        })
      });

      // Crear el nuevo préstamo
      const newLoan: LoanData = {
        id: Date.now(),
        amountUSDC: pendingLoan.usdcAmount,
        collateralBTC: pendingLoan.btcAmount,
        startDate: new Date(),
        endDate: null,
        status: "active",
        interestRate: ANNUAL_INTEREST_RATE
      };
      
      // Actualizar el estado
      setActiveLoan(newLoan);
      setLoanHistory([...loanHistory, newLoan]);
      
      // Refrescar el wallet para mostrar el nuevo balance
      refreshWallet();
      
      // Cerrar el modal de colateral
      setShowCollateralModal(false);
      setPendingLoan(null);
      
      // Limpiar formulario
      setBtcAmount("");
      setLoanAmount("");
      
      // Cambiar a la pestaña de préstamos activos
      setActiveTab("active");
      
      toast({
        title: "Success",
        description: `Loan approved! $${pendingLoan.usdcAmount.toFixed(2)} has been added to your wallet`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process loan. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Pagar préstamo
  const handleRepayLoan = () => {
    if (!activeLoan) return;
    
    const repayValue = parseFloat(repayAmount);
    const totalDue = calculateTotalRepayment();
    
    if (!repayValue) {
      toast({
        title: "Error",
        description: "Please enter a valid amount",
        variant: "destructive"
      });
      return;
    }
    
    if (repayValue < totalDue) {
      toast({
        title: "Error",
        description: "Amount is less than the total amount due",
        variant: "destructive"
      });
      return;
    }
    
    // Actualizar el préstamo
    const updatedLoan: LoanData = {
      ...activeLoan,
      endDate: new Date(),
      status: "repaid"
    };
    
    // Actualizar el historial
    const updatedHistory = loanHistory.map(loan => 
      loan.id === activeLoan.id ? updatedLoan : loan
    );
    
    setLoanHistory(updatedHistory);
    setActiveLoan(null);
    setRepayAmount("");
    
    toast({
      title: "Success",
      description: "Loan repaid successfully. Your collateral has been returned.",
    });
  };

  return (
    <>
      <Helmet>
        <title>Loans | D-OneCash</title>
        <meta name="description" content="Request USDC loans using BTC as collateral" />
      </Helmet>
      
      {/* Modal de colateral */}
      {pendingLoan && (
        <CollateralModal
          isOpen={showCollateralModal}
          onClose={() => setShowCollateralModal(false)}
          onConfirm={handleCollateralConfirmed}
          btcAmount={pendingLoan.btcAmount}
        />
      )}

      {/* Modal de confirmación de términos */}
      <Dialog open={showConfirmationModal} onOpenChange={setShowConfirmationModal}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-green-800">Loan Request Confirmation</DialogTitle>
            <DialogDescription>
              Please review and confirm your loan details before proceeding
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Loan Summary */}
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <h4 className="font-semibold text-green-800 mb-3">Loan Details</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Loan Amount:</span>
                  <p className="font-bold text-lg">${formatNumber(parseFloat(loanAmount))}</p>
                </div>
                <div>
                  <span className="text-gray-600">BTC Collateral:</span>
                  <p className="font-bold text-lg">{formatNumber(parseFloat(btcAmount))} BTC</p>
                </div>
                <div>
                  <span className="text-gray-600">Loan Term:</span>
                  <p className="font-medium">{loanTerm} year{loanTerm !== "1" ? "s" : ""}</p>
                </div>
                <div>
                  <span className="text-gray-600">Interest Rate:</span>
                  <p className="font-medium">{ANNUAL_INTEREST_RATE * 100}% annual</p>
                </div>
                <div>
                  <span className="text-gray-600">Total to Repay:</span>
                  <p className="font-bold text-red-600">${formatNumber(parseFloat(loanAmount) + (parseFloat(loanAmount) * ANNUAL_INTEREST_RATE * parseInt(loanTerm)))}</p>
                </div>
                <div>
                  <span className="text-gray-600">Total Interest:</span>
                  <p className="font-medium text-orange-600">${formatNumber(parseFloat(loanAmount) * ANNUAL_INTEREST_RATE * parseInt(loanTerm))}</p>
                </div>
              </div>
            </div>

            {/* Terms and Conditions Collapsible */}
            <Collapsible open={termsOpen} onOpenChange={setTermsOpen}>
              <CollapsibleTrigger asChild>
                <Button variant="outline" className="w-full justify-between p-4">
                  <span className="font-semibold">Terms and Conditions</span>
                  <svg
                    className={`h-4 w-4 transition-transform ${termsOpen ? 'rotate-180' : ''}`}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-2">
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg mt-2">
                  <div className="text-sm text-yellow-700 space-y-2">
                    <p>• Your {formatNumber(parseFloat(btcAmount))} BTC will be locked as collateral during the loan period</p>
                    <p>• You have {loanTerm} year{loanTerm !== "1" ? "s" : ""} to repay the full amount of ${formatNumber(parseFloat(loanAmount) + (parseFloat(loanAmount) * ANNUAL_INTEREST_RATE * parseInt(loanTerm)))}</p>
                    <p>• If not repaid within the deadline, D-OneCash will liquidate only the necessary portion of your BTC to cover the debt plus a 1% late payment fee</p>
                    <p>• Any remaining BTC after liquidation will be returned to you</p>
                    <p>• You can repay the loan at any time before the deadline</p>
                    <p>• No partial payments or extensions are permitted</p>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* Acceptance Checkbox */}
            <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
              <Checkbox
                id="terms"
                checked={termsAccepted}
                onCheckedChange={(checked) => {
                  if (typeof checked === 'boolean') {
                    setTermsAccepted(checked);
                  }
                }}
                className="mt-1"
              />
              <label htmlFor="terms" className="text-sm text-gray-700 cursor-pointer">
                I acknowledge that I have read, understood, and agree to all the terms and conditions stated above. 
                I understand the risks involved and accept full responsibility for this loan agreement with D-OneCash.
              </label>
            </div>

            {/* Processing/Success State */}
            {loanProcessing && (
              <div className="text-center p-6 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-lg font-semibold text-blue-700">Processing Loan Request...</span>
                </div>
                <p className="text-sm text-blue-600">Please wait while we validate your information</p>
              </div>
            )}

            {loanCompleted && (
              <div className="text-center p-6 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                    <svg className="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
                    </svg>
                  </div>
                  <span className="text-xl font-bold text-green-700">Loan Approved!</span>
                </div>
                <p className="text-sm text-green-600 mb-2">Your loan request has been successfully processed</p>
                <p className="text-xs text-gray-500">Proceeding to collateral submission...</p>
              </div>
            )}

            {/* Action Buttons */}
            {!loanProcessing && !loanCompleted && (
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowConfirmationModal(false);
                    setTermsAccepted(false);
                  }}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleConfirmLoan}
                  disabled={!termsAccepted}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  Accept & Continue
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal QR para pago BTC */}
      <Dialog open={showQRModal} onOpenChange={setShowQRModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Send BTC Collateral</DialogTitle>
            <DialogDescription>
              Scan the QR code to send {btcAmount} BTC as collateral
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 px-2 sm:px-0">
            {/* QR Code */}
            <div className="flex items-center justify-center p-3 sm:p-6 bg-white rounded-lg border">
              <div className="text-center w-full max-w-xs mx-auto">
                <div className="w-full aspect-square max-w-[200px] sm:max-w-[240px] bg-black mx-auto mb-4 rounded flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-[90%] h-[90%]">
                    <rect width="100" height="100" fill="white"/>
                    <g fill="black">
                      {/* QR Code pattern simulation - más detallado */}
                      <rect x="0" y="0" width="7" height="7"/>
                      <rect x="2" y="2" width="3" height="3" fill="white"/>
                      <rect x="93" y="0" width="7" height="7"/>
                      <rect x="95" y="2" width="3" height="3" fill="white"/>
                      <rect x="0" y="93" width="7" height="7"/>
                      <rect x="2" y="95" width="3" height="3" fill="white"/>
                      
                      {/* Patrón más detallado */}
                      <rect x="10" y="10" width="2" height="2"/>
                      <rect x="13" y="10" width="2" height="2"/>
                      <rect x="16" y="10" width="2" height="2"/>
                      <rect x="19" y="10" width="2" height="2"/>
                      <rect x="22" y="10" width="2" height="2"/>
                      <rect x="25" y="10" width="2" height="2"/>
                      <rect x="28" y="10" width="2" height="2"/>
                      
                      <rect x="10" y="13" width="2" height="2"/>
                      <rect x="16" y="13" width="2" height="2"/>
                      <rect x="22" y="13" width="2" height="2"/>
                      <rect x="28" y="13" width="2" height="2"/>
                      
                      <rect x="10" y="16" width="2" height="2"/>
                      <rect x="13" y="16" width="2" height="2"/>
                      <rect x="19" y="16" width="2" height="2"/>
                      <rect x="25" y="16" width="2" height="2"/>
                      <rect x="28" y="16" width="2" height="2"/>
                      
                      <rect x="70" y="10" width="2" height="2"/>
                      <rect x="73" y="10" width="2" height="2"/>
                      <rect x="76" y="10" width="2" height="2"/>
                      <rect x="79" y="10" width="2" height="2"/>
                      <rect x="82" y="10" width="2" height="2"/>
                      <rect x="85" y="10" width="2" height="2"/>
                      <rect x="88" y="10" width="2" height="2"/>
                      
                      <rect x="10" y="70" width="2" height="2"/>
                      <rect x="13" y="73" width="2" height="2"/>
                      <rect x="16" y="76" width="2" height="2"/>
                      <rect x="19" y="79" width="2" height="2"/>
                      <rect x="22" y="82" width="2" height="2"/>
                      <rect x="25" y="85" width="2" height="2"/>
                      <rect x="28" y="88" width="2" height="2"/>
                    </g>
                  </svg>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">
                    Amount: {btcAmount} BTC
                  </p>
                  <p className="text-xs text-muted-foreground break-all px-2">
                    bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh
                  </p>
                </div>
              </div>
            </div>

            {/* Status */}
            <div className="text-center p-4 bg-blue-50 rounded-lg border">
              {btcPaymentStatus === 'pending' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-sm font-medium text-blue-700">Waiting for payment...</span>
                  </div>
                  <p className="text-xs text-blue-600">
                    Send exactly {btcAmount} BTC to complete the transaction
                  </p>
                </div>
              )}

              {btcPaymentStatus === 'confirmed' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <span className="text-sm font-medium text-green-700">Payment Confirmed!</span>
                  </div>
                  <p className="text-xs text-green-600">
                    {btcAmount} BTC received successfully
                  </p>
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowQRModal(false);
                  setBtcPaymentStatus('pending');
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              
              {btcPaymentStatus === 'pending' && (
                <Button
                  onClick={() => {
                    setBtcPaymentStatus('confirmed');
                    setTimeout(() => {
                      setShowQRModal(false);
                      setBtcPaymentStatus('pending');
                      toast({
                        title: "BTC Collateral Received",
                        description: `${btcAmount} BTC has been deposited as collateral`,
                        variant: "default",
                      });
                    }, 2000);
                  }}
                  className="flex-1 bg-orange-500 hover:bg-orange-600"
                >
                  Simulate Payment
                </Button>
              )}

              {btcPaymentStatus === 'confirmed' && (
                <Button
                  onClick={() => {
                    setShowQRModal(false);
                    setBtcPaymentStatus('pending');
                  }}
                  className="flex-1 bg-green-500 hover:bg-green-600"
                >
                  Continue
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      <div className="container mx-auto px-4 pb-24 max-w-4xl min-h-screen">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold">Loans</h1>
            <p className="text-muted-foreground">Request USDC loans using BTC as collateral</p>
          </div>
          
          <Tabs defaultValue="request" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="request">Request Loan</TabsTrigger>
              <TabsTrigger value="active">Active Loans</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
            
            {/* Request Loan */}
            <TabsContent value="request" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Request Loan</CardTitle>
                  <CardDescription>
                    Available BTC balance: {formatNumber(userBTCBalance)} BTC (${formatNumber(userBTCBalance * BTC_PRICE)})
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4 sm:p-6">
                  <form className="space-y-4 sm:space-y-6">
                    <div className="space-y-3">
                      <label className="text-sm font-medium">
                        BTC como colateral (Máximo: 1 BTC)
                      </label>
                      
                      {/* Botones de selección rápida */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[0.5, 1].map((amount) => (
                          <Button
                            key={amount}
                            type="button"
                            variant={btcAmount === amount.toString() ? "default" : "outline"}
                            size="sm"
                            onClick={() => setBtcAmount(amount.toString())}
                            className={btcAmount === amount.toString() ? "bg-primary text-white" : ""}
                          >
                            {amount} BTC
                          </Button>
                        ))}
                      </div>
                      
                      {/* Campo de entrada manual */}
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={btcAmount}
                        max="1"
                        min="0.1"
                        step="0.1"
                        onChange={(e) => {
                          const value = parseFloat(e.target.value);
                          if (value <= 1 || e.target.value === "") {
                            setBtcAmount(e.target.value);
                          }
                        }}
                      />
                      
                      {btcAmount && parseFloat(btcAmount) > 1 && (
                        <p className="text-xs text-red-500">
                          ⚠️ Máximo permitido: 1 BTC
                        </p>
                      )}
                      
                      {btcAmount && parseFloat(btcAmount) <= 1 && parseFloat(btcAmount) > 0 && (
                        <p className="text-xs text-muted-foreground">
                          Valor: ${formatNumber(parseFloat(btcAmount) * BTC_PRICE)}
                        </p>
                      )}
                    </div>


                    
                    {btcAmount && parseFloat(btcAmount) > 0 && (
                      <Alert className="bg-primary/10 border-primary/20">
                        <AlertDescription>
                          Préstamo máximo: ${formatNumber(maxLoanAmount)} USDC ({(MAX_LOAN_PERCENTAGE * 100)}% del valor del colateral)
                        </AlertDescription>
                      </Alert>
                    )}
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Cantidad de préstamo (USD)
                      </label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={loanAmount}
                        onChange={(e) => setLoanAmount(e.target.value)}
                        disabled={!btcAmount || parseFloat(btcAmount) <= 0}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Loan Term (Maximum: 5 years)
                      </label>
                      <Select value={loanTerm} onValueChange={setLoanTerm}>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select loan duration" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 Year</SelectItem>
                          <SelectItem value="2">2 Years</SelectItem>
                          <SelectItem value="3">3 Years</SelectItem>
                          <SelectItem value="4">4 Years</SelectItem>
                          <SelectItem value="5">5 Years</SelectItem>
                        </SelectContent>
                      </Select>
                      {loanTerm && (
                        <p className="text-xs text-muted-foreground">
                          Selected duration: {loanTerm} year{loanTerm !== "1" ? "s" : ""}
                        </p>
                      )}
                    </div>
                    
                    {loanAmount && parseFloat(loanAmount) > 0 && loanTerm && (
                      <div className="space-y-4 p-6 bg-gradient-to-br from-green-50 via-white to-green-50 rounded-xl border-2 border-green-100 shadow-lg">
                        {/* Header */}
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                            <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                              <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z"/>
                              <path fillRule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clipRule="evenodd"/>
                            </svg>
                          </div>
                          <div>
                            <h4 className="text-lg font-bold text-green-800">Loan Summary</h4>
                            <p className="text-sm text-green-600">Your personalized loan details</p>
                          </div>
                        </div>

                        {/* Main Amount Display */}
                        <div className="text-center p-4 bg-white rounded-lg border border-green-200">
                          <p className="text-sm text-gray-500 mb-1">You will receive</p>
                          <p className="text-3xl font-bold text-green-600">${formatNumber(parseFloat(loanAmount))}</p>
                          <p className="text-sm text-gray-500 mt-1">Available immediately</p>
                        </div>

                        {/* Details Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {/* Loan Terms */}
                          <div className="bg-white p-4 rounded-lg border border-gray-200">
                            <div className="flex items-center gap-2 mb-3">
                              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                              <span className="text-sm font-medium text-gray-700">Loan Terms</span>
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Duration</span>
                                <span className="font-medium">{loanTerm} year{loanTerm !== "1" ? "s" : ""}</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">Interest rate</span>
                                <span className="font-medium text-blue-600">{ANNUAL_INTEREST_RATE * 100}% annual</span>
                              </div>
                            </div>
                          </div>

                          {/* Collateral */}
                          <div className="bg-white p-4 rounded-lg border border-gray-200">
                            <div className="flex items-center gap-2 mb-3">
                              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                              <span className="text-sm font-medium text-gray-700">Collateral</span>
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">BTC locked</span>
                                <span className="font-medium">{formatNumber(parseFloat(btcAmount))} BTC</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-gray-600">USD value</span>
                                <span className="font-medium text-orange-600">${formatNumber(parseFloat(btcAmount) * BTC_PRICE)}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Repayment Details Collapsible */}
                        <Collapsible open={repaymentOpen} onOpenChange={setRepaymentOpen}>
                          <CollapsibleTrigger asChild>
                            <Button variant="outline" className="w-full justify-between p-4">
                              <span className="font-semibold flex items-center gap-2">
                                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd"/>
                                </svg>
                                Repayment Terms
                              </span>
                              <svg
                                className={`h-4 w-4 transition-transform ${repaymentOpen ? 'rotate-180' : ''}`}
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                              </svg>
                            </Button>
                          </CollapsibleTrigger>
                          <CollapsibleContent className="space-y-2">
                            <div className="bg-gradient-to-r from-red-50 to-orange-50 p-4 rounded-lg border border-red-200 mt-2">
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div className="text-center">
                                  <p className="text-xs text-gray-600 mb-1">Total Interest</p>
                                  <p className="text-lg font-bold text-orange-600">
                                    ${formatNumber(parseFloat(loanAmount) * ANNUAL_INTEREST_RATE * parseInt(loanTerm))}
                                  </p>
                                </div>
                                
                                <div className="text-center">
                                  <p className="text-xs text-gray-600 mb-1">Total to Repay</p>
                                  <p className="text-xl font-bold text-red-600">
                                    ${formatNumber(parseFloat(loanAmount) + (parseFloat(loanAmount) * ANNUAL_INTEREST_RATE * parseInt(loanTerm)))}
                                  </p>
                                </div>
                              </div>

                              <div className="mt-4 p-3 bg-white rounded-lg border-l-4 border-red-500">
                                <div className="flex items-center gap-2 mb-2">
                                  <svg className="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"/>
                                  </svg>
                                  <span className="text-sm font-medium text-red-700">Repayment Deadline</span>
                                </div>
                                <p className="text-sm text-gray-700">
                                  You have <span className="font-bold text-red-600">{loanTerm} year{loanTerm !== "1" ? "s" : ""}</span> to repay the full amount. 
                                  Payment can be made at any time within this period.
                                </p>
                              </div>
                            </div>
                          </CollapsibleContent>
                        </Collapsible>

                        {/* Late Payment Policy Collapsible */}
                        <Collapsible open={policyOpen} onOpenChange={setPolicyOpen}>
                          <CollapsibleTrigger asChild>
                            <Button variant="outline" className="w-full justify-between p-4">
                              <span className="font-semibold flex items-center gap-2">
                                <svg className="w-4 h-4 text-orange-600" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd"/>
                                </svg>
                                ⚠️ LATE PAYMENT POLICY
                              </span>
                              <svg
                                className={`h-4 w-4 transition-transform ${policyOpen ? 'rotate-180' : ''}`}
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                              </svg>
                            </Button>
                          </CollapsibleTrigger>
                          <CollapsibleContent className="space-y-2">
                            <div className="flex items-start gap-3 p-4 bg-orange-50 border-2 border-orange-200 rounded-lg mt-2">
                              <svg className="w-6 h-6 text-orange-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd"/>
                              </svg>
                              <div className="text-sm text-orange-700">
                                <div className="space-y-2">
                                  <p>• Your <span className="font-semibold">{formatNumber(parseFloat(btcAmount))} BTC</span> will remain locked as collateral</p>
                                  <p>• If not repaid within <span className="font-semibold">{loanTerm} year{loanTerm !== "1" ? "s" : ""}</span>, D-OneCash will liquidate only the necessary portion of your BTC to cover:</p>
                                  <div className="ml-4 space-y-1">
                                    <p>→ Outstanding debt: <span className="font-semibold">${formatNumber(parseFloat(loanAmount) + (parseFloat(loanAmount) * ANNUAL_INTEREST_RATE * parseInt(loanTerm)))}</span></p>
                                    <p>→ Late payment fee: <span className="font-semibold">1%</span> of total debt</p>
                                  </div>
                                  <p>• Any remaining BTC will be returned to you</p>
                                  <p>• You can repay at any time before the deadline to avoid fees</p>
                                </div>
                              </div>
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      </div>
                    )}
                    
                    {loanAmount && parseFloat(loanAmount) > 0 && btcAmount && parseFloat(btcAmount) > 0 && (
                      <div className="space-y-2">
                        <Separator />
                        <div className="flex items-center gap-2">
                          <div className="text-sm">Préstamo/Valor</div>
                          <div className="flex-1">
                            <Progress 
                              value={(parseFloat(loanAmount) / (parseFloat(btcAmount) * BTC_PRICE)) * 100} 
                              max={MAX_LOAN_PERCENTAGE * 100}
                              className="h-2"
                            />
                          </div>
                          <div className="text-sm font-medium">
                            {formatNumber((parseFloat(loanAmount) / (parseFloat(btcAmount) * BTC_PRICE)) * 100)}%
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="pt-4">
                      <Button 
                        className="w-full h-12 text-base font-semibold" 
                        type="button" 
                        onClick={handleRequestLoan}
                        disabled={
                          !btcAmount || 
                          parseFloat(btcAmount) <= 0 || 
                          parseFloat(btcAmount) > userBTCBalance || 
                          !loanAmount || 
                          parseFloat(loanAmount) <= 0 || 
                          parseFloat(loanAmount) > maxLoanAmount ||
                          !loanTerm ||
                          !repaymentOpen ||
                          !policyOpen
                        }
                      >
                        Request loan
                      </Button>
                      
                      {/* Warning message if dropdowns haven't been opened */}
                      {loanAmount && parseFloat(loanAmount) > 0 && loanTerm && (!repaymentOpen || !policyOpen) && (
                        <p className="text-xs text-orange-600 mt-2 text-center">
                          ⚠️ Please review the Repayment Terms and Late Payment Policy before proceeding
                        </p>
                      )}
                    </div>
                  </form>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>How do loans work?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-medium">Collateral</h3>
                    <p className="text-sm text-muted-foreground">
                      We use your Bitcoin (BTC) as collateral for your loan. Your BTC will remain secure on our platform until you repay the loan.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-medium">Loan terms</h3>
                    <p className="text-sm text-muted-foreground">
                      We offer loans up to 50% of your BTC value. The annual interest rate is 6%, with monthly interest payments.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-medium">Repayment</h3>
                    <p className="text-sm text-muted-foreground">
                      You can repay your loan at any time. Once the principal and interest are paid, your BTC will be automatically released.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Active Loans */}
            <TabsContent value="active" className="space-y-6">
              {activeLoan ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Active loan</CardTitle>
                    <CardDescription>
                      Start date: {new Date(activeLoan.startDate).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Loan amount</p>
                        <p className="text-lg font-medium">{formatNumber(activeLoan.amountUSDC)} USD</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Collateral</p>
                        <p className="text-lg font-medium">{formatNumber(activeLoan.collateralBTC)} BTC</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Accrued interest</p>
                        <p className="text-lg font-medium">{formatNumber(calculateAccruedInterest(activeLoan))} USD</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Total to pay</p>
                        <p className="text-lg font-medium">{formatNumber(calculateTotalRepayment())} USD</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <form className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Amount to pay (USD)
                        </label>
                        <Input
                          type="number"
                          placeholder={formatNumber(calculateTotalRepayment())}
                          value={repayAmount}
                          onChange={(e) => setRepayAmount(e.target.value)}
                        />
                      </div>

                      {/* Early Payment Fee Notice */}
                      <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="flex items-start gap-2">
                          <svg className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd"/>
                          </svg>
                          <div className="text-sm text-yellow-700">
                            <p className="font-medium mb-1">💡 Early Payment Policy</p>
                            <p>Paying your loan before the due date will incur a <span className="font-semibold">1% early cancellation fee</span> on the total amount to be repaid.</p>
                          </div>
                        </div>
                      </div>
                      
                      <Button 
                        className="w-full" 
                        type="button" 
                        onClick={handleRepayLoan}
                        disabled={
                          !repayAmount || 
                          parseFloat(repayAmount) < calculateTotalRepayment()
                        }
                      >
                        Pay Loan
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>No tienes préstamos activos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center py-6 text-center">
                      <p className="text-muted-foreground mb-4">
                        Actualmente no tienes ningún préstamo activo. Solicita un préstamo usando tu BTC como colateral para obtener USDC al instante.
                      </p>
                      <Button onClick={() => setActiveTab("request")}>
                        Solicitar un nuevo préstamo
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            {/* Historial de Préstamos */}
            <TabsContent value="history" className="space-y-6">
              {loanHistory.length > 0 ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Historial de préstamos</CardTitle>
                    <CardDescription>
                      Total de préstamos: {loanHistory.length}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {loanHistory.map((loan) => (
                        <div key={loan.id} className="p-4 border rounded-lg bg-card">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-medium">{formatNumber(loan.amountUSDC)} USDC</h3>
                              <p className="text-xs text-muted-foreground">
                                Solicitado el: {new Date(loan.startDate).toLocaleDateString()}
                              </p>
                            </div>
                            <div>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                loan.status === "active" ? "bg-primary/20 text-primary" : "bg-green-500/20 text-green-500"
                              }`}>
                                {loan.status === "active" ? "Activo" : "Pagado"}
                              </span>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <p className="text-muted-foreground">Colateral</p>
                              <p>{formatNumber(loan.collateralBTC)} BTC</p>
                            </div>
                            {loan.status === "repaid" && loan.endDate && (
                              <div>
                                <p className="text-muted-foreground">Pagado el</p>
                                <p>{new Date(loan.endDate).toLocaleDateString()}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>No hay historial de préstamos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center py-6 text-center">
                      <p className="text-muted-foreground mb-4">
                        Aún no has solicitado ningún préstamo. Los préstamos que solicites y pagues aparecerán aquí para que puedas realizar un seguimiento de tu historial.
                      </p>
                      <Button onClick={() => setActiveTab("request")}>
                        Solicitar mi primer préstamo
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}