import { Helmet } from "react-helmet";
import WalletDashboard from "@/components/WalletDashboard";
import QuickActions from "@/components/QuickActions";
import TransactionHistory from "@/components/TransactionHistory";
import Notifications from "@/components/Notifications";

export default function Dashboard() {
  return (
    <>
      <Helmet>
        <title>Dashboard | D-OneCash</title>
        <meta name="description" content="View your wallet balance, send money, and manage transactions with D-OneCash - your digital finance solution." />
      </Helmet>
      
      <WalletDashboard />
      <QuickActions />
      <TransactionHistory />
      <Notifications />
    </>
  );
}
