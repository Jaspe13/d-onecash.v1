import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { sendMoneySchema, generateQrSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // For MVP, we'll just return the user
      // In production, we'd generate a JWT token here
      return res.json({ user });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/register", async (req, res) => {
    try {
      const { username, password, email, phoneNumber, fullName } = req.body;
      
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(409).json({ message: "Email already exists" });
      }
      
      // Generate a mock wallet address
      const walletAddress = `d1c:${Math.random().toString(36).substring(2, 15)}`;
      
      const newUser = await storage.createUser({
        username,
        password,
        email,
        phoneNumber,
        fullName,
        walletAddress,
      });
      
      // Create a wallet for the user
      await storage.createWallet({
        userId: newUser.id,
        balance: 1000, // Starting balance for demo
        currency: "USDC"
      });
      
      return res.status(201).json({ user: newUser });
    } catch (error) {
      console.error("Registration error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Wallet routes
  app.get("/api/wallet/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const wallet = await storage.getWalletByUserId(userId);
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }
      
      return res.json(wallet);
    } catch (error) {
      console.error("Get wallet error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/wallet/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const { balance } = req.body;
      if (typeof balance !== 'number' || balance < 0) {
        return res.status(400).json({ message: "Invalid balance amount" });
      }

      const wallet = await storage.getWalletByUserId(userId);
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }

      const updatedWallet = await storage.updateWallet(wallet.id, { balance });
      return res.json(updatedWallet);
    } catch (error) {
      console.error("Update wallet error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/wallet/add-funds", async (req, res) => {
    try {
      const { userId, amount, method } = req.body;
      
      if (!userId || !amount || !method) {
        return res.status(400).json({ message: "User ID, amount, and payment method are required" });
      }
      
      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({ message: "Amount must be a positive number" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const wallet = await storage.getWalletByUserId(userId);
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }
      
      // Update wallet with new balance
      const updatedWallet = await storage.updateWallet(wallet.id, {
        balance: wallet.balance + amount
      });
      
      // Create transaction record for the deposit
      const transaction = await storage.createTransaction({
        userId,
        type: "deposit",
        amount,
        fee: 0,
        sender: method === "card" ? "Credit/Debit Card" : 
                method === "bank" ? "Bank Transfer" : 
                "Cryptocurrency",
        status: "completed"
      });
      
      return res.status(200).json({ 
        wallet: updatedWallet,
        transaction 
      });
    } catch (error) {
      console.error("Add funds error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Transaction routes
  app.get("/api/transactions/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const transactions = await storage.getTransactionsByUserId(userId);
      return res.json(transactions);
    } catch (error) {
      console.error("Get transactions error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/transactions/loan", async (req, res) => {
    try {
      const { userId, type, amount, fee, sender, note, status } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Create loan transaction
      const transaction = await storage.createTransaction({
        userId,
        type,
        amount,
        fee,
        sender,
        note,
        status
      });
      
      return res.status(201).json(transaction);
    } catch (error) {
      console.error("Create loan transaction error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/transactions/send", async (req, res) => {
    try {
      const validatedData = sendMoneySchema.parse(req.body);
      const { userId, recipient, amount, note } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const wallet = await storage.getWalletByUserId(userId);
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }
      
      // Calculate fee (for demo purposes)
      const fee = amount * 0.01;
      const totalAmount = amount + fee;
      
      if (wallet.balance < totalAmount) {
        return res.status(400).json({ message: "Insufficient funds" });
      }
      
      // Update sender's wallet
      await storage.updateWallet(wallet.id, {
        balance: wallet.balance - totalAmount
      });
      
      // Create transaction
      const transaction = await storage.createTransaction({
        userId,
        type: "send",
        amount,
        fee,
        recipient,
        note,
        status: "completed"
      });
      
      // For demo purposes, let's also add a receive transaction for the recipient
      // In production, this would be handled differently
      const recipientUser = await storage.getUserByEmail(recipient) || await storage.getUserByUsername(recipient);
      
      if (recipientUser) {
        const recipientWallet = await storage.getWalletByUserId(recipientUser.id);
        
        if (recipientWallet) {
          // Update recipient's wallet
          await storage.updateWallet(recipientWallet.id, {
            balance: recipientWallet.balance + amount
          });
          
          // Create receive transaction for recipient
          await storage.createTransaction({
            userId: recipientUser.id,
            type: "receive",
            amount,
            fee: 0,
            sender: user.username,
            note,
            status: "completed"
          });
        }
      }
      
      return res.status(201).json({ transaction });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Send money error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // QR Code routes
  app.post("/api/qrcode/generate", async (req, res) => {
    try {
      const validatedData = generateQrSchema.parse(req.body);
      const { userId, amount, description } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Set expiration to 24 hours from now
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 24);
      
      const qrCode = await storage.createQrCode({
        userId,
        amount,
        description,
        expiresAt,
        active: true
      });
      
      return res.status(201).json({
        qrCode,
        walletAddress: user.walletAddress
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Generate QR code error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Contact routes
  app.get("/api/contacts/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const contacts = await storage.getContactsByUserId(userId);
      return res.json(contacts);
    } catch (error) {
      console.error("Get contacts error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/contacts", async (req, res) => {
    try {
      const { userId, name, email, phoneNumber, isFavorite, profilePic } = req.body;
      
      if (!userId || !name) {
        return res.status(400).json({ message: "User ID and name are required" });
      }
      
      // Validar que exista al menos un método de contacto
      if (!email && !phoneNumber) {
        return res.status(400).json({ message: "Email or phone number is required" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const newContact = await storage.createContact({
        userId,
        name,
        email,
        phoneNumber,
        isFavorite: isFavorite || false,
        profilePic
      });
      
      return res.status(201).json(newContact);
    } catch (error) {
      console.error("Create contact error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.put("/api/contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      if (isNaN(contactId)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }
      
      const contact = await storage.getContactById(contactId);
      if (!contact) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      const { name, email, phoneNumber, isFavorite, profilePic } = req.body;
      
      const updatedContact = await storage.updateContact(contactId, {
        name,
        email,
        phoneNumber,
        isFavorite,
        profilePic
      });
      
      return res.json(updatedContact);
    } catch (error) {
      console.error("Update contact error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.delete("/api/contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      if (isNaN(contactId)) {
        return res.status(400).json({ message: "Invalid contact ID" });
      }
      
      const success = await storage.deleteContact(contactId);
      if (!success) {
        return res.status(404).json({ message: "Contact not found" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Delete contact error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  return httpServer;
}
