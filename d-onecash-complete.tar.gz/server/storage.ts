import { 
  users, type User, type InsertUser,
  wallets, type Wallet, type InsertWallet,
  transactions, type Transaction, type InsertTransaction,
  qrCodes, type QrCode, type InsertQrCode,
  contacts, type Contact, type InsertContact
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: Omit<InsertUser, "id">): Promise<User>;
  
  // Wallet operations
  getWallet(id: number): Promise<Wallet | undefined>;
  getWalletByUserId(userId: number): Promise<Wallet | undefined>;
  createWallet(wallet: Omit<InsertWallet, "id">): Promise<Wallet>;
  updateWallet(id: number, updates: Partial<Wallet>): Promise<Wallet>;
  
  // Transaction operations
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactionsByUserId(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: Omit<InsertTransaction, "id">): Promise<Transaction>;
  
  // QR Code operations
  getQrCode(id: number): Promise<QrCode | undefined>;
  getQrCodesByUserId(userId: number): Promise<QrCode[]>;
  createQrCode(qrCode: Omit<InsertQrCode, "id">): Promise<QrCode>;
  updateQrCode(id: number, updates: Partial<QrCode>): Promise<QrCode>;
  
  // Contact operations
  getContactById(id: number): Promise<Contact | undefined>;
  getContactsByUserId(userId: number): Promise<Contact[]>;
  createContact(contact: Omit<InsertContact, "id">): Promise<Contact>;
  updateContact(id: number, updates: Partial<Contact>): Promise<Contact>;
  deleteContact(id: number): Promise<boolean>;
  
  // Inheritance operations
  getHeirsByUserId(userId: number): Promise<Heir[]>;
  createHeir(heir: Omit<InsertHeir, "id">): Promise<Heir>;
  updateHeir(id: number, updates: Partial<Heir>): Promise<Heir>;
  deleteHeir(id: number): Promise<boolean>;
  getInheritanceSettings(userId: number): Promise<InheritanceSettings | undefined>;
  updateInheritanceSettings(userId: number, settings: Partial<InheritanceSettings>): Promise<InheritanceSettings>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private wallets: Map<number, Wallet>;
  private transactions: Map<number, Transaction>;
  private qrCodes: Map<number, QrCode>;
  private contacts: Map<number, Contact>;
  private userId: number;
  private walletId: number;
  private transactionId: number;
  private qrCodeId: number;
  private contactId: number;

  constructor() {
    this.users = new Map();
    this.wallets = new Map();
    this.transactions = new Map();
    this.qrCodes = new Map();
    this.contacts = new Map();
    this.userId = 1;
    this.walletId = 1;
    this.transactionId = 1;
    this.qrCodeId = 1;
    this.contactId = 1;
    
    // Initialize with demo data
    this.initDemoData();
  }

  private initDemoData() {
    // Create demo user
    const demoUser: User = {
      id: this.userId++,
      username: "demo",
      password: "password123",
      email: "demo@donecash.com",
      phoneNumber: "+1234567890",
      fullName: "Demo User",
      walletAddress: "d1c:0x7F5E8c21A53dE856DBC4a0a25E0C98d06Dff303C",
      avatarUrl: null,
      createdAt: new Date(),
    };
    this.users.set(demoUser.id, demoUser);

    // Create wallet for demo user
    const demoWallet: Wallet = {
      id: this.walletId++,
      userId: demoUser.id,
      balance: 3428.65,
      currency: "USDC",
      createdAt: new Date(),
    };
    this.wallets.set(demoWallet.id, demoWallet);

    // Create some demo transactions
    const transactions: Omit<Transaction, "id">[] = [
      {
        userId: demoUser.id,
        type: "send",
        amount: 250,
        fee: 2.5,
        recipient: "maria@example.com",
        sender: undefined,
        note: "Monthly rent",
        status: "completed",
        createdAt: new Date(),
      },
      {
        userId: demoUser.id,
        type: "receive",
        amount: 520,
        fee: 0,
        recipient: undefined,
        sender: "john@example.com",
        note: "Project payment",
        status: "completed",
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
      },
      {
        userId: demoUser.id,
        type: "reward",
        amount: 12.55,
        fee: 0,
        recipient: undefined,
        sender: undefined,
        note: "Staking reward",
        status: "completed",
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      },
      {
        userId: demoUser.id,
        type: "card",
        amount: 100,
        fee: 1,
        recipient: "Virtual Card",
        sender: undefined,
        note: "Card top-up",
        status: "completed",
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      },
    ];

    transactions.forEach(transaction => {
      this.transactions.set(this.transactionId, {
        ...transaction,
        id: this.transactionId++,
      });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(user: Omit<InsertUser, "id">): Promise<User> {
    const id = this.userId++;
    const newUser: User = {
      ...user,
      id,
      createdAt: new Date(),
    };
    this.users.set(id, newUser);
    return newUser;
  }

  // Wallet operations
  async getWallet(id: number): Promise<Wallet | undefined> {
    return this.wallets.get(id);
  }

  async getWalletByUserId(userId: number): Promise<Wallet | undefined> {
    return Array.from(this.wallets.values()).find(
      (wallet) => wallet.userId === userId,
    );
  }

  async createWallet(wallet: Omit<InsertWallet, "id">): Promise<Wallet> {
    const id = this.walletId++;
    const newWallet: Wallet = {
      ...wallet,
      id,
      createdAt: new Date(),
    };
    this.wallets.set(id, newWallet);
    return newWallet;
  }

  async updateWallet(id: number, updates: Partial<Wallet>): Promise<Wallet> {
    const wallet = await this.getWallet(id);
    if (!wallet) {
      throw new Error(`Wallet with ID ${id} not found`);
    }
    
    const updatedWallet = {
      ...wallet,
      ...updates,
    };
    this.wallets.set(id, updatedWallet);
    return updatedWallet;
  }

  // Transaction operations
  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async getTransactionsByUserId(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createTransaction(transaction: Omit<InsertTransaction, "id">): Promise<Transaction> {
    const id = this.transactionId++;
    const newTransaction: Transaction = {
      ...transaction,
      id,
      createdAt: new Date(),
    };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  // QR Code operations
  async getQrCode(id: number): Promise<QrCode | undefined> {
    return this.qrCodes.get(id);
  }

  async getQrCodesByUserId(userId: number): Promise<QrCode[]> {
    return Array.from(this.qrCodes.values())
      .filter((qrCode) => qrCode.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createQrCode(qrCode: Omit<InsertQrCode, "id">): Promise<QrCode> {
    const id = this.qrCodeId++;
    const newQrCode: QrCode = {
      ...qrCode,
      id,
      createdAt: new Date(),
    };
    this.qrCodes.set(id, newQrCode);
    return newQrCode;
  }

  async updateQrCode(id: number, updates: Partial<QrCode>): Promise<QrCode> {
    const qrCode = await this.getQrCode(id);
    if (!qrCode) {
      throw new Error(`QR Code with ID ${id} not found`);
    }
    
    const updatedQrCode = {
      ...qrCode,
      ...updates,
    };
    this.qrCodes.set(id, updatedQrCode);
    return updatedQrCode;
  }

  // Contact operations
  async getContactById(id: number): Promise<Contact | undefined> {
    return this.contacts.get(id);
  }

  async getContactsByUserId(userId: number): Promise<Contact[]> {
    return Array.from(this.contacts.values())
      .filter(contact => contact.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createContact(contact: Omit<InsertContact, "id">): Promise<Contact> {
    const id = this.contactId++;
    const newContact: Contact = {
      ...contact,
      id,
      createdAt: new Date(),
    };
    this.contacts.set(id, newContact);
    return newContact;
  }

  async updateContact(id: number, updates: Partial<Contact>): Promise<Contact> {
    const contact = await this.getContactById(id);
    if (!contact) {
      throw new Error(`Contact with ID ${id} not found`);
    }
    
    const updatedContact = {
      ...contact,
      ...updates,
    };
    this.contacts.set(id, updatedContact);
    return updatedContact;
  }

  async deleteContact(id: number): Promise<boolean> {
    const exists = this.contacts.has(id);
    if (!exists) return false;
    
    this.contacts.delete(id);
    return true;
  }
}

export const storage = new MemStorage();
